<?php
/*
 * All Metabox related options for Fame theme.
 * Author & Copyright: VictorThemes
 * URL: http://themeforest.net/user/VictorThemes
 */

// Control core classes for avoid errors
if( class_exists( 'CSF' ) ) {

  $templates = get_posts( 'post_type="elementor_library"&numberposts=-1' );
  $elementor_templates = array();
  if ( $templates ) {
    foreach ( $templates as $template ) {
      $elementor_templates[ $template->ID ] = $template->post_title;
    }
  } else {
    $elementor_templates[ __( 'No templates found', 'fame' ) ] = 0;
  }

  $organizers = get_posts( 'post_type="tribe_organizer"&numberposts=-1' );
  $fame_organizers = array();
  if ( $organizers ) {
    foreach ( $organizers as $organizer ) {
      $fame_organizers[ $organizer->ID ] = $organizer->post_title;
    }
  } else {
    $fame_organizers[ __( 'No organizers found', 'fame' ) ] = 0;
  }

  // Set a unique slug-like ID
  $meta_prefix = 'page_type_metabox';

  // Page Custom Options
  CSF::createMetabox( $meta_prefix, array(
    'id'        => 'page_type_metabox',
    'title'     => esc_html__('Page Custom Options', 'fame'),
    'post_type' => array('post', 'page', 'portfolio', 'testimonial', 'team', 'casestudies'),
    'context'   => 'normal',
    'priority'  => 'default',
  ) );

  // Header
  CSF::createSection( $meta_prefix, array(
    'name'  => 'header_section',
    'title' => esc_html__('Header', 'fame'),
    'icon'  => 'fa fa-bars',
    'fields' => array(

      array(
        'id'             => 'choose_menu',
        'type'           => 'select',
        'title'          => esc_html__('Choose Menu', 'fame'),
        'desc'          => esc_html__('Choose custom menus for this page.', 'fame'),
        'options'        => 'menus',
        'default_option' => esc_html__('Select your menu', 'fame'),
      ),
      array(
        'id'    => 'one_page_menu',
        'type'  => 'switcher',
        'title' => esc_html__('One Page Scroll Menu', 'fame'),
        'label' => esc_html__('Yes, Please do it.', 'fame'),
      ),
      array(
        'id'        => 'search_icon',
        'type'      => 'select',
        'title'     => esc_html__('Search Icon', 'fame'),
        'options'   => array(
          'default'    => 'Default(Theme Options)',
          'show' => 'Show',
          'hide'   => 'Hide',
        ),
      ),

    )
  ) );

  // Header
  CSF::createSection( $meta_prefix, array(
    'name'  => 'footer_section',
    'title' => esc_html__('Footer', 'fame'),
    'icon'  => 'fa fa-ellipsis-h',
    'fields' => array(
      
      array(
        'id'        => 'hide_footer_top',
        'type'      => 'select',
        'title'     => esc_html__('Footer Top Widget', 'fame'),
        'options'   => array(
          'default'    => 'Default(Theme Options)',
          'show' => 'Show',
          'hide'   => 'Hide',
        ),
      ),
      array(
        'id'        => 'footer_top_style',
        'type'      => 'select',
        'title'     => esc_html__('Footer Top Widget Style', 'fame'),
        'options'   => array(
          'default-style' => 'Style One Default',
          'style-two'     => 'Style Two (Blue)',
          'style-three'   => 'Style Three (Yellow)',
        ),
        'dependency'  => array('hide_footer_top', '!=', 'hide'),
      ),
      array(
        'id'    => 'footer_top_bg',
        'type'  => 'media',
        'url'   => false,
        'title' => esc_html__('Background Image', 'fame'),
        'dependency'  => array('hide_footer_top', '!=', 'hide'),
      ),

    )
  ) );

  // Banner & Title Area
  CSF::createSection( $meta_prefix, array(
    'name'  => 'banner_title_section',
    'title' => esc_html__('Banner & Title Area', 'fame'),
    'icon'  => 'fa fa-bullhorn',
    'fields' => array(

      array(
        'id'        => 'banner_type',
        'type'      => 'select',
        'title'     => esc_html__('Choose Banner Type', 'fame'),
        'options'   => array(
          'default-title'    => 'Default Title',
          'revolution-slider' => 'Shortcode [Rev Slider]',
          'elementor-templates' => 'Elementor Templates',
          'hide-title-area'   => 'Hide Title/Banner Area',
        ),
      ),
      array(
        'id'             => 'ele_templates',
        'type'           => 'select',
        'title'          => esc_html__('Elementor Templates', 'fame'),
        'desc'          => esc_html__('Choose template for this page.', 'fame'),
        'options'        => $elementor_templates,
        'default_option' => esc_html__('Select your template', 'fame'),
        'dependency'   => array('banner_type', '==', 'elementor-templates' ),
      ),
      array(
        'id'    => 'page_revslider',
        'type'  => 'textarea',
        'title' => esc_html__('Revolution Slider or Any Shortcodes', 'fame'),
        'desc' => esc_html__('Enter any shortcodes that you want to show in this page title area. <br />Eg : Revolution Slider shortcode.', 'fame'),
        'attributes' => array(
          'placeholder' => esc_html__('Enter your shortcode...', 'fame'),
        ),
        'dependency'   => array('banner_type', '==', 'revolution-slider' ),
      ),
      array(
        'id'    => 'page_custom_title',
        'type'  => 'text',
        'title' => esc_html__('Custom Title', 'fame'),
        'attributes' => array(
          'placeholder' => esc_html__('Enter your custom title...', 'fame'),
        ),
        'dependency'   => array('banner_type', '==', 'default-title'),
      ),
      array(
        'type'    => 'submessage',
        'style'   => 'info',
        'content' => esc_html__('Spaces & Background Options', 'fame'),
        'dependency'   => array('banner_type', '==', 'default-title'),
      ),
      array(
        'id'        => 'title_area_spacings',
        'type'      => 'select',
        'title'     => esc_html__('Title Area Spacings', 'fame'),
        'options'   => array(
          'padding-default' => esc_html__('Default Spacing', 'fame'),
          'padding-xs' => esc_html__('Extra Small Padding', 'fame'),
          'padding-sm' => esc_html__('Small Padding', 'fame'),
          'padding-md' => esc_html__('Medium Padding', 'fame'),
          'padding-lg' => esc_html__('Large Padding', 'fame'),
          'padding-xl' => esc_html__('Extra Large Padding', 'fame'),
          'padding-no' => esc_html__('No Padding', 'fame'),
          'padding-custom' => esc_html__('Custom Padding', 'fame'),
        ),
        'dependency'   => array('banner_type', '==', 'default-title'),
      ),
      array(
        'id'    => 'title_top_bottom_padding',
        'type'  => 'spacing',
        'title' => esc_html__('Title Bar Top & Bottom Space', 'fame'),
        'left'  => false,
        'right' => false,
        'dependency'  => array('banner_type|title_area_spacings', '==|==', 'default-title|padding-custom'),
      ),
      array(
        'id'    => 'title_area_bg',
        'type'    => 'background',
        'title'   => esc_html__('Background', 'fame'),
        'background_color'      => true,
        'background_image'      => true,
        'background-position'   => true,
        'background_repeat'     => true,
        'background_attachment' => true,
        'background_size'       => true,
        'background_origin'     => true,
        'background_clip'       => true,
        'background_blend_mode' => true,
        'title' => esc_html__('Background', 'fame'),
        'dependency'   => array('banner_type', '==', 'default-title'),
      ),
    )
  ) );

  // Content
  CSF::createSection( $meta_prefix, array(
    'name'  => 'page_content_options',
    'title' => esc_html__('Content Options', 'fame'),
    'icon'  => 'fa fa-file',
    'fields' => array(

      array(
        'id'        => 'content_spacings',
        'type'      => 'select',
        'title'     => esc_html__('Content Spacings', 'fame'),
        'options'   => array(
          'padding-default' => esc_html__('Default Spacing', 'fame'),
          'padding-xs' => esc_html__('Extra Small Padding', 'fame'),
          'padding-sm' => esc_html__('Small Padding', 'fame'),
          'padding-md' => esc_html__('Medium Padding', 'fame'),
          'padding-lg' => esc_html__('Large Padding', 'fame'),
          'padding-xl' => esc_html__('Extra Large Padding', 'fame'),
          'padding-cnt-no' => esc_html__('No Padding', 'fame'),
          'padding-custom' => esc_html__('Custom Padding', 'fame'),
        ),
        'desc' => esc_html__('Content area top and bottom spacings.', 'fame'),
      ),
      array(
        'id'    => 'content_top_bottom_padding',
        'type'  => 'spacing',
        'title' => esc_html__('Content Top & Bottom Space', 'fame'),
        'left'  => false,
        'right' => false,
        'dependency'  => array('content_spacings', '==', 'padding-custom'),
      ),

    )
  ) );

  // Enable & Disable
  CSF::createSection( $meta_prefix, array(
    'name'  => 'hide_show_section',
    'title' => esc_html__('Enable & Disable', 'fame'),
    'icon'  => 'fa fa-toggle-on',
    'fields' => array(

      array(
        'id'    => 'hide_header',
        'type'  => 'switcher',
        'title' => esc_html__('Hide Header', 'fame'),
        'label' => esc_html__('Yes, Please do it.', 'fame'),
      ),
      array(
        'id'    => 'hide_footer',
        'type'  => 'switcher',
        'title' => esc_html__('Hide Footer', 'fame'),
        'label' => esc_html__('Yes, Please do it.', 'fame'),
      ),
      array(
        'id'    => 'hide_copyright',
        'type'  => 'switcher',
        'title' => esc_html__('Hide Copyright', 'fame'),
        'label' => esc_html__('Yes, Please do it.', 'fame'),
      ),

    )
  ) );

  // Layout Options
  $meta_prefix_layout = 'page_layout_options';

  CSF::createMetabox( $meta_prefix_layout, array(
    'id'        => 'page_layout_options',
    'title'     => esc_html__('Page Layout', 'fame'),
    'post_type' => 'page',
    'context'   => 'side',
  ) );

  // Layout
  CSF::createSection( $meta_prefix_layout, array(
    'parent' => 'page_layout_options',
    'name'   => 'page_layout_section',
    'fields' => array(

      array(
        'id'        => 'page_layout',
        'type'      => 'image_select',
        'title'          => esc_html__('Page Layout Options', 'fame'),
        'options'   => array(
          'default'       => FAME_PLUGIN_IMGS . '/pages/page-0.png',
          'full-width'    => FAME_PLUGIN_IMGS . '/pages/page-2.png',
          'left-sidebar'  => FAME_PLUGIN_IMGS . '/pages/page-3.png',
          'right-sidebar' => FAME_PLUGIN_IMGS . '/pages/page-4.png',
        ),
        'default'    => 'default',
      ),
      array(
        'id'             => 'page_sidebar_widget',
        'type'           => 'select',
        'title'          => esc_html__('Sidebar Widget', 'fame'),
        'options'        => 'sidebars',
        'default_option' => esc_html__('Select Widget', 'fame'),
        'dependency'     => array('page_layout', 'any', 'left-sidebar,right-sidebar'),
      ),

    )
  ) );

  // Post Options
  $meta_prefix_post = 'post_type_metabox';

  CSF::createMetabox( $meta_prefix_post, array(
    'id'        => 'post_type_metabox',
    'title'     => esc_html__('Post Options', 'fame'),
    'post_type' => 'post',
    'context'   => 'normal',
    'priority'  => 'default',
    'post_formats'  => 'quote',
  ) );

  // Post
  CSF::createSection( $meta_prefix_post, array(
    'parent'   => 'post_type_metabox',
    'name'     => 'section_post_formats',
    'fields' => array(

      array(
        'id'      => 'quote_text',
        'type'    => 'textarea',
        'title'     => esc_html__('Quote Text', 'fame'),
        'desc'    => esc_html__('Enter your quote text.', 'fame'),
      ),
      array(
        'id'      => 'quote_author',
        'type'    => 'text',
        'title'     => esc_html__('Quote Author', 'fame'),
      ),
      array(
        'id'      => 'quote_author_link',
        'type'    => 'text',
        'title'     => esc_html__('Quote Author Link', 'fame'),
      ),

    )
  ) );

  // Testimonial Options
  $meta_prefix_testi = 'testimonial_options';

  CSF::createMetabox( $meta_prefix_testi, array(
    'id'        => 'testimonial_options',
    'title'     => esc_html__('Testimonial Options', 'fame'),
    'post_type' => 'testimonial',
    'context'   => 'side',
    'priority'  => 'default',
  ) );

  // Testimonial
  CSF::createSection( $meta_prefix_testi, array(
    'parent'   => 'testimonial_options',
    'name'  => 'testimonial_option_section',
    'fields' => array(

      array(
        'id'      => 'testi_position',
        'type'    => 'text',
        'title'     => esc_html__('Job Position', 'fame'),
        'attributes' => array(
          'placeholder' => esc_html__('Eg : Financial Manager', 'fame'),
        ),
        'desc'    => esc_html__('Enter job position in your company.', 'fame'),
      ),
      array(
        'id'    => 'testi_logo',
        'type'  => 'media',
        'url'   => false,
        'title' => esc_html__('Testimonial Logo', 'fame'),
        'desc'  => esc_html__('Choose your logo.', 'fame'),
        'button_title' => esc_html__('Add Logo', 'fame'),
      ),

    )
  ) );

  // Team Options
  $meta_prefix_team = 'team_options';

  CSF::createMetabox( $meta_prefix_team, array(
    'id'        => 'team_options',
    'title'     => esc_html__('Team Options', 'fame'),
    'post_type' => 'team',
    'context'   => 'side',
    'priority'  => 'default',
  ) );

  // Team
  CSF::createSection( $meta_prefix_team, array(
    'parent'   => 'team_options',
    'name'  => 'team_option_section',
    'fields' => array(

      array(
        'id'      => 'team_job_position',
        'title'   => esc_html__('Job Position', 'fame'),
        'type'    => 'text',
        'attributes' => array(
          'placeholder' => esc_html__('Eg : Financial Manager', 'fame'),
        ),
        'info'    => esc_html__('Enter this employee job position, in your company.', 'fame'),
      ),
      // Contact fields
      array(
        'id'                  => 'contact_details',
        'type'                => 'group',
        'title'    => esc_html__('Contact Details', 'fame'),
        'button_title'       => 'Add New',
        'fields'              => array(

          array(
            'id'              => 'contact_title',
            'type'            => 'text',
            'title'           => esc_html__('Enter your title', 'fame'),
          ),
          array(
            'id'              => 'contact_text',
            'type'            => 'text',
            'title'           => esc_html__('Enter your text', 'fame'),
          ),
          array(
            'id'              => 'contact_link',
            'type'            => 'text',
            'title'           => esc_html__('Enter your link', 'fame'),
          ),

        ),
      ),
      // Contact fields
      // Social fields
      array(
        'id'                  => 'social_icons',
        'type'                => 'group',
        'title'    => esc_html__('Social Icons', 'fame'),
        'button_title'       => 'Add New Icon',
        'fields'              => array(
          array(
            'id'              => 'icon',
            'type'            => 'icon',
            'title'           => esc_html__('Selected your icon', 'fame'),
          ),
          array(
            'id'              => 'icon_link',
            'type'            => 'text',
            'title'           => esc_html__('Enter your icon link', 'fame'),
          ),
        ),
      ),
      // Social fields

    )
  ) );

  // Portfolio Options
  $meta_prefix_testi = 'portfolio_options';

  CSF::createMetabox( $meta_prefix_testi, array(
    'id'        => 'portfolio_options',
    'title'     => esc_html__('Portfolio Options', 'fame'),
    'post_type' => 'portfolio',
    'context'   => 'side',
    'priority'  => 'default',
  ) );

  // Portfolio
  CSF::createSection( $meta_prefix_testi, array(
    'parent'   => 'portfolio_options',
    'name'  => 'portfolio_option_section',
    'fields' => array(

      array(
        'id'      => 'portfolio_client',
        'type'    => 'text',
        'title'     => esc_html__('Client', 'fame'),
        'attributes' => array(
          'placeholder' => esc_html__('Eg : Fame Tech Pvt', 'fame'),
        ),
        'desc'    => esc_html__('Enter client name.', 'fame'),
      ),
      array(
        'id'      => 'portfolio_client_link',
        'type'    => 'text',
        'title'     => esc_html__('Client Link', 'fame'),
      ),
      array(
        'id'    => 'portfolio_banner',
        'type'  => 'media',
        'url'   => false,
        'title' => esc_html__('Portfolio Image', 'fame'),
        'desc'  => esc_html__('Choose your image.', 'fame'),
        'button_title' => esc_html__('Add Image', 'fame'),
      ),

    )
  ) );

  // Organizer Options
  $meta_prefix_org = 'organizer_option';

  CSF::createMetabox( $meta_prefix_org, array(
    'id'        => 'organizer_options',
    'title'     => esc_html__('Organizer Options', 'fame'),
    'post_type' => 'tribe_organizer',
    'context'   => 'side',
    'priority'  => 'default',
  ) );

  // Organizer
  CSF::createSection( $meta_prefix_org, array(
    'parent'   => 'organizer_options',
    'name'  => 'organizer_option_section',
    'fields' => array(

      array(
        'id'      => 'organizer_role',
        'title'   => esc_html__('Organizer Role', 'fame'),
        'type'    => 'text',
        'attributes' => array(
          'placeholder' => esc_html__('Eg : Speaker', 'fame'),
        ),
        'info'    => esc_html__('Enter this organizer role.', 'fame'),
      ),
      // Social fields
      array(
        'id'                  => 'social_icons',
        'type'                => 'group',
        'title'    => esc_html__('Social Icons', 'fame'),
        'button_title'       => 'Add New Icon',
        'fields'              => array(
          array(
            'id'              => 'icon',
            'type'            => 'icon',
            'title'           => esc_html__('Selected your icon', 'fame'),
          ),
          array(
            'id'              => 'icon_link',
            'type'            => 'text',
            'title'           => esc_html__('Enter your icon link', 'fame'),
          ),
        ),
      ),
      // Social fields

    )
  ) );

  // Event Options
  $meta_prefix_event = 'event_options';

  CSF::createMetabox( $meta_prefix_event, array(
    'id'        => 'event_options',
    'title'     => esc_html__('Event Options', 'fame'),
    'post_type' => 'tribe_events',
    'context'   => 'normal',
    'priority'  => 'default',
  ) );

  // Event
  CSF::createSection( $meta_prefix_event, array(
    'parent'   => 'event_options',
    'name'  => 'event_option_section',
    'fields' => array(

      array(
        'id'                  => 'schedules',
        'type'                => 'group',
        'title'               => esc_html__('Schedules', 'fame'),
        'button_title'        => esc_html__('Add New Schedule', 'fame'),
        'fields'              => array(

          array(
            'id'    => 'schedule_title',
            'type'  => 'text',
            'title' => esc_html__('Title', 'fame'),
          ),
          array(
            'id'     => 'schedule_item',
            'type'   => 'group',
            'title'  => esc_html__('Schedule Info', 'fame'),
            'fields' => array(

              array(
                'id'    => 'schedule_item_title',
                'type'  => 'text',
                'title' => esc_html__('Title', 'fame'),
              ),
              array(
                'id'    => 'schedule_item_time',
                'type'  => 'text',
                'title' => esc_html__('Time', 'fame'),
              ),
              array(
                'id'    => 'schedule_item_title_link',
                'type'  => 'text',
                'title' => esc_html__('Title Link', 'fame'),
              ),
              array(
                'id'    => 'open_tab',
                'type'  => 'switcher',
                'title' => esc_html__('Open New Tab?', 'fame'),
                'label' => esc_html__('Yes, Please do it.', 'fame'),
              ),
              array(
                'id'    => 'schedule_image',
                'type'  => 'media',
                'url'   => false,
                'title' => esc_html__('Schedule Image', 'fame'),
                'desc'  => esc_html__('Choose your image.', 'fame'),
                'button_title' => esc_html__('Add Image', 'fame'),
              ),
              array(
                'id'             => 'schedule_item_organizer',
                'type'           => 'select',
                'title'          => esc_html__('Event By', 'fame'),
                'options'        => $fame_organizers,
                'default_option' => esc_html__('Select Organizer', 'fame'),
              ),

            ),
          ),

        ),
      ),

    )
  ) );

}