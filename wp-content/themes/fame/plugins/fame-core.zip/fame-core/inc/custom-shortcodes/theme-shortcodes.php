<?php
/*
 * All Custom Shortcode for fame theme.
 * Author & Copyright: VictorThemes
 * URL: http://themeforest.net/user/VictorThemes
 */

// Control core classes for avoid errors
if( class_exists( 'CSF' ) ) {

  // Set a unique slug-like ID
  $prefix = 'fame_vt_shortcodes';

  // Create a shortcoder
  CSF::createShortcoder( $prefix, array(
    'button_title'   => 'Add Shortcode',
    'select_title'   => 'Select a shortcode',
    'insert_title'   => 'Insert Shortcode',
    'show_in_editor' => true,
    'gutenberg'      => array(
      'title'        => 'Fame Shortcodes',
      'description'  => 'Fame Shortcode Block',
      'icon'         => 'screenoptions',
      'category'     => 'widgets',
      'keywords'     => array( 'shortcode', 'csf', 'insert' ),
      'placeholder'  => 'Write shortcode here...',
    )
  ) );

  CSF::createSection( $prefix, array(
    'title'     => 'Header Buttons',
    'view'      => 'group',
    'shortcode' => 'fame_header_btns',
    'fields'    => array(

      array(
        'id'        => 'custom_class',
        'type'      => 'text',
        'title'     => __('Custom Class', 'fame'),
      ),
      array(
        'id'       => 'btn_text_size',
        'type'     => 'spinner',
        'title'    => __('Button Text Size', 'fame'),
        'max'      => 100,
        'min'      => 0,
        'step'     => 1,
        'unit'     => 'px',
      ),
      array(
        'id'        => 'btn_text_color',
        'type'      => 'color_group',
        'title'     => __('Button Text Color', 'fame'),
        'options'   => array(
          'bt_color' => 'Color',
          'bt_hover' => 'Hover',
        )
      ),
      array(
        'id'        => 'link_text_color',
        'type'      => 'color_group',
        'title'     => __('Link Text Color', 'fame'),
        'options'   => array(
          'link_color' => 'Color',
          'link_hover' => 'Hover',
        )
      ),
      array(
        'id'        => 'btn_bg_color',
        'type'      => 'color_group',
        'title'     => __('Button Background Color', 'fame'),
        'options'   => array(
          'bt_bg_color' => 'Color',
          'bt_bg_hover' => 'Hover',
        )
      ),

    ),
    'group_shortcode' => 'fame_header_btn',
    'group_fields'    => array(

      array(
        'id'    => 'simple_link',
        'type'  => 'switcher',
        'title' => 'Simple Link?',
      ),
      array(
        'id'        => 'btn_text',
        'type'      => 'text',
        'title'     => __('Button Text', 'fame')
      ),
      array(
        'id'        => 'btn_link',
        'type'      => 'text',
        'title'     => __('Button Link', 'fame')
      ),

    )

  ) );

  CSF::createSection( $prefix, array(
    'title'     => __('Free Trial', 'fame'),
    'view'      => 'normal',
    'shortcode' => 'fame_free_trial',
    'fields'    => array(

      array(
        'id'        => 'custom_class',
        'type'      => 'text',
        'title'     => __('Custom Class', 'fame'),
      ),
      array(
        'id'       => 'text_size',
        'type'     => 'spinner',
        'title'    => __('Text Size', 'fame'),
        'max'      => 100,
        'min'      => 0,
        'step'     => 1,
        'unit'     => 'px',
        'output'      => '.free-trial span',
        'output_mode' => 'font-size',
      ),
      array(
        'id'        => 'text_color',
        'type'      => 'color',
        'title'     => __('Text Color', 'fame'),
        'output'      => '.free-trial span',
        'output_mode' => 'color',
      ),
      array(
        'id'       => 'btn_text_size',
        'type'     => 'spinner',
        'title'    => __('Button Text Size', 'fame'),
        'max'      => 100,
        'min'      => 0,
        'step'     => 1,
        'unit'     => 'px',
        'output'      => '.free-trial .fame-label',
        'output_mode' => 'font-size',
      ),
      array(
        'id'        => 'btn_text_color',
        'type'      => 'color_group',
        'title'     => __('Button Text Color', 'fame'),
        'output'      => '.free-trial .fame-label',
        'output_mode' => 'color',
        'options'   => array(
          'bt_color' => 'Color',
          'bt_hover' => 'Hover',
        )
      ),
      array(
        'id'        => 'btn_bg_color',
        'type'      => 'color_group',
        'title'     => __('Button Background Color', 'fame'),
        'output'      => '.free-trial .fame-label',
        'output_mode' => 'background-color',
        'options'   => array(
          'bt_bg_color' => 'Color',
          'bt_bg_hover' => 'Hover',
        )
      ),
      array(
        'id'      => 'get_icon',
        'type'    => 'icon',
        'title'   => 'Icon',
        'default' => 'fa fa-check',
      ),
      array(
        'id'        => 'get_text',
        'type'      => 'textarea',
        'title'     => __('Text Block', 'fame'),
      ),
      array(
        'id'        => 'btn_text',
        'type'      => 'text',
        'title'     => __('Button Text', 'fame')
      ),
      array(
        'id'        => 'btn_link',
        'type'      => 'text',
        'title'     => __('Button Link', 'fame')
      ),

    )
  ) );

  CSF::createSection( $prefix, array(
    'title'     => __('Blockquote', 'fame'),
    'view'      => 'normal',
    'shortcode' => 'fame_blockquote',
    'fields'    => array(

      array(
        'id'        => 'custom_class',
        'type'      => 'text',
        'title'     => __('Custom Class', 'fame'),
      ),
      array(
        'id'       => 'text_size',
        'type'     => 'spinner',
        'title'    => __('Text Size', 'fame'),
        'max'      => 100,
        'min'      => 0,
        'step'     => 1,
        'unit'     => 'px',
      ),
      array(
        'id'        => 'text_color',
        'type'      => 'color',
        'title'     => __('Text Color', 'fame'),
      ),
      array(
        'id'        => 'border_color',
        'type'      => 'color',
        'title'     => __('Border Color', 'fame'),
      ),
      array(
        'id'       => 'author_text_size',
        'type'     => 'spinner',
        'title'    => __('Author Text Size', 'fame'),
        'max'      => 100,
        'min'      => 0,
        'step'     => 1,
        'unit'     => 'px',
      ),
      array(
        'id'        => 'author_text_color',
        'type'      => 'color_group',
        'title'     => __('Author Text Color', 'fame'),
        'options'   => array(
          'au_color' => 'Color',
          'au_hover' => 'Hover',
        )
      ),
      
      array(
        'id'        => 'get_text',
        'type'      => 'textarea',
        'title'     => __('Blockquote Text', 'fame'),
      ),
      array(
        'id'        => 'author_text',
        'type'      => 'text',
        'title'     => __('Author Text', 'fame')
      ),
      array(
        'id'        => 'author_link',
        'type'      => 'text',
        'title'     => __('Author Link', 'fame')
      ),

    )
  ) );

  CSF::createSection( $prefix, array(
    'title'     => 'Social Icons',
    'view'      => 'group',
    'shortcode' => 'fame_social_icons',
    'fields'    => array(

      array(
        'id'        => 'custom_class',
        'type'      => 'text',
        'title'     => __('Custom Class', 'fame'),
      ),
      array(
        'id'       => 'icon_size',
        'type'     => 'spinner',
        'title'    => __('Button Text Size', 'fame'),
        'max'      => 100,
        'min'      => 0,
        'step'     => 1,
        'unit'     => 'px',
      ),
      array(
        'id'        => 'icon_color',
        'type'      => 'color_group',
        'title'     => __('Icon Color', 'fame'),
        'options'   => array(
          'ico_color' => 'Color',
          'ico_hover' => 'Hover',
        )
      ),

    ),
    'group_shortcode' => 'fame_social_icon',
    'group_fields'    => array(

      array(
        'id'      => 'get_icon',
        'type'    => 'icon',
        'title'   => 'Icon',
        'default' => 'fa fa-facebook',
      ),
      array(
        'id'        => 'icon_link',
        'type'      => 'text',
        'title'     => __('Button Link', 'fame')
      ),

    )

  ) );

  CSF::createSection( $prefix, array(
    'title'     => 'List',
    'view'      => 'group',
    'shortcode' => 'fame_lists',
    'fields'    => array(

      array(
        'id'        => 'custom_class',
        'type'      => 'text',
        'title'     => __('Custom Class', 'fame'),
      ),

    ),
    'group_shortcode' => 'fame_list',
    'group_fields'    => array(

      array(
        'id'     => 'title',
        'type'   => 'textarea',
        'title'     => __('Content', 'fame'),
      ),

    )

  ) );

  CSF::createSection( $prefix, array(
    'title'     => 'How it Works Carousel',
    'view'      => 'group',
    'shortcode' => 'fame_how_it_works',
    'fields'    => array(

      array(
        'id'        => 'custom_class',
        'type'      => 'text',
        'title'     => __('Custom Class', 'fame'),
      ),

    ),
    'group_shortcode' => 'fame_how_it_work',
    'group_fields'    => array(

      array(
        'id'    => 'carousel_image',
        'type'  => 'upload',
        'title' => 'Carousel Image',
      ), 
      array(
        'id'     => 'carousel_content',
        'type'   => 'textarea',
        'title'     => __('Carousel Content', 'fame'),
      ),

    )

  ) );

  CSF::createSection( $prefix, array(
    'title'     => 'Footer Info',
    'view'      => 'group',
    'shortcode' => 'fame_footer_infos',
    'fields'    => array(

      array(
        'id'        => 'custom_class',
        'type'      => 'text',
        'title'     => __('Custom Class', 'fame'),
      ),   
      array(
        'id'    => 'info_logo',
        'type'  => 'upload',
        'title' => 'Info Logo',
      ),   
      array(
        'id'        => 'logo_link',
        'type'      => 'text',
        'title'     => __('Logo Link', 'fame')
      ),
      array(
        'id'     => 'info_content',
        'type'   => 'textarea',
        'title'     => __('Content', 'fame'),
      ),

    ),
    'group_shortcode' => 'fame_footer_info',
    'group_fields'    => array(

      array(
        'id'    => 'btn_image',
        'type'  => 'upload',
        'title' => 'Button Image',
      ), 
      array(
        'id'        => 'image_link',
        'type'      => 'text',
        'title'     => __('Image Link', 'fame')
      ),

    )

  ) );

  CSF::createSection( $prefix, array(
    'title'     => 'Footer Menu',
    'view'      => 'group',
    'shortcode' => 'fame_footer_menus',
    'fields'    => array(

      array(
        'id'        => 'custom_class',
        'type'      => 'text',
        'title'     => __('Custom Class', 'fame'),
      ),

    ),
    'group_shortcode' => 'fame_footer_menu',
    'group_fields'    => array(

      array(
        'id'     => 'link_title',
        'type'   => 'text',
        'title'     => __('Link Title', 'fame'),
      ),
      array(
        'id'     => 'title',
        'type'   => 'text',
        'title'     => __('Link Text', 'fame'),
      ),
      array(
        'id'     => 'link',
        'type'   => 'text',
        'title'     => __('Link', 'fame'),
      ),

    )

  ) );

}