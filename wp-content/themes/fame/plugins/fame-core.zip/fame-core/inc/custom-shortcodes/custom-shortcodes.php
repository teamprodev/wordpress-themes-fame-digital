<?php
/* Topbar Shortcodes */

/* Header Buttons */
function fame_header_btns_function($atts, $content = true) {
  extract(shortcode_atts(array(
    "custom_class" => '',
    "btn_text_size" => '',
    "bt_color" => '',
    "bt_hover" => '',
    "link_color" => '',
    "link_hover" => '',
    "bt_bg_color" => '',
    "bt_bg_hover" => '',
  ), $atts));

  // Shortcode Style CSS
  $e_uniqid       = uniqid();
  $inline_style   = '';

  // Btn Colors & Size
  if ( $btn_text_size || $bt_color || $bt_bg_color ) {
    $inline_style .= '.fame-btn-'. $e_uniqid .'.header-right-btn .fame-small-btn {';
    $inline_style .= ( $btn_text_size ) ? 'font-size:'. fame_core_check_px($btn_text_size) .';' : '';
    $inline_style .= ( $bt_color ) ? 'color:'. $bt_color .';' : '';
    $inline_style .= ( $bt_bg_color ) ? 'background-color:'. $bt_bg_color .';' : '';
    $inline_style .= '}';
  }
  // Btn Colors & Size
  if ( $bt_hover || $bt_bg_hover ) {
    $inline_style .= '.fame-btn-'. $e_uniqid .'.header-right-btn .fame-small-btn:hover {';
    $inline_style .= ( $bt_hover ) ? 'color:'. $bt_hover .';' : '';
    $inline_style .= ( $bt_bg_hover ) ? 'background-color:'. $bt_bg_hover .';' : '';
    $inline_style .= '}';
  }
  // Btn Colors & Size
  if ( $btn_text_size || $link_color ) {
    $inline_style .= '.fame-btn-'. $e_uniqid .'.header-right-btn .fame-default-link {';
    $inline_style .= ( $btn_text_size ) ? 'font-size:'. fame_core_check_px($btn_text_size) .';' : '';
    $inline_style .= ( $link_color ) ? 'color:'. $link_color .';' : '';
    $inline_style .= '}';
  }
  // Btn Colors & Size
  if ( $link_hover ) {
    $inline_style .= '.fame-btn-'. $e_uniqid .'.header-right-btn .fame-default-link:hover {';
    $inline_style .= ( $link_hover ) ? 'color:'. $link_hover .';' : '';
    $inline_style .= '}';
  }

  // add inline style
  add_inline_style( $inline_style );
  $styled_class  = ' fame-btn-'. $e_uniqid;

  $result = '<div class="header-right-btn '. $custom_class . $styled_class .'">'. do_shortcode($content) .'</div>';
  return $result;

}
add_shortcode("fame_header_btns", "fame_header_btns_function");

/* Header Button */
function fame_header_btn_function($atts, $content = NULL) {
  extract(shortcode_atts(array(
    "simple_link" => '',
    "btn_text" => '',
    "btn_link" => '',
  ), $atts));

  if ($simple_link) {
    $button = $btn_link ? '<a href="'.$btn_link.'" class="fame-default-link">'.$btn_text.'</a>' : '';
  } else {
    $button = $btn_link ? '<a href="'.$btn_link.'" class="fame-btn fame-blue-btn fame-small-btn">'.$btn_text.'</a>' : '';
  }

  $result = $button;
  return $result;

}
add_shortcode("fame_header_btn", "fame_header_btn_function");

/* Free Trial */
function fame_free_trial_function($atts, $content = NULL) {
  extract(shortcode_atts(array(
    "custom_class" => '',
    "text_size" => '',
    "text_color" => '',
    "btn_text_size" => '',
    "bt_color" => '',
    "bt_hover" => '',
    "bt_bg_color" => '',
    "bt_bg_hover" => '',
    "get_icon" => '',
    "get_text" => '',
    "btn_text" => '',
    "btn_link" => '',
  ), $atts));

  // Shortcode Style CSS
  $e_uniqid       = uniqid();
  $inline_style   = '';

  // Colors & Size
  if ( $text_size || $text_color ) {
    $inline_style .= '.fame-trial-'. $e_uniqid .'.free-trial span {';
    $inline_style .= ( $text_size ) ? 'font-size:'. fame_core_check_px($text_size) .';' : '';
    $inline_style .= ( $text_color ) ? 'color:'. $text_color .';' : '';
    $inline_style .= '}';
  }
  // Btn Colors & Size
  if ( $btn_text_size || $bt_color || $bt_bg_color ) {
    $inline_style .= '.fame-trial-'. $e_uniqid .'.free-trial .fame-label {';
    $inline_style .= ( $btn_text_size ) ? 'font-size:'. fame_core_check_px($btn_text_size) .';' : '';
    $inline_style .= ( $bt_color ) ? 'color:'. $bt_color .';' : '';
    $inline_style .= ( $bt_bg_color ) ? 'background-color:'. $bt_bg_color .';' : '';
    $inline_style .= '}';
  }
  // Btn Colors & Size
  if ( $bt_hover || $bt_bg_hover ) {
    $inline_style .= '.fame-trial-'. $e_uniqid .'.free-trial .fame-label:hover {';
    $inline_style .= ( $bt_hover ) ? 'color:'. $bt_hover .';' : '';
    $inline_style .= ( $bt_bg_hover ) ? 'background-color:'. $bt_bg_hover .';' : '';
    $inline_style .= '}';
  }

  // add inline style
  add_inline_style( $inline_style );
  $styled_class  = ' fame-trial-'. $e_uniqid;

  $result = '<div class="free-trial '.$custom_class.$styled_class.'">
              <span class="trial-label"><i class="'.$get_icon.'" aria-hidden="true"></i>'. $get_text .'</span>
              <a href="'. $btn_link .'" class="fame-label">'. $btn_text .'</a>
            </div>';
  return $result;
}
add_shortcode("fame_free_trial", "fame_free_trial_function");

/* Blockquote */
function fame_blockquote_function($atts, $content = NULL) {
  extract(shortcode_atts(array(
    "custom_class" => '',
    "text_size" => '',
    "text_color" => '',
    "border_color" => '',
    "author_text_size" => '',
    "au_color" => '',
    "au_hover" => '',
    "get_text" => '',
    "author_text" => '',
    "author_link" => '',
  ), $atts));

  // Shortcode Style CSS
  $e_uniqid       = uniqid();
  $inline_style   = '';

  // Colors & Size
  if ( $text_size || $text_color ) {
    $inline_style .= 'blockquote.fame-quote-'. $e_uniqid .' p {';
    $inline_style .= ( $text_size ) ? 'font-size:'. fame_core_check_px($text_size) .';' : '';
    $inline_style .= ( $text_color ) ? 'color:'. $text_color .';' : '';
    $inline_style .= '}';
  }
  // Btn Colors & Size
  if ( $author_text_size || $au_color ) {
    $inline_style .= 'blockquote.fame-quote-'. $e_uniqid .' cite a {';
    $inline_style .= ( $author_text_size ) ? 'font-size:'. fame_core_check_px($author_text_size) .';' : '';
    $inline_style .= ( $au_color ) ? 'color:'. $au_color .';' : '';
    $inline_style .= '}';
  }
  // Btn Colors & Size
  if ( $au_hover ) {
    $inline_style .= 'blockquote.fame-quote-'. $e_uniqid .' cite a:hover {';
    $inline_style .= ( $au_hover ) ? 'color:'. $au_hover .';' : '';
    $inline_style .= '}';
  }
  if ( $border_color ) {
    $inline_style .= 'blockquote.fame-quote-'. $e_uniqid .' {';
    $inline_style .= ( $border_color ) ? 'border-color:'. $border_color .';' : '';
    $inline_style .= '}';
  }

  // add inline style
  add_inline_style( $inline_style );
  $styled_class  = ' fame-quote-'. $e_uniqid;

  $text = $get_text ? '<p>'.$get_text.'</p>' : '';
  $author = $author_link ? '<cite><a href="'. $author_link .'">'. $author_text .'</a></cite>' : '<cite>'. $author_text .'</cite>';

  $result = '<blockquote class="'.$custom_class.$styled_class.'">'.$text.$author.'</blockquote>';
  return $result;
}
add_shortcode("fame_blockquote", "fame_blockquote_function");

/* Social Icons */
function fame_social_icons_function($atts, $content = true) {
  extract(shortcode_atts(array(
    "custom_class" => '',
    "icon_size" => '',
    "ico_color" => '',
    "ico_hover" => '',
  ), $atts));

  // Shortcode Style CSS
  $e_uniqid       = uniqid();
  $inline_style   = '';

  // Icon Colors & Size
  if ( $icon_size || $ico_color ) {
    $inline_style .= '.fame-copyright .fame-social-'. $e_uniqid .'.fame-social a {';
    $inline_style .= ( $icon_size ) ? 'font-size:'. fame_core_check_px($icon_size) .';' : '';
    $inline_style .= ( $ico_color ) ? 'color:'. $ico_color .';' : '';
    $inline_style .= '}';
  }
  // Icon Hover Color
  if ( $ico_hover ) {
    $inline_style .= '.fame-copyright .fame-social-'. $e_uniqid .'.fame-social a:hover {';
    $inline_style .= ( $ico_hover ) ? 'color:'. $ico_hover .';' : '';
    $inline_style .= '}';
  }

  // add inline style
  add_inline_style( $inline_style );
  $styled_class  = ' fame-social-'. $e_uniqid;

  $result = '<div class="fame-social '. $custom_class . $styled_class .'">'. do_shortcode($content) .'</div>';
  return $result;

}
add_shortcode("fame_social_icons", "fame_social_icons_function");

/* Social Icon */
function fame_social_icon_function($atts, $content = NULL) {
  extract(shortcode_atts(array(
    "get_icon" => '',
    "icon_link" => '',
  ), $atts));

  $icon = $icon_link ? '<a href="'.$icon_link.'"><i class="'.$get_icon.'" aria-hidden="true"></i></a>' : '';

  $result = $icon;
  return $result;

}
add_shortcode("fame_social_icon", "fame_social_icon_function");

/* Lists */
function fame_lists_function($atts, $content = true) {
   extract(shortcode_atts(array(
      "custom_class" => '',
   ), $atts));

   $result = '<ul class="bullets-list '. $custom_class .'">'. do_shortcode($content) .'</ul>';
   return $result;

}
add_shortcode("fame_lists", "fame_lists_function");

/* List */
function fame_list_function($atts, $content = NULL) {
   extract(shortcode_atts(array(
      "title" => '',
   ), $atts));

   $menu_title = $title ? '<li>'.$title.'</li>' : '';

   return $menu_title;

}
add_shortcode("fame_list", "fame_list_function");

/* How it Works */
function fame_how_it_works_function($atts, $content = true) {
   extract(shortcode_atts(array(
      "custom_class" => '',
   ), $atts));

   $result = '<div class="owl-carousel '. $custom_class .'" data-items="1" data-margin="0" data-loop="true" data-nav="true" data-dots="false" data-autoplay="true" data-auto-height="true">'. do_shortcode($content) .'</div>';
   return $result;

}
add_shortcode("fame_how_it_works", "fame_how_it_works_function");

/* How it Work */
function fame_how_it_work_function($atts, $content = NULL) {
   extract(shortcode_atts(array(
      "carousel_image" => '',
      "carousel_content" => '',
   ), $atts));

  $image = $carousel_image ? '<div class="fame-image"><img src="'.$carousel_image.'" alt="Fame"></div>' : '';

  $result = '<div class="item">'.$image.'<div class="work-process-info"><p>'.$carousel_content.'</p></div></div>';

   return $result;

}
add_shortcode("fame_how_it_work", "fame_how_it_work_function");

/* Footer Infos */
function fame_footer_infos_function($atts, $content = true) {
  extract(shortcode_atts(array(
    "custom_class" => '',
    "info_logo" => '',
    "logo_link" => '',
    "info_content" => '',
  ), $atts));

  $logo = $logo_link ? '<a href="'.$logo_link.'"><img src="'.$info_logo.'" width="143" alt="Fame"></a>' : '<img src="'.$info_logo.'" width="143" alt="Fame">';
  $info_content = $info_content ? '<p>'.$info_content.'</p>' : '';

  $result = '<div class="info-widget '. $custom_class .'">
              <div class="fame-logo">'.$logo.'</div>'.$info_content.'
              <div class="fame-btn-wrap">'. do_shortcode($content) .'</div>
            </div>';
  return $result;

}
add_shortcode("fame_footer_infos", "fame_footer_infos_function");

/* Footer Info */
function fame_footer_info_function($atts, $content = NULL) {
  extract(shortcode_atts(array(
    "btn_image" => '',
    "image_link" => '',
  ), $atts));

  $button = $image_link ? '<a href="'.$image_link.'"><img src="'.$btn_image.'" width="160" alt="App Store"></a>' : '<img src="'.$btn_image.'" width="160" alt="App Store">';

  return $button;

}
add_shortcode("fame_footer_info", "fame_footer_info_function");

/* Footer Menus */
function fame_footer_menus_function($atts, $content = true) {
   extract(shortcode_atts(array(
      "custom_class" => '',
   ), $atts));

   $result = '<ul class="'. $custom_class .'">'. do_shortcode($content) .'</ul>';
   return $result;

}
add_shortcode("fame_footer_menus", "fame_footer_menus_function");

/* Footer Menu */
function fame_footer_menu_function($atts, $content = NULL) {
   extract(shortcode_atts(array(
      "link_title" => '',
      "title" => '',
      "link" => '',
   ), $atts));
   $link_title = $link_title ? $link_title : '';
   $footer_link = $link ? '<li>'.$link_title.'<a href="'.$link.'">'.$title.'</a></li>' : '<li>'.$link_title.$title.'</li>';

   return $footer_link;

}
add_shortcode("fame_footer_menu", "fame_footer_menu_function");

/* Current Year - Shortcode */
if( ! function_exists( 'fame_current_year' ) ) {
  function fame_current_year() {
    return date('Y');
  }
  add_shortcode( 'fame_current_year', 'fame_current_year' );
}

/* Get Home Page URL - Via Shortcode */
if( ! function_exists( 'fame_home_url' ) ) {
  function fame_home_url() {
    return esc_url( home_url( '/' ) );
  }
  add_shortcode( 'fame_home_url', 'fame_home_url' );
}
