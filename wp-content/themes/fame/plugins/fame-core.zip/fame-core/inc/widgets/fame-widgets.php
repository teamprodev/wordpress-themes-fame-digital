<?php
/*
 * Text Widget
 * Author & Copyright: VictorThemes
 * URL: http://themeforest.net/user/VictorThemes
 */

// Control core classes for avoid errors
if( class_exists( 'CSF' ) ) {

  // Latest Posts Widget
  CSF::createWidget( 'fame_recent_posts', array(
    'title'       => VTHEME_NAME_P . __( ': Latest Posts Tab', 'fame' ),
    'classname'   => 'post-tab-widget',
    'description' => VTHEME_NAME_P . __( ' widget that displays posts tab.', 'fame' ),
    'fields'      => array(

      array(
        'id'            => 'post_tabs',
        'type'          => 'accordion',
        'title'         => esc_html__('Tabs', 'fame'),
        'accordions'    => array(

          array(
            'title'     => esc_html__('Latest', 'fame'),
            'fields'    => array(
              array(
                'id'      => 'tabone_title',
                'type'    => 'text',
                'title'   => __('Title', 'fame' ),
              ),
              array(
                'id'             => 'ptypes',
                'type'           => 'select',
                'options'        => 'post_types',
                'title'          => __( 'Post Type :', 'fame' ),
                'placeholder'    => __('Select Post Type', 'fame'),
              ),
              array(
                'id'            => 'limit',
                'type'          => 'spinner',
                'title'         => __( 'Webinars Limit', 'fame' ),
                'max'           => 100,
                'min'           => -1,
                'step'          => 1,
                'default'       => 5,
              ),
              array(
                'id'            => 'date',
                'type'          => 'switcher',
                'title'         => __( 'Display Date :', 'fame' ),
                'default'       => false,
              ),
              array(
                'id'    => 'category',
                'type'  => 'text',
                'title' => __( 'Category :', 'fame' ),
                'desc'  => __( 'Enter category slugs with comma(,) for multiple items', 'fame' ),
              ),
              array(
                'id'    => 'order',
                'type' => 'select',
                'options'   => array(
                  'ASC' => 'Ascending',
                  'DESC' => 'Descending',
                ),
                'placeholder' => __( 'Select Order', 'fame' ),
                'title' => __( 'Order :', 'fame' ),
              ),
              array(
                'id'    => 'orderby',
                'type' => 'select',
                'options'   => array(
                  'none' => __('None', 'fame'),
                  'ID' => __('ID', 'fame'),
                  'author' => __('Author', 'fame'),
                  'title' => __('Title', 'fame'),
                  'name' => __('Name', 'fame'),
                  'type' => __('Type', 'fame'),
                  'date' => __('Date', 'fame'),
                  'modified' => __('Modified', 'fame'),
                  'rand' => __('Random', 'fame'),
                ),
                'placeholder' => __( 'Select OrderBy', 'fame' ),
                'title' => __( 'OrderBy :', 'fame' ),
              ),

            )
          ),
          array(
            'title'     => esc_html__('Popular', 'fame'),
            'fields'    => array(

              array(
                'id'      => 'tabtwo_title',
                'type'    => 'text',
                'title'   => __('Title', 'fame' ),
              ),
              array(
                'id'             => 'ptypes_two',
                'type'           => 'select',
                'options'        => 'post_types',
                'title'          => __( 'Post Type :', 'fame' ),
                'placeholder'    => __('Select Post Type', 'fame'),
              ),
              array(
                'id'            => 'limit_two',
                'type'          => 'spinner',
                'title'         => __( 'Webinars Limit', 'fame' ),
                'max'           => 100,
                'min'           => -1,
                'step'          => 1,
                'default'       => 5,
              ),
              array(
                'id'            => 'date_two',
                'type'          => 'switcher',
                'title'         => __( 'Display Date :', 'fame' ),
                'default'       => false,
              ),
              array(
                'id'    => 'category_two',
                'type'  => 'text',
                'title' => __( 'Category :', 'fame' ),
                'desc'  => __( 'Enter category slugs with comma(,) for multiple items', 'fame' ),
              ),
              array(
                'id'    => 'order_two',
                'type' => 'select',
                'options'   => array(
                  'ASC' => 'Ascending',
                  'DESC' => 'Descending',
                ),
                'placeholder' => __( 'Select Order', 'fame' ),
                'title' => __( 'Order :', 'fame' ),
              ),
              array(
                'id'    => 'orderby_two',
                'type' => 'select',
                'options'   => array(
                  'none' => __('None', 'fame'),
                  'ID' => __('ID', 'fame'),
                  'author' => __('Author', 'fame'),
                  'title' => __('Title', 'fame'),
                  'name' => __('Name', 'fame'),
                  'type' => __('Type', 'fame'),
                  'date' => __('Date', 'fame'),
                  'modified' => __('Modified', 'fame'),
                  'rand' => __('Random', 'fame'),
                ),
                'placeholder' => __( 'Select OrderBy', 'fame' ),
                'title' => __( 'OrderBy :', 'fame' ),
              ),

            )
          ),
          array(
            'title'  => esc_html__('Most Viewed', 'fame'),
            'fields'    => array(

              array(
                'id'      => 'tabthree_title',
                'type'    => 'text',
                'title'   => __('Title', 'fame' ),
              ),
              array(
                'id'             => 'ptypes_three',
                'type'           => 'select',
                'options'        => 'post_types',
                'title'          => __( 'Post Type :', 'fame' ),
                'placeholder'    => __('Select Post Type', 'fame'),
              ),
              array(
                'id'            => 'limit_three',
                'type'          => 'spinner',
                'title'         => __( 'Webinars Limit', 'fame' ),
                'max'           => 100,
                'min'           => -1,
                'step'          => 1,
                'default'       => 5,
              ),
              array(
                'id'            => 'date_three',
                'type'          => 'switcher',
                'title'         => __( 'Display Date :', 'fame' ),
                'default'       => false,
              ),

            )
          ),

        )
      ),

    )
  ) );

  //
  // Front-end display of widget example 1
  // Attention: This function named considering above widget base id.
  //
  if( ! function_exists( 'fame_recent_posts' ) ) {
    function fame_recent_posts( $args, $instance ) {

      $tabone_title    = $instance['post_tabs']['tabone_title'];
      $tabtwo_title    = $instance['post_tabs']['tabtwo_title'];
      $tabthree_title  = $instance['post_tabs']['tabthree_title'];
      $ptypes          = $instance['post_tabs']['ptypes'];
      $ptypes_two      = $instance['post_tabs']['ptypes_two'];
      $ptypes_three    = $instance['post_tabs']['ptypes_three'];
      $limit           = $instance['post_tabs']['limit'];
      $limit_two       = $instance['post_tabs']['limit_two'];
      $limit_three     = $instance['post_tabs']['limit_three'];
      $date            = $instance['post_tabs']['date'];
      $date_two        = $instance['post_tabs']['date_two'];
      $date_three      = $instance['post_tabs']['date_three'];
      $category        = $instance['post_tabs']['category'];
      $category_two    = $instance['post_tabs']['category_two'];
      $order           = $instance['post_tabs']['order'];
      $order_two       = $instance['post_tabs']['order_two'];
      $orderby         = $instance['post_tabs']['orderby'];
      $orderby_two     = $instance['post_tabs']['orderby_two'];
      
      global $post;

      echo $args['before_widget']; ?>

      <div class="post-widget">

        <ul class="nav nav-tabs">
          <?php if ($tabone_title) { ?>
          <li><a class="nav-item nav-link active" data-toggle="tab" href="#latest"><?php echo esc_html($tabone_title); ?></a></li>
          <?php }
          if ($tabtwo_title) { ?>
          <li><a class="nav-item nav-link" data-toggle="tab" href="#popular"><?php echo esc_html($tabtwo_title); ?></a></li>
          <?php }
          if ($tabthree_title) { ?>
          <li><a class="nav-item nav-link" data-toggle="tab" href="#most-viewed"><?php echo esc_html($tabthree_title); ?></a></li>
          <?php } ?>
        </ul>
        
        <div class="tab-content">
          <?php 
          $latest_args = array(
            // other query params here,
            'post_type' => esc_attr($ptypes),
            'posts_per_page' => (int)$limit,
            'orderby' => esc_attr($orderby),
            'order' => esc_attr($order),
            'category_name' => esc_attr($category),
            'ignore_sticky_posts' => 1,
          );

          $fame_latest = new WP_Query( $latest_args );
          if ($fame_latest->have_posts()) :
          ?>
          <div class="tab-pane fade show active" id="latest">
            <?php while ($fame_latest->have_posts()) : $fame_latest->the_post(); 
              $latest_large_image =  wp_get_attachment_image_src( get_post_thumbnail_id(get_the_ID()), 'fullsize', false, '' );
              $latest_large_image = $latest_large_image[0];
              if(class_exists('Aq_Resize')) {
                $blog_img = aq_resize( $latest_large_image, '140', '140', true );
              } else {$blog_img = $latest_large_image;}
              $latest_featured_img = ( $blog_img ) ? $blog_img : $latest_large_image;
              if($latest_large_image) {
                $img_class = '';
              } else {
                $img_class = ' no-img';
              }
            ?>
            <div class="post-item<?php echo esc_attr($img_class); ?>">
              <?php if($latest_featured_img) { ?>
                <div class="fame-image">
                  <img src="<?php echo esc_url($latest_featured_img); ?>" alt="<?php the_title(); ?>">
                </div>
              <?php } ?>
              <div class="post-info">
                <h4 class="post-title"><a href="<?php esc_url(the_permalink()) ?>"><?php the_title(); ?></a></h4>
                <?php if ($date === '1') { ?>
                <h5 class="post-date"><?php echo get_the_date('M j, Y'); ?></h5>
                <?php } ?>
              </div>
            </div>
            <?php endwhile; ?>      
          </div>
          <?php endif;
          wp_reset_postdata();

          $popular_args = array(
            // other query params here,
            'post_type' => esc_attr($ptypes_two),
            'posts_per_page' => (int)$limit_two,
            'orderby' => esc_attr($orderby_two),
            'order' => esc_attr($order_two),
            'category_name' => esc_attr($category_two),
            'ignore_sticky_posts' => 1,
          );

          $fame_popular = new WP_Query( $popular_args );
          if ($fame_popular->have_posts()) :
          ?>
          <div class="tab-pane fade show" id="popular">
            <?php while ($fame_popular->have_posts()) : $fame_popular->the_post(); 
              $popular_large_image =  wp_get_attachment_image_src( get_post_thumbnail_id(get_the_ID()), 'fullsize', false, '' );
              $popular_large_image = $popular_large_image[0];
              if(class_exists('Aq_Resize')) {
                $blog_img = aq_resize( $popular_large_image, '140', '140', true );
              } else {$blog_img = $popular_large_image;}
              $popular_featured_img = ( $blog_img ) ? $blog_img : $popular_large_image;
              if($popular_large_image) {
                $img_class = '';
              } else {
                $img_class = ' no-img';
              }
            ?>
            <div class="post-item<?php echo esc_attr($img_class); ?>">
              <?php if($popular_featured_img) { ?>
                <div class="fame-image">
                  <img src="<?php echo esc_url($popular_featured_img); ?>" alt="<?php the_title(); ?>">
                </div>
              <?php } ?>
              <div class="post-info">
                <h4 class="post-title"><a href="<?php esc_url(the_permalink()) ?>"><?php the_title(); ?></a></h4>
                <?php if ($date_two === '1') { ?>
                <h5 class="post-date"><?php echo get_the_date('M j, Y'); ?></h5>
                <?php } ?>
              </div>
            </div>
            <?php endwhile; ?>      
          </div>
          <?php endif;
          wp_reset_postdata();

          $most_args = array(
            // other query params here,
            'post_type' => esc_attr($ptypes_three),
            'posts_per_page' => (int)$limit_three,
            'meta_key'     => 'post_views_count',
            'orderby'      => 'meta_value_num',
            'order'        => 'DESC',
          );

          $fame_most = new WP_Query( $most_args );
          if ($fame_most->have_posts()) :
          ?>
          <div class="tab-pane fade show" id="most-viewed">
            <?php while ($fame_most->have_posts()) : $fame_most->the_post(); 
              $most_large_image =  wp_get_attachment_image_src( get_post_thumbnail_id(get_the_ID()), 'fullsize', false, '' );
              $most_large_image = $most_large_image[0];
              if(class_exists('Aq_Resize')) {
                $blog_img = aq_resize( $most_large_image, '140', '140', true );
              } else {$blog_img = $most_large_image;}
              $most_featured_img = ( $blog_img ) ? $blog_img : $most_large_image;
              if($most_large_image) {
                $img_class = '';
              } else {
                $img_class = ' no-img';
              }
            ?>
            <div class="post-item<?php echo esc_attr($img_class); ?>">
              <?php if($most_featured_img) { ?>
                <div class="fame-image">
                  <img src="<?php echo esc_url($most_featured_img); ?>" alt="<?php the_title(); ?>">
                </div>
              <?php } ?>
              <div class="post-info">
                <h4 class="post-title"><a href="<?php esc_url(the_permalink()) ?>"><?php the_title(); ?></a></h4>
                <?php if ($date_three === '1') { ?>
                <h5 class="post-date"><?php echo get_the_date('M j, Y'); ?></h5>
                <?php } ?>
              </div>
            </div>
            <?php endwhile; ?>      
          </div>
          <?php endif;
          wp_reset_postdata(); ?>
          
        </div>
      </div>

      <?php echo $args['after_widget'];

    }
  }

}
