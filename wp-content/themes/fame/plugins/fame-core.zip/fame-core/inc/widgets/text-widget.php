<?php
/*
 * Text Widget
 * Author & Copyright: VictorThemes
 * URL: http://themeforest.net/user/VictorThemes
 */

// Control core classes for avoid errors
if( class_exists( 'CSF' ) ) {

  // Text Widget Widget
  CSF::createWidget( 'fame_text_widget', array(
    'title'       => VTHEME_NAME_P . __( ': Text Widget', 'fame' ),
    'classname'   => 'fame-text-widget',
    'description' => VTHEME_NAME_P . __( ' widget that displays contents.', 'fame' ),
    'fields'      => array(

      array(
        'id'      => 'title',
        'type'    => 'text',
        'title'   => __('Title', 'fame' ),
      ),      
      array(
        'id'      => 'content',
        'type'    => 'textarea',
        'title'   => __('Content :', 'fame' ),
        'desc'    => __( "Enter your shortcode.", 'fame'),
        'shortcoder'      => 'fame_vt_shortcodes',
        'attributes'    => array(
          'rows'        => 16,
          'cols'        => 20,
        ),
      ),      

    )
  ) );

  if( ! function_exists( 'fame_text_widget' ) ) {
    function fame_text_widget( $args, $instance ) {

      $title          = apply_filters( 'widget_title', $instance['title'] );
      $content        = $instance['content'];
      
      echo $args['before_widget'];

      if ( ! empty( $instance['title'] ) ) {
        echo $args['before_title'] . apply_filters( 'widget_title', $instance['title'] ) . $args['after_title'];
      }

      echo do_shortcode($content);

      echo $args['after_widget'];

    }
  }

}