<?php
/*
 * Elementor Fame Image Widget
 * Author & Copyright: VictorTheme
*/

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Fame_Image extends Widget_Base{

	/**
	 * Retrieve the widget name.
	*/
	public function get_name(){
		return 'vt-fame_image';
	}

	/**
	 * Retrieve the widget title.
	*/
	public function get_title(){
		return esc_html__( 'Image Animation', 'fame-core' );
	}

	/**
	 * Retrieve the widget icon.
	*/
	public function get_icon() {
		return 'fa fa-picture-o';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	*/
	public function get_categories() {
		return ['victortheme-category'];
	}

	/**
	 * Retrieve the list of scripts the Fame Image widget depended on.
	 * Used to set scripts dependencies required to run the widget.
	*/
	/*
	public function get_script_depends() {
		return ['vt-fame_image'];
	}
	*/
	
	/**
	 * Register Fame Image widget controls.
	 * Adds different input fields to allow the user to change and customize the widget settings.
	*/
	protected function _register_controls(){
		
		$this->start_controls_section(
			'section_image',
			[
				'label' => esc_html__( 'Image Options', 'fame-core' ),
			]
		);

		$this->add_control(
			'fame_image',
			[
				'label' => esc_html__( 'Upload Image', 'fame-core' ),
				'type' => Controls_Manager::MEDIA,
				'default' => [
					'url' => Utils::get_placeholder_image_src(),
				],
			]
		);
		$this->add_control(
			'fame_image_animation',
			[
				'label' => esc_html__( 'Animation', 'fame-core' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'fame-core' ),
				'label_off' => esc_html__( 'No', 'fame-core' ),
				'return_value' => 'true',
				'default' => 'true',
			]
		);
		$this->add_control(
			'img_max_width',
			[
				'label' => esc_html__( 'Disable Max Width', 'fame-core' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'fame-core' ),
				'label_off' => esc_html__( 'No', 'fame-core' ),
				'return_value' => 'true',
				'default' => 'false',
			]
		);
		$this->add_responsive_control(
			'custom_max_width',
			[
				'label' => esc_html__( 'Custom Max Width', 'fame-core' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1500,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'size_units' => [ 'px', '%' ],
				'selectors' => [
					'{{WRAPPER}} .fame-image img' => 'max-width: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'img_max_width' => 'true',
				],
			]
		);
		$this->add_responsive_control(
			'pulse_max_width',
			[
				'label' => esc_html__( 'Background Pulse Width', 'fame-core' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 1000,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'size_units' => [ 'px', '%' ],
				'selectors' => [
					'{{WRAPPER}} .fame-image-animation:before, {{WRAPPER}} .fame-image-animation:after, {{WRAPPER}} .fame-image-wrap:before' => 'width: {{SIZE}}{{UNIT}};height: {{SIZE}}{{UNIT}};',
				],
				'condition' => [
					'fame_image_animation' => 'true',
				],
			]
		);
		$this->add_control(
			'bg_color',
			[
				'label' => esc_html__( 'Background Pulse Color', 'fame-core' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .fame-image-animation:before, {{WRAPPER}} .fame-image-animation:after, {{WRAPPER}} .fame-image-wrap:before' => 'background-color: {{VALUE}};',
				],
				'condition' => [
					'fame_image_animation' => 'true',
				],
			]
		);	
	$this->end_controls_section();// end: Section

	}

	/**
	 * Render Image widget output on the frontend.
	 * Written in PHP and used to generate the final HTML.
	*/
	protected function render() {
		$settings = $this->get_settings_for_display();
		$fame_image = !empty( $settings['fame_image']['id'] ) ? $settings['fame_image']['id'] : '';
		$fame_image_animation  =  !empty( $settings['fame_image_animation'] ) ? $settings['fame_image_animation'] : '';
		$img_max_width  = !empty( $settings['img_max_width'] ) ? $settings['img_max_width'] : '';

		if($img_max_width === 'true') {
		  $max_width_cls = ' no-max-width';
		} else {
		  $max_width_cls = '';
		}

		if($fame_image_animation === 'true') {
		  $animate_cls = ' fame-image-animation';
		} else {
		  $animate_cls = ' fame-image-no-animation';
		}

		// Image
		$image_url = wp_get_attachment_url( $fame_image );
		if ($image_url) {
	  	$output = '<div class="fame-image'.$max_width_cls.$animate_cls.'">
	                <div class="fame-image-wrap"><img src="'.$image_url.'" alt="Fame"></div>
	              </div>';
		}

	  echo $output;
		
	}

	/**
	 * Render Image widget output in the editor.
	 * Written as a Backbone JavaScript template and used to generate the live preview.
	*/
	
	//protected function _content_template(){}
	
}
Plugin::instance()->widgets_manager->register_widget_type( new Fame_Image() );