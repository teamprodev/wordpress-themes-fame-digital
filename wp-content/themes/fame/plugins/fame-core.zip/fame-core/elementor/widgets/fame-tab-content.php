<?php
/*
 * Elementor Fame Tab Content Widget
 * Author & Copyright: VictorTheme
*/

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Fame_TabContent extends Widget_Base{

	/**
	 * Retrieve the widget name.
	*/
	public function get_name(){
		return 'vt-fame_tab_content';
	}

	/**
	 * Retrieve the widget title.
	*/
	public function get_title(){
		return esc_html__( 'Tab Content', 'fame-core' );
	}

	/**
	 * Retrieve the widget icon.
	*/
	public function get_icon() {
		return 'fa fa-bars';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	*/
	public function get_categories() {
		return ['victortheme-category'];
	}

	/**
	 * Retrieve the list of scripts the Fame Tab Content widget depended on.
	 * Used to set scripts dependencies required to run the widget.
	*/
	/*
	public function get_script_depends() {
		return ['vt-fame_tab_content'];
	}
	*/
	
	/**
	 * Register Fame Tab Content widget controls.
	 * Adds different input fields to allow the user to change and customize the widget settings.
	*/
	protected function _register_controls(){

		$this->start_controls_section(
			'section_active',
			[
				'label' => __( 'Tab Options', 'fame-core' ),
			]
		);
		$this->add_control(
			'left_info',
			[
				'type' => Controls_Manager::RAW_HTML,
				'raw' => '<div class="elementor-control-raw-html elementor-panel-alert elementor-panel-alert-warning"><b>Active number for Tab Title and Tab Content must be same.</b></div>',
			]
		);
		$this->add_control(
			'active',
			[
				'label' => __( 'Active Tab Number', 'fame-core' ),
				'type' => Controls_Manager::TEXT,
				'default' => 1,
			]
		);
		
		$this->end_controls_section();// end: Section

		$this->start_controls_section(
			'section_tab_content',
			[
				'label' => __( 'Tab Content Group', 'fame-core' ),
			]
		);		

		$repeater = new Repeater();
		$repeater->add_control(
			'left_info',
			[
				'type' => Controls_Manager::RAW_HTML,
				'raw' => '<div class="elementor-control-raw-html elementor-panel-alert elementor-panel-alert-warning"><b>Tab will Work depends on this Content ID field(Use ID in the order from Tab Title).</b></div>',
			]
		);
		$repeater->add_control(
			'tab_content_id',
			[
				'label' => esc_html__( 'Content ID', 'fame-core' ),
				'type' => Controls_Manager::TEXT,
				'placeholder' => esc_html__( 'Enter ID here', 'fame-core' ),
				'label_block' => true,
			]
		);
		
		$repeater->add_control(
			'group_tab_content',
			[
				'label' => esc_html__( 'Tab Content', 'fame-core' ),
				'type' => Controls_Manager::WYSIWYG,
				'rows' => 10,
				'placeholder' => esc_html__( 'Type content here', 'fame-core' ),
				'label_block' => true,
			]
		);
		$this->add_control(
			'content_groups',
			[
				'label' => esc_html__( 'Content Group', 'fame-core' ),
				'type' => Controls_Manager::REPEATER,
				'default' => [
					[
						'tab_content_id' => esc_html__( 'Content', 'fame-core' ),
					],
					
				],
				'fields' => $repeater->get_controls(),
				'title_field' => '{{{ tab_content_id }}}',
			]
		);
		
		$this->end_controls_section();// end: Section	

	}

	/**
	 * Render Tab Content widget output on the frontend.
	 * Written in PHP and used to generate the final HTML.
	*/
	protected function render() {
		// Tab Content query
		$settings = $this->get_settings_for_display();
		$active = !empty( $settings['active'] ) ? $settings['active'] : '';
		$content_groups = !empty( $settings['content_groups'] ) ? $settings['content_groups'] : '';

			$output = '<div class="tab-content">';
			if( !empty( $content_groups ) && is_array( $content_groups ) ){
      	$key = 1;
      	foreach ( $content_groups as $each_logo ) {
      		$tab_content_id = !empty( $each_logo['tab_content_id'] ) ? $each_logo['tab_content_id'] : '';
				  $content = !empty( $each_logo['group_tab_content'] ) ? $each_logo['group_tab_content'] : '';

					$id = sanitize_title($tab_content_id);
					$active_cls = ( $key == $active ) ? ' show active' : '';

					$output .= '<div class="tab-pane fade'.$active_cls.'" id="nav-'.$key.$id.'">'.do_shortcode($content).'</div>';
				$key++;
			  }
			}
			$output .= '</div>';
			echo $output;
		
	}

	/**
	 * Render Tab Content widget output in the editor.
	 * Written as a Backbone JavaScript template and used to generate the live preview.
	*/
	
	//protected function _content_template(){}
	
}
Plugin::instance()->widgets_manager->register_widget_type( new Fame_TabContent() );