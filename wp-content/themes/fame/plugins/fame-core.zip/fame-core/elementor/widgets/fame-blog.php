<?php
/*
 * Elementor Fame Blog Widget
 * Author & Copyright: VictorTheme
*/

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Fame_Blog extends Widget_Base{

	/**
	 * Retrieve the widget name.
	*/
	public function get_name(){
		return 'vt-fame_blog';
	}

	/**
	 * Retrieve the widget title.
	*/
	public function get_title(){
		return esc_html__( 'Blog', 'fame-core' );
	}

	/**
	 * Retrieve the widget icon.
	*/
	public function get_icon() {
		return 'fa fa-newspaper-o';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	*/
	public function get_categories() {
		return ['victortheme-category'];
	}

	/**
	 * Retrieve the list of scripts the Fame Blog widget depended on.
	 * Used to set scripts dependencies required to run the widget.
	*/
	/*
	public function get_script_depends() {
		return ['vt-fame_blog'];
	}
	 */
	
	/**
	 * Register Fame Blog widget controls.
	 * Adds different input fields to allow the user to change and customize the widget settings.
	*/
	protected function _register_controls(){

		$posts = get_posts( 'post_type="post"&numberposts=-1' );
    $PostID = array();
    if ( $posts ) {
      foreach ( $posts as $post ) {
        $PostID[ $post->ID ] = $post->ID;
      }
    } else {
      $PostID[ __( 'No ID\'s found', 'fame' ) ] = 0;
    }

    $this->start_controls_section(
			'section_blog_listing',
			[
				'label' => esc_html__( 'Listing Options', 'fame-core' ),
			]
		);
		$this->add_control(
			'blog_limit',
			[
				'label' => esc_html__( 'Blog Limit', 'fame-core' ),
				'type' => Controls_Manager::NUMBER,
				'min' => 1,
				'max' => 100,
				'step' => 1,
				'default' => 3,
				'description' => esc_html__( 'Enter the number of items to show.', 'fame-core' ),
			]
		);
		$this->add_control(
			'blog_order',
			[
				'label' => __( 'Order', 'fame-core' ),
				'type' => Controls_Manager::SELECT,
				'options' => [
					'ASC' => esc_html__( 'Asending', 'fame-core' ),
					'DESC' => esc_html__( 'Desending', 'fame-core' ),
				],
				'default' => 'DESC',
			]
		);
		$this->add_control(
			'blog_orderby',
			[
				'label' => __( 'Order By', 'fame-core' ),
				'type' => Controls_Manager::SELECT,
				'options' => [
					'none' => esc_html__( 'None', 'fame-core' ),
					'ID' => esc_html__( 'ID', 'fame-core' ),
					'author' => esc_html__( 'Author', 'fame-core' ),
					'title' => esc_html__( 'Title', 'fame-core' ),
					'date' => esc_html__( 'Date', 'fame-core' ),
				],
				'default' => 'date',
			]
		);
		$this->add_control(
			'blog_show_category',
			[
				'label' => __( 'Certain Categories?', 'fame-core' ),
				'type' => Controls_Manager::SELECT2,
				'default' => [],
				'options' => Controls_Helper_Output::get_terms_names( 'category'),
				'multiple' => true,
			]
		);
		$this->add_control(
			'blog_show_id',
			[
				'label' => __( 'Certain ID\'s?', 'fame-core' ),
				'type' => Controls_Manager::SELECT2,
				'default' => [],
				'options' => $PostID,
				'multiple' => true,
			]
		);
		$this->add_control(
			'short_content',
			[
				'label' => esc_html__( 'Excerpt Length', 'fame-core' ),
				'type' => Controls_Manager::NUMBER,
				'min' => 1,
				'step' => 1,
				'default' => 55,
				'description' => esc_html__( 'How many words you want in short content paragraph.', 'fame-core' ),
			]
		);
		$this->add_control(
			'blog_pagination',
			[
				'label' => esc_html__( 'Pagination', 'fame-core' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'fame-core' ),
				'label_off' => esc_html__( 'Hide', 'fame-core' ),
				'return_value' => 'true',
				'default' => 'true',
			]
		);		
		$this->add_control(
			'read_more_txt',
			[
				'label' => esc_html__( 'Read More Button Text', 'fame-core' ),
				'type' => Controls_Manager::TEXT,
				'label_block' => true,
				'default' => esc_html__( 'READ MORE', 'fame-core' ),
				'placeholder' => esc_html__( 'Type text here', 'fame-core' ),
			]
		);
		$this->end_controls_section();// end: Section
		
		$this->start_controls_section(
			'section_blog_metas',
			[
				'label' => esc_html__( 'Meta\'s Options', 'fame-core' ),
			]
		);
		$this->add_control(
			'blog_image',
			[
				'label' => esc_html__( 'Image', 'fame-core' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'fame-core' ),
				'label_off' => esc_html__( 'Hide', 'fame-core' ),
				'return_value' => 'true',
				'default' => 'true',
			]
		);
		$this->add_control(
			'blog_date',
			[
				'label' => esc_html__( 'Date', 'fame-core' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'fame-core' ),
				'label_off' => esc_html__( 'Hide', 'fame-core' ),
				'return_value' => 'true',
				'default' => 'true',
			]
		);
		$this->add_control(
			'blog_category',
			[
				'label' => esc_html__( 'Category', 'fame-core' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'fame-core' ),
				'label_off' => esc_html__( 'Hide', 'fame-core' ),
				'return_value' => 'true',
				'default' => 'true',
			]
		);
		$this->add_control(
			'blog_share',
			[
				'label' => esc_html__( 'Share', 'fame-core' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'fame-core' ),
				'label_off' => esc_html__( 'Hide', 'fame-core' ),
				'return_value' => 'true',
				'default' => 'true',
			]
		);
		$this->end_controls_section();// end: Section	
		
		$this->start_controls_section(
			'section_title_style',
			[
				'label' => esc_html__( 'Title', 'fame-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'sasblo_title_typography',
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .news-meta h3',
			]
		);
		$this->start_controls_tabs( 'title_style' );
			$this->start_controls_tab(
				'title_normal',
				[
					'label' => esc_html__( 'Normal', 'fame-core' ),
				]
			);
			$this->add_control(
				'title_color',
				[
					'label' => esc_html__( 'Color', 'fame-core' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .news-meta h3, {{WRAPPER}} .news-meta h3 a' => 'color: {{VALUE}};',
					],
				]
			);
			$this->end_controls_tab();  // end:Normal tab
			$this->start_controls_tab(
				'title_hover',
				[
					'label' => esc_html__( 'Hover', 'fame-core' ),
				]
			);
			$this->add_control(
				'title_hover_color',
				[
					'label' => esc_html__( 'Color', 'fame-core' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .news-meta h3 a:hover' => 'color: {{VALUE}};',
					],
				]
			);
			$this->end_controls_tab();  // end:Hover tab
		$this->end_controls_tabs(); // end tabs
		$this->end_controls_section();// end: Section
		
		$this->start_controls_section(
			'section_excerpt_style',
			[
				'label' => esc_html__( 'Excerpt', 'fame-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'excerpt_typography',
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .news-info p',
			]
		);
		$this->add_control(
			'excerpt_color',
			[
				'label' => esc_html__( 'Color', 'fame-core' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .news-info p' => 'color: {{VALUE}};',
				],
			]
		);
		$this->end_controls_section();// end: Section
		
		$this->start_controls_section(
			'section_metas_style',
			[
				'label' => esc_html__( 'Meta\'s', 'fame-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'date_options',
			[
				'label' => __( 'Date', 'fame-core' ),
				'type' => Controls_Manager::HEADING,
				'frontend_available' => true,
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'date_typography',
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'frontend_available' => true,
				'selector' => '{{WRAPPER}} .news-meta h5',
			]
		);
		$this->add_control(
			'date_color',
			[
				'label' => esc_html__( 'Color', 'fame-core' ),
				'type' => Controls_Manager::COLOR,
				'frontend_available' => true,
				'selectors' => [
					'{{WRAPPER}} .news-meta h5' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_control(
			'metas_options',
			[
				'label' => __( 'Categories', 'fame-core' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'metas_typography',
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .news-meta h5 a',
			]
		);
		$this->start_controls_tabs( 'metas_style' );
			$this->start_controls_tab(
				'metas_normal',
				[
					'label' => esc_html__( 'Normal', 'fame-core' ),
				]
			);
			$this->add_control(
				'metas_color',
				[
					'label' => esc_html__( 'Color', 'fame-core' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .news-meta h5 a' => 'color: {{VALUE}};',
					],
				]
			);			
			$this->end_controls_tab();  // end:Normal tab
			$this->start_controls_tab(
				'metas_hover',
				[
					'label' => esc_html__( 'Hover', 'fame-core' ),
				]
			);
			$this->add_control(
				'metas_hover_color',
				[
					'label' => esc_html__( 'Color', 'fame-core' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .news-meta h5 a:hover' => 'color: {{VALUE}};',
					],
				]
			);			
			$this->end_controls_tab();  // end:Normal tab
		$this->end_controls_tabs(); // end tabs

		$this->add_control(
			'author_options',
			[
				'label' => __( 'Share', 'fame-core' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);		
		$this->start_controls_tabs( 'share_style' );
			$this->start_controls_tab(
				'share_normal',
				[
					'label' => esc_html__( 'Normal', 'fame-core' ),
				]
			);
			$this->add_control(
				'share_color',
				[
					'label' => esc_html__( 'Color', 'fame-core' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .fame-social.rounded a, {{WRAPPER}} .fame-share-link > a' => 'color: {{VALUE}};',
					],
				]
			);
			$this->add_control(
				'share_bg_color',
				[
					'label' => esc_html__( 'Background Color', 'fame-core' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .fame-social.rounded a, {{WRAPPER}} .fame-share-link > a' => 'background-color: {{VALUE}};',
					],
				]
			);
			$this->add_control(
				'share_border_color',
				[
					'label' => esc_html__( 'Border Color', 'fame-core' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .fame-social.rounded a, {{WRAPPER}} .fame-share-link > a' => 'border-color: {{VALUE}};',
					],
				]
			);
			$this->end_controls_tab();  // end:Normal tab
			$this->start_controls_tab(
				'share_hover',
				[
					'label' => esc_html__( 'Hover', 'fame-core' ),
				]
			);
			$this->add_control(
				'share_hover_color',
				[
					'label' => esc_html__( 'Color', 'fame-core' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .fame-social.rounded a:hover, {{WRAPPER}} .fame-share-link > a:hover' => 'color: {{VALUE}};',
					],
				]
			);
			$this->add_control(
				'share_bg_hover_color',
				[
					'label' => esc_html__( 'Background Color', 'fame-core' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .fame-social.rounded a:hover, {{WRAPPER}} .fame-share-link > a:hover' => 'background-color: {{VALUE}};',
					],
				]
			);
			$this->add_control(
				'share_border_hover_color',
				[
					'label' => esc_html__( 'Border Color', 'fame-core' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .fame-social.rounded a:hover, {{WRAPPER}} .fame-share-link > a:hover' => 'border-color: {{VALUE}};',
					],
				]
			);
			$this->end_controls_tab();  // end:Normal tab
		$this->end_controls_tabs(); // end tabs

		$this->add_control(
			'rmore_options',
			[
				'label' => __( 'Read More', 'fame-core' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'rmore_typography',
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .fame-link a',
			]
		);
		$this->start_controls_tabs( 'rmore_style' );
			$this->start_controls_tab(
				'rmore_normal',
				[
					'label' => esc_html__( 'Normal', 'fame-core' ),
				]
			);
			$this->add_control(
				'rmore_color',
				[
					'label' => esc_html__( 'Color', 'fame-core' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .fame-link a' => 'color: {{VALUE}};',
					],
				]
			);			
			$this->end_controls_tab();  // end:Normal tab
			$this->start_controls_tab(
				'rmore_hover',
				[
					'label' => esc_html__( 'Hover', 'fame-core' ),
				]
			);
			$this->add_control(
				'rmore_hover_color',
				[
					'label' => esc_html__( 'Color', 'fame-core' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .fame-link a:hover' => 'color: {{VALUE}};',
					],
				]
			);			
			$this->end_controls_tab();  // end:Normal tab
		$this->end_controls_tabs(); // end tabs
		
		$this->end_controls_section();// end: Section
		
	}

	/**
	 * Render Blog widget output on the frontend.
	 * Written in PHP and used to generate the final HTML.
	*/
	protected function render() {
		$settings = $this->get_settings_for_display();
		$blog_image  = ( isset( $settings['blog_image'] ) && ( 'true' == $settings['blog_image'] ) ) ? true : false;
		$blog_date  = ( isset( $settings['blog_date'] ) && ( 'true' == $settings['blog_date'] ) ) ? true : false;
		$blog_category  = ( isset( $settings['blog_category'] ) && ( 'true' == $settings['blog_category'] ) ) ? true : false;
		$blog_share  = ( isset( $settings['blog_share'] ) && ( 'true' == $settings['blog_share'] ) ) ? true : false;

		$blog_limit = !empty( $settings['blog_limit'] ) ? $settings['blog_limit'] : '';
		$blog_order = !empty( $settings['blog_order'] ) ? $settings['blog_order'] : '';
		$blog_orderby = !empty( $settings['blog_orderby'] ) ? $settings['blog_orderby'] : '';
		$blog_show_category = !empty( $settings['blog_show_category'] ) ? $settings['blog_show_category'] : [];
		$blog_show_id = !empty( $settings['blog_show_id'] ) ? $settings['blog_show_id'] : [];
		$short_content = !empty( $settings['short_content'] ) ? $settings['short_content'] : '';
		$blog_pagination  = ( isset( $settings['blog_pagination'] ) && ( 'true' == $settings['blog_pagination'] ) ) ? true : false;
		$read_more_txt = !empty( $settings['read_more_txt'] ) ? $settings['read_more_txt'] : '';

		// Excerpt
		if (fame_framework_active()) {
		  $excerpt_length = cs_get_option('theme_blog_excerpt');
		  $excerpt_length = $excerpt_length ? $excerpt_length : '55';
		  if ($short_content) {
			$short_content = $short_content;
		  } else {
			$short_content = $excerpt_length;
		  }
		} else {
		  $short_content = '55';
		}

		// Read More Text
		if (fame_framework_active()) {
		  $read_more_to = cs_get_option('read_more_text');
		  if ($read_more_txt) {
			$read_more_txt = $read_more_txt;
		  } elseif($read_more_to) {
			$read_more_txt = $read_more_to;
		  } else {
			$read_more_txt = esc_html__( 'READ MORE', 'fame-core' );
		  }
		} else {
		  $read_more_txt = $read_more_txt ? $read_more_txt : esc_html__( 'READ MORE', 'fame-core' );
		}

		// Turn output buffer on
		ob_start();

		// Pagination
		global $paged;
		if( get_query_var( 'paged' ) )
		  $my_page = get_query_var( 'paged' );
		else {
		  if( get_query_var( 'page' ) )
			$my_page = get_query_var( 'page' );
		  else
			$my_page = 1;
		  set_query_var( 'paged', $my_page );
		  $paged = $my_page;
		}

    if ($blog_show_id) {
			$blog_show_id = json_encode( $blog_show_id );
			$blog_show_id = str_replace(array( '[', ']' ), '', $blog_show_id);
			$blog_show_id = str_replace(array( '"', '"' ), '', $blog_show_id);
      $blog_show_id = explode(',',$blog_show_id);
    } else {
      $blog_show_id = '';
    }

		$args = array(
		  // other query params here,
		  'paged' => $my_page,
		  'post_type' => 'post',
		  'posts_per_page' => (int)$blog_limit,
		  'category_name' => implode(',', $blog_show_category),
		  'orderby' => $blog_orderby,
		  'order' => $blog_order,
      'post__in' => $blog_show_id,
		);

		$fame_post = new \WP_Query( $args ); ?>

		<div class="news-items-wrap">
			<?php 
			// Metabox

		  if ($fame_post->have_posts()) : while ($fame_post->have_posts()) : $fame_post->the_post();

			global $post;
			$fame_id    = ( isset( $post ) ) ? $post->ID : 0;
			$fame_meta  = get_post_meta( $fame_id, 'post_type_metabox', true );
		  $large_image =  wp_get_attachment_image_src( get_post_thumbnail_id(get_the_ID()), 'fullsize', false, '' );
		  $large_image = $large_image[0]; 

			$date_format = cs_get_option('blog_date_format');
			$date_format_actual = $date_format ? $date_format : '';

		  ?>
			<div class="news-item">
				<?php if(get_post_format() === 'quote') {
					if ($fame_meta) {
						$quote_text = $fame_meta['quote_text'];
						$quote_author = $fame_meta['quote_author'];
						$quote_author_link = $fame_meta['quote_author_link'];
					} else {
						$quote_text = '';
						$quote_author = '';
						$quote_author_link = '';
					} 
					if ($quote_text) {
					?>
						<blockquote class="blockquote-style-two">
			        <p><?php echo esc_html($quote_text); ?><span class="quote-icon"></span></p>
			        <?php if ($quote_author) { ?><cite><?php if ($quote_author_link) { ?><a href="<?php echo esc_url( $quote_author_link ); ?>"><?php echo esc_attr($quote_author); ?></a><?php } else { ?><?php echo esc_attr($quote_author); ?><?php } ?></cite><?php } ?>
			      </blockquote>
				  <?php } 
				} else {
				  if ($large_image && $blog_image) { ?>
					  <div class="fame-image">
					    <a href="<?php echo esc_url( get_permalink() ); ?>"><img src="<?php echo esc_url($large_image); ?>" alt="<?php echo esc_attr(get_the_title()); ?>"></a>
					  </div>
					<?php } 
				} ?>
			  <div class="news-info">
			    <div class="news-meta">
			      <div class="row">
			        <div class="col-md-8">
			        	<?php if ( $blog_date || $blog_category ) { ?>
			        	<h5 class="news-date">
			        		<?php if ( $blog_date ) { echo get_the_date($date_format_actual); }
			        		if ( $blog_category ) {
							    $categories = get_the_category();
					        foreach ( $categories as $category ) : ?>
					          <a href="<?php echo esc_url( get_category_link( $category->term_id ) ); ?>"><?php echo esc_html( $category->name ); ?></a>
					        <?php endforeach; } ?>
			        	</h5>
				        <?php } ?>
			          <h3 class="news-title"><a href="<?php echo esc_url( get_permalink() ); ?>"><?php echo esc_html(get_the_title()); ?></a></h3>
			        </div>
			        <div class="col-md-4 text-right">
			        	<?php if ( function_exists( 'fame_post_share_option' ) && $blog_share ) {	echo fame_post_share_option(); } ?>
			        </div>
			      </div>
			    </div>
			    <?php
						echo '<p>';
						fame_excerpt($short_content);
						echo '</p>';
						echo fame_wp_link_pages();
					?>
			    <div class="fame-link">
			      <a href="<?php echo esc_url( get_permalink() ); ?>"><?php echo esc_html($read_more_txt); ?> <img src="<?php echo esc_url( FAME_PLUGIN_ASTS . '/images/icons/icon53@2x.png' ); ?>" alt="<?php echo esc_attr($read_more_txt); ?>" width="18"></a>
			    </div>
			  </div>
			</div>

		  <?php
		  endwhile;
		  endif;
		  wp_reset_postdata();
			if ($blog_pagination) { fame_paging_nav($fame_post->max_num_pages,"",$paged); } ?>
		</div>
		<?php
		// Return outbut buffer
		echo ob_get_clean();
		
	}

	/**
	 * Render Blog widget output in the editor.
	 * Written as a Backbone JavaScript template and used to generate the live preview.
	*/

	//protected function _content_template(){}
	
}
Plugin::instance()->widgets_manager->register_widget_type( new Fame_Blog() );