<?php
/*
 * Elementor Fame Branches Widget
 * Author & Copyright: VictorTheme
*/

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Fame_Branches extends Widget_Base{

	/**
	 * Retrieve the widget name.
	*/
	public function get_name(){
		return 'vt-fame_branch';
	}

	/**
	 * Retrieve the widget title.
	*/
	public function get_title(){
		return esc_html__( 'Branches', 'fame-core' );
	}

	/**
	 * Retrieve the widget icon.
	*/
	public function get_icon() {
		return 'fa fa-sitemap';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	*/
	public function get_categories() {
		return ['victortheme-category'];
	}

	/**
	 * Retrieve the list of scripts the Fame Branches widget depended on.
	 * Used to set scripts dependencies required to run the widget.
	*/
	/*
	public function get_script_depends() {
		return ['vt-fame_branch'];
	}
	*/
	
	/**
	 * Register Fame Branches widget controls.
	 * Adds different input fields to allow the user to change and customize the widget settings.
	*/
	protected function _register_controls(){
		
		$this->start_controls_section(
			'section_branch',
			[
				'label' => __( 'Branches Item', 'fame-core' ),
			]
		);

		$repeater = new Repeater();
		$repeater->add_control(
			'branch_image',
			[
				'label' => esc_html__( 'Upload Icon', 'fame-core' ),
				'type' => Controls_Manager::MEDIA,
				'frontend_available' => true,
				'default' => [
					'url' => Utils::get_placeholder_image_src(),
				],
				'description' => esc_html__( 'Set your icon image.', 'fame-core'),
			]
		);
		$repeater->add_control(
			'branch_title',
			[
				'label' => esc_html__( 'Title', 'fame-core' ),
				'type' => Controls_Manager::TEXT,
				'default' => esc_html__( 'Australia', 'fame-core' ),
				'placeholder' => esc_html__( 'Type title text here', 'fame-core' ),
				'label_block' => true,
			]
		);
		$repeater->add_control(
			'branch_title_link',
			[
				'label' => esc_html__( 'Link', 'fame-core' ),
				'type' => Controls_Manager::URL,
				'placeholder' => 'https://your-link.com',
				'default' => [
					'url' => '',
				],
				'label_block' => true,
			]
		);
		$repeater->add_control(
			'branch_position',
			[
				'label' => esc_html__( 'Positions', 'fame-core' ),
				'default' => esc_html__( '08 Positions', 'fame-core' ),
				'placeholder' => esc_html__( 'Type your content here', 'fame-core' ),
				'type' => Controls_Manager::TEXTAREA,
				'label_block' => true,
			]
		);
		$this->add_control(
			'branch_groups',
			[
				'label' => esc_html__( 'Branches Items', 'fame-core' ),
				'type' => Controls_Manager::REPEATER,
				'default' => [
					[
						'branch_title' => esc_html__( 'Australia', 'fame-core' ),
						'branch_position' => esc_html__( '08 Positions', 'fame-core' ),
					],
					
				],
				'fields' => $repeater->get_controls(),
				'title_field' => '{{{ branch_title }}}',
			]
		);
		
		$this->end_controls_section();// end: Section

		$this->start_controls_section(
			'number_style',
			[
				'label' => esc_html__( 'Number', 'fame-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'label' => esc_html__( 'Typography', 'fame-core' ),
				'name' => 'number_typography',
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .branch-item h2',
			]
		);
		$this->add_control(
			'number_color',
			[
				'label' => esc_html__( 'Color', 'fame-core' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .branch-item h2' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'number_bg_color',
			[
				'label' => esc_html__( 'Background Shape Color', 'fame-core' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .branch-counter span, {{WRAPPER}} .branch-counter span:before, {{WRAPPER}} .branch-counter span:after' => 'background: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();// end: Section

		// Title
		$this->start_controls_section(
			'section_title_style',
			[
				'label' => esc_html__( 'Title', 'fame-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'label' => esc_html__( 'Typography', 'fame-core' ),
					'name' => 'sastool_title_typography',
					'scheme' => Scheme_Typography::TYPOGRAPHY_1,
					'selector' => '{{WRAPPER}} .branch-item h3',
				]
			);
			$this->start_controls_tabs( 'branch_title_style' );
				$this->start_controls_tab(
					'title_normal',
					[
						'label' => esc_html__( 'Normal', 'fame-core' ),
					]
				);
				$this->add_control(
					'title_color',
					[
						'label' => esc_html__( 'Color', 'fame-core' ),
						'type' => Controls_Manager::COLOR,
						'selectors' => [
							'{{WRAPPER}} .branch-item h3, {{WRAPPER}} .branch-item h3 a' => 'color: {{VALUE}};',
						],
					]
				);
				$this->end_controls_tab();  // end:Normal tab
				
				$this->start_controls_tab(
					'title_hover',
					[
						'label' => esc_html__( 'Hover', 'fame-core' ),
					]
				);
				$this->add_control(
					'title_hov_color',
					[
						'label' => esc_html__( 'Color', 'fame-core' ),
						'type' => Controls_Manager::COLOR,
						'selectors' => [
							'{{WRAPPER}} .branch-item h3 a:hover' => 'color: {{VALUE}};',
						],
					]
				);
				$this->end_controls_tab();  // end:Hover tab
			$this->end_controls_tabs(); // end tabs
		$this->end_controls_section();// end: Section
		
		$this->start_controls_section(
			'section_content_style',
			[
				'label' => esc_html__( 'Content', 'fame-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'label' => esc_html__( 'Typography', 'fame-core' ),
					'name' => 'content_typography',
					'scheme' => Scheme_Typography::TYPOGRAPHY_1,
					'selector' => '{{WRAPPER}} .branch-item p',
				]
			);
			$this->add_control(
				'content_color',
				[
					'label' => esc_html__( 'Color', 'fame-core' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .branch-item p' => 'color: {{VALUE}};',
					],
				]
			);
		$this->end_controls_section();// end: Section
		
	}

	/**
	 * Render Branches widget output on the frontend.
	 * Written in PHP and used to generate the final HTML.
	*/
	protected function render() {
		// Branches query
		$settings = $this->get_settings_for_display();
		$branch = $this->get_settings_for_display( 'branch_groups' );

		$output = '';

		if( !empty( $branch ) && is_array( $branch ) ){
		$output .= '<div class="fame-locations"><div class="row justify-content-center">';	

			// Group Param Output
			foreach ( $branch as $each_logo ) {
				$image_url = wp_get_attachment_url( $each_logo['branch_image']['id'] );
				$branch_title_link = !empty( $each_logo['branch_title_link'] ) ? $each_logo['branch_title_link'] : '';
				$link_url = !empty( $branch_title_link['url'] ) ? esc_url($branch_title_link['url']) : '';
				$link_external = !empty( $branch_title_link['is_external'] ) ? 'target="_blank"' : '';
				$link_nofollow = !empty( $branch_title_link['nofollow'] ) ? 'rel="nofollow"' : '';
				$link_attr = !empty( $branch_title_link['url'] ) ?  $link_external.' '.$link_nofollow : '';

				$image = !empty( $image_url ) ? '<div class="fame-icon"><img src="'.$image_url.'" width="60" alt="Branch"></div>' : '';
			  $title_link = !empty( $link_url ) ? '<a href="'.$link_url.'" '.$link_attr.'>'.$each_logo['branch_title'].'</a>' : $each_logo['branch_title'];
		  	$title = !empty( $each_logo['branch_title'] ) ? '<h3 class="branch-title">'.$title_link.'</h3>' : '';
			  $content = !empty( $each_logo['branch_position'] ) ? '<p>'.$each_logo['branch_position'].'</p>' : '';

			  $output .= '<div class="col-custom-lo"><div class="branch-item fame-item">'.$image.$title.$content.'</div></div>';
			}

		$output .= '</div></div>';
		}
		echo $output;
		
	}

	/**
	 * Render Branches widget output in the editor.
	 * Written as a Backbone JavaScript template and used to generate the live preview.
	*/
	
	//protected function _content_template(){}
	
}
Plugin::instance()->widgets_manager->register_widget_type( new Fame_Branches() );