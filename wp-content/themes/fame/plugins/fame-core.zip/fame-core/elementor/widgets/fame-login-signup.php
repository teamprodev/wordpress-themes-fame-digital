<?php
/*
 * Elementor Fame Login Signup Widget
 * Author & Copyright: VictorTheme
*/

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Fame_LoginSignup extends Widget_Base{

	/**
	 * Retrieve the widget name.
	*/
	public function get_name(){
		return 'vt-fame_login_signup';
	}

	/**
	 * Retrieve the widget title.
	*/
	public function get_title(){
		return esc_html__( 'Login Signup', 'fame-core' );
	}

	/**
	 * Retrieve the widget icon.
	*/
	public function get_icon() {
		return 'fa fa-user';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	*/
	public function get_categories() {
		return ['victortheme-category'];
	}

	/**
	 * Retrieve the list of scripts the Fame Login Signup widget depended on.
	 * Used to set scripts dependencies required to run the widget.
	*/
	/*
	public function get_script_depends() {
		return ['vt-fame_login_signup'];
	}
	*/

	/**
	 * Register Fame Login Signup widget controls.
	 * Adds different input fields to allow the user to change and customize the widget settings.
	*/
	protected function _register_controls(){

		$this->start_controls_section(
			'section_login_signup',
			[
				'label' => esc_html__( 'Options', 'fame-core' ),
			]
		);
		$this->add_control(
			'form_type',
			[
				'label' => esc_html__( 'Select Form', 'fame-core' ),
				'type' => Controls_Manager::SELECT,
				'options' => [
					'login' => esc_html__( 'Login Form', 'fame-core' ),
					'signup' => esc_html__( 'Signup Form', 'fame-core' ),
				],
				'default' => 'login',
				'description' => esc_html__( 'Select your list column.', 'fame-core' ),
			]
		);
		$this->add_control(
			'form_title',
			[
				'label' => esc_html__( 'Form Title', 'fame-core' ),
				'type' => Controls_Manager::TEXT,
				'frontend_available' => true,
				'label_block' => true,
				'default' => esc_html__( 'Default title', 'fame-core' ),
				'placeholder' => esc_html__( 'Type your title here', 'fame-core' ),
			]
		);
		$this->add_control(
			'form_sub_title',
			[
				'label' => esc_html__( 'Form Sub-Title', 'fame-core' ),
				'type' => Controls_Manager::TEXTAREA,
				'frontend_available' => true,
				'label_block' => true,
				'rows' => 5,
				'default' => __( 'Subtitle Text', 'fame-core' ),
				'placeholder' => esc_html__( 'Enter your Subtitle text here.', 'fame-core' ),
			]
		);

		$this->end_controls_section();// end: Section

		$this->start_controls_section(
			'section_title_style',
			[
				'label' => esc_html__( 'Title', 'fame-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'saslog_title_typography',
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .fame-login-signup .section-title',
			]
		);
		$this->add_control(
			'title_color',
			[
				'label' => esc_html__( 'Color', 'fame-core' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .fame-login-signup .section-title' => 'color: {{VALUE}};',
				],
			]
		);
		$this->end_controls_section();// end: Section

		$this->start_controls_section(
			'section_sub_title_style',
			[
				'label' => esc_html__( 'Sub-Title', 'fame-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'saslog_sub_title_typography',
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .fame-login-signup .section-subtitle',
			]
		);
		$this->add_control(
			'sub_title_color',
			[
				'label' => esc_html__( 'Color', 'fame-core' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .fame-login-signup .section-subtitle' => 'color: {{VALUE}};',
				],
			]
		);
		$this->end_controls_section();// end: Section

		$this->start_controls_section(
			'section_label_style',
			[
				'label' => esc_html__( 'Label', 'fame-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'label_typography',
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .fame-login-signup label',
			]
		);
		$this->add_control(
			'label_color',
			[
				'label' => esc_html__( 'Color', 'fame-core' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .fame-login-signup label' => 'color: {{VALUE}};',
				],
			]
		);
		$this->end_controls_section();// end: Section

		$this->start_controls_section(
			'section_form_style',
			[
				'label' => esc_html__( 'Form', 'fame-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'form_typography',
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .fame-login-signup input[type="text"],
					{{WRAPPER}} .fame-login-signup input[type="email"],
					{{WRAPPER}} .fame-login-signup input[type="password"],
					{{WRAPPER}} .fame-login-signup input[type="date"],
					{{WRAPPER}} .fame-login-signup input[type="time"],
					{{WRAPPER}} .fame-login-signup input[type="number"],
					{{WRAPPER}} .fame-login-signup textarea,
					{{WRAPPER}} .fame-login-signup select,
					{{WRAPPER}} .fame-login-signup .form-control,
					{{WRAPPER}} .fame-login-signup .nice-select,
					.trial-form form input',
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'form_border',
				'label' => esc_html__( 'Border', 'fame-core' ),
				'selector' => '{{WRAPPER}} .fame-login-signup input[type="text"],
					{{WRAPPER}} .fame-login-signup input[type="email"],
					{{WRAPPER}} .fame-login-signup input[type="password"],
					{{WRAPPER}} .fame-login-signup input[type="date"],
					{{WRAPPER}} .fame-login-signup input[type="time"],
					{{WRAPPER}} .fame-login-signup input[type="number"],
					{{WRAPPER}} .fame-login-signup textarea,
					{{WRAPPER}} .fame-login-signup select,
					{{WRAPPER}} .fame-login-signup .form-control,
					{{WRAPPER}} .fame-login-signup .nice-select,
					.trial-form form input',
			]
		);
		$this->add_control(
			'placeholder_text_color',
			[
				'label' => __( 'Placeholder Text Color', 'fame-core' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .fame-login-signup input:not([type="submit"])::-webkit-input-placeholder' => 'color: {{VALUE}} !important;',
					'{{WRAPPER}} .fame-login-signup input:not([type="submit"])::-moz-placeholder' => 'color: {{VALUE}} !important;',
					'{{WRAPPER}} .fame-login-signup input:not([type="submit"])::-ms-input-placeholder' => 'color: {{VALUE}} !important;',
					'{{WRAPPER}} .fame-login-signup input:not([type="submit"])::-o-placeholder' => 'color: {{VALUE}} !important;',
					'{{WRAPPER}} .trial-form form input:not([type="submit"])::-o-placeholder' => 'color: {{VALUE}} !important;',
					'{{WRAPPER}} .fame-login-signup textarea::-webkit-input-placeholder' => 'color: {{VALUE}} !important;',
					'{{WRAPPER}} .fame-login-signup textarea::-moz-placeholder' => 'color: {{VALUE}} !important;',
					'{{WRAPPER}} .fame-login-signup textarea::-ms-input-placeholder' => 'color: {{VALUE}} !important;',
					'{{WRAPPER}} .fame-login-signup textarea::-o-placeholder' => 'color: {{VALUE}} !important;',
				],
			]
		);
		$this->add_control(
			'text_color',
			[
				'label' => __( 'Text Color', 'fame-core' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .fame-login-signup input[type="text"],
					{{WRAPPER}} .fame-login-signup input[type="email"],
					{{WRAPPER}} .fame-login-signup input[type="password"],
					{{WRAPPER}} .fame-login-signup input[type="date"],
					{{WRAPPER}} .fame-login-signup input[type="time"],
					{{WRAPPER}} .fame-login-signup input[type="number"],
					{{WRAPPER}} .fame-login-signup textarea,
					{{WRAPPER}} .fame-login-signup select,
					{{WRAPPER}} .fame-login-signup .form-control,
					{{WRAPPER}} .fame-login-signup .nice-select,
					.trial-form form input' => 'color: {{VALUE}} !important;',
				],
			]
		);
		$this->end_controls_section();// end: Section

		$this->start_controls_section(
			'section_aftr_text_style',
			[
				'label' => esc_html__( 'Form After Text', 'fame-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'sub_aftr_text_typography',
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .fame-login-signup .getstart-rules,
				{{WRAPPER}} .fame-login-signup .create-account-link',
			]
		);
		$this->add_control(
			'sub_aftr_text_color',
			[
				'label' => esc_html__( 'Color', 'fame-core' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .fame-login-signup .getstart-rules,
					{{WRAPPER}} .fame-login-signup .create-account-link' => 'color: {{VALUE}};',
				],
			]
		);
		$this->end_controls_section();// end: Section

		$this->start_controls_section(
			'section_aftr_link_style',
			[
				'label' => esc_html__( 'Form After Link', 'fame-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'sub_aftr_link_typography',
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .fame-login-signup .getstart-rules a',
			]
		);
		$this->start_controls_tabs( 'aftr_link_style' );
			$this->start_controls_tab(
				'aftr_link_normal',
				[
					'label' => esc_html__( 'Normal', 'fame-core' ),
				]
			);
			$this->add_control(
				'aftr_link_color',
				[
					'label' => esc_html__( 'Color', 'fame-core' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .fame-login-signup .getstart-rules a,
						{{WRAPPER}} .fame-login-signup .create-account-link a' => 'color: {{VALUE}};',
					],
				]
			);
			$this->end_controls_tab();  // end:Normal tab
			$this->start_controls_tab(
				'aftr_link_hover_normal',
				[
					'label' => esc_html__( 'Hover', 'fame-core' ),
				]
			);
			$this->add_control(
				'aftr_link_hover_color',
				[
					'label' => esc_html__( 'Color', 'fame-core' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .fame-login-signup .getstart-rules a:hover,
						{{WRAPPER}} .fame-login-signup .create-account-link a:hover' => 'color: {{VALUE}};',
						'{{WRAPPER}} .fame-login-signup .getstart-rules a:after,
						{{WRAPPER}} .fame-login-signup .create-account-link a:after' => 'background: {{VALUE}};',
					],
				]
			);
			$this->end_controls_tab();  // end:Hover tab
		$this->end_controls_tabs(); // end tabs
		$this->end_controls_section();// end: Section


		$this->start_controls_section(
			'section_button_style',
			[
				'label' => esc_html__( 'Button', 'fame-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'button_typography',
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .fame-login-signup input[type="submit"], {{WRAPPER}} .trial-form form input[type="submit"]',
			]
		);
		$this->add_control(
			'button_border_radius',
			[
				'label' => __( 'Border Radius', 'fame-core' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .fame-login-signup input[type="submit"], {{WRAPPER}} .trial-form form input[type="submit"]' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->start_controls_tabs( 'button_style' );
			$this->start_controls_tab(
				'button_normal',
				[
					'label' => esc_html__( 'Normal', 'fame-core' ),
				]
			);
			$this->add_control(
				'button_color',
				[
					'label' => esc_html__( 'Color', 'fame-core' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .fame-login-signup input[type="submit"], {{WRAPPER}} .trial-form form input[type="submit"]' => 'color: {{VALUE}};',
					],
				]
			);
			$this->add_control(
				'button_bg_color',
				[
					'label' => esc_html__( 'Background Color', 'fame-core' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .fame-login-signup input[type="submit"], {{WRAPPER}} .trial-form form input[type="submit"]' => 'background-color: {{VALUE}};',
					],
				]
			);
			$this->add_group_control(
				Group_Control_Border::get_type(),
				[
					'name' => 'button_border',
					'label' => esc_html__( 'Border', 'fame-core' ),
					'selector' => '{{WRAPPER}} .fame-login-signup input[type="submit"], {{WRAPPER}} .trial-form form input[type="submit"]',
				]
			);
			$this->end_controls_tab();  // end:Normal tab

			$this->start_controls_tab(
				'button_hover',
				[
					'label' => esc_html__( 'Hover', 'fame-core' ),
				]
			);
			$this->add_control(
				'button_hover_color',
				[
					'label' => esc_html__( 'Color', 'fame-core' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .fame-login-signup input[type="submit"]:hover, {{WRAPPER}} .trial-form form input[type="submit"]:hover' => 'color: {{VALUE}};',
					],
				]
			);
			$this->add_control(
				'button_bg_hover_color',
				[
					'label' => esc_html__( 'Background Color', 'fame-core' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .fame-login-signup input[type="submit"]:hover, {{WRAPPER}} .trial-form form input[type="submit"]:hover' => 'background-color: {{VALUE}};',
					],
				]
			);
			$this->add_group_control(
				Group_Control_Border::get_type(),
				[
					'name' => 'button_hover_border',
					'label' => esc_html__( 'Border', 'fame-core' ),
					'selector' => '{{WRAPPER}} .fame-login-signup input[type="submit"]:hover, {{WRAPPER}} .trial-form form input[type="submit"]:hover',
				]
			);
			$this->end_controls_tab();  // end:Hover tab
		$this->end_controls_tabs(); // end tabs

		$this->end_controls_section();// end: Section


		$this->start_controls_section(
			'section_custom_css_style',
			[
				'label' => esc_html__( 'Custom Css', 'fame-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'custom_css',
			[
				'label' => esc_html__( 'Custom Css', 'fame-core' ),
				'type' => Controls_Manager::CODE,
				'language' => 'css',
				'rows' => 10,
			]
		);
		$this->end_controls_section();// end: Section

	}

	/**
	 * Render Login Signup widget output on the frontend.
	 * Written in PHP and used to generate the final HTML.
	*/
	protected function render() {
		$settings = $this->get_settings_for_display();
		$form_type = !empty( $settings['form_type'] ) ? $settings['form_type'] : '';
		$form_title = !empty( $settings['form_title'] ) ? $settings['form_title'] : '';
		$form_sub_title = !empty( $settings['form_sub_title'] ) ? $settings['form_sub_title'] : '';
		$custom_css = !empty( $settings['custom_css'] ) ? $settings['custom_css'] : '';

		$form_type = $form_type ?  $form_type  : 'login';
		$title = $form_title ? '<h2 class="section-title">'.$form_title.'</h2>' : '';
		$sub_title = $form_sub_title ? '<p>'.$form_sub_title.'</p>' : '';

		// Turn output buffer on
		ob_start(); ?>
		<div class="fame-login-signup fame-form">
			<div class="fame-losi-wrap">
				<div class="row align-items-center">
					<div class="col-md-12">
						<div class="form-wrap">
							<div class="section-title-wrap">
							  <?php echo $title.$sub_title; ?>
							</div>
							<?php
								if ( ! is_user_logged_in() ) {
									if($form_type == "login") {
										$args = array(

											'remember'       => true,
											'redirect'       => ( is_ssl() ? 'https://' : 'http://' ) . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'],
											'form_id'        => 'loginform',
											'id_username'    => 'user_login',
											'id_password'    => 'user_pass',
											'id_remember'    => 'rememberme',
											'id_submit'      => 'wp-submit',
											'label_username' => __( 'Username or Email Address', 'fame-core' ),
											'label_password' => __( 'Password', 'fame-core' ),
											'label_remember' => __( 'Keep me sign in', 'fame-core' ),
											'label_log_in'   => __( 'Login', 'fame-core' ),
											'value_username' => '',
											'value_remember' => false
										);
										wp_login_form($args);
									} else {
										echo do_shortcode('[fame_registration]');
									}
								} else { // If logged in:
									echo '<div class="fame-logout-admin">';
										wp_loginout( home_url() ); // Display "Log Out" link.
										echo " | ";
										wp_register('', ''); // Display "Site Admin" link.
									echo '</div>';
								}
							?>
						</div>
					</div>
				</div>
			</div>
		</div>
		<?php echo '<style>'.$custom_css.'</style>';
		// Return outbut buffer
		echo ob_get_clean();

	}

	/**
	 * Render Login Signup widget output in the editor.
	 * Written as a Backbone JavaScript template and used to generate the live preview.
	*/

	//protected function _content_template(){}

}
Plugin::instance()->widgets_manager->register_widget_type( new Fame_LoginSignup() );