<?php
/*
 * Elementor Fame Counter Widget
 * Author & Copyright: VictorTheme
*/

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Fame_Counter extends Widget_Base{

	/**
	 * Retrieve the widget name.
	*/
	public function get_name(){
		return 'vt-fame_counter';
	}

	/**
	 * Retrieve the widget title.
	*/
	public function get_title(){
		return esc_html__( 'Counter', 'fame-core' );
	}

	/**
	 * Retrieve the widget icon.
	*/
	public function get_icon() {
		return 'fa fa-sort-numeric-asc';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	*/
	public function get_categories() {
		return ['victortheme-category'];
	}

	/**
	 * Retrieve the list of scripts the Fame Counter widget depended on.
	 * Used to set scripts dependencies required to run the widget.
	*/
	public function get_script_depends() {
		return ['vt-fame_counter'];
	}
	
	/**
	 * Register Fame Counter widget controls.
	 * Adds different input fields to allow the user to change and customize the widget settings.
	*/
	protected function _register_controls(){
		
		$this->start_controls_section(
			'section_counter',
			[
				'label' => esc_html__( 'Counter Options', 'fame-core' ),
			]
		);
		$this->add_control(
			'counter_title',
			[
				'label' => esc_html__( 'Title', 'fame-core' ),
				'type' => Controls_Manager::TEXT,
				'label_block' => true,
				'default' => esc_html__( 'Default title', 'fame-core' ),
				'placeholder' => esc_html__( 'Type your counter title here', 'fame-core' ),
			]
		);
		$this->add_control(
			'counter_value',
			[
				'label' => esc_html__( 'Value', 'fame-core' ),
				'type' => Controls_Manager::TEXT,
				'default' => 100,
				'description' => esc_html__( 'Type your counter value here', 'fame-core' ),
			]
		);
		$this->add_control(
			'counter_value_in',
			[
				'label' => esc_html__( 'Value In', 'fame-core' ),
				'type' => Controls_Manager::TEXT,
				'label_block' => true,
				'default' => esc_html__( '+', 'fame-core' ),
				'placeholder' => esc_html__( 'Type your counter value here', 'fame-core' ),
			]
		);
		$this->add_control(
			'counter_delay',
			[
				'label' => esc_html__( 'Counter Delay', 'fame-core' ),
				'type' => Controls_Manager::TEXT,
				'label_block' => true,
				'placeholder' => esc_html__( 'Type your counter delay. Eg:1,2,10 etc.,', 'fame-core' ),
			]
		);
		$this->add_control(
			'counter_time',
			[
				'label' => esc_html__( 'Counter Time', 'fame-core' ),
				'type' => Controls_Manager::TEXT,
				'label_block' => true,
				'placeholder' => esc_html__( 'Type your counter time. Eg:1000,2000 etc.,', 'fame-core' ),
			]
		);
		$this->end_controls_section();// end: Section

		$this->start_controls_section(
			'section_title_style',
			[
				'label' => esc_html__( 'Title', 'fame-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'counter_title!' => '',
				],
				'frontend_available' => true,
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'title_typography',
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .status-title',
			]
		);
		$this->add_control(
			'title_color',
			[
				'label' => esc_html__( 'Color', 'fame-core' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .status-title' => 'color: {{VALUE}};',
				],
			]
		);
		$this->end_controls_section();// end: Section
		
		$this->start_controls_section(
			'section_value_style',
			[
				'label' => esc_html__( 'Value', 'fame-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'counter_value!' => '',
				],
				'frontend_available' => true,
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'value_typography',
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .status-item h2 .fame-counter',
			]
		);
		$this->add_control(
			'value_color',
			[
				'label' => esc_html__( 'Color', 'fame-core' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .status-item h2 .fame-counter' => 'color: {{VALUE}};',
				],
			]
		);
		$this->end_controls_section();// end: Section
		
		$this->start_controls_section(
			'section_value_in_style',
			[
				'label' => esc_html__( 'Value In', 'fame-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'counter_value_in!' => '',
				],
				'frontend_available' => true,
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'value_in_typography',
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .status-item h2',
			]
		);
		$this->add_control(
			'value_in_color',
			[
				'label' => esc_html__( 'Color', 'fame-core' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .status-item h2' => 'color: {{VALUE}};',
				],
			]
		);
		$this->end_controls_section();// end: Section
				
	}

	/**
	 * Render Counter widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	*/
	protected function render() {
		$settings = $this->get_settings_for_display();
		$counter_title = !empty( $settings['counter_title'] ) ? $settings['counter_title'] : '';
		$counter_value = !empty( $settings['counter_value'] ) ? $settings['counter_value'] : '';
		$counter_value_in = !empty( $settings['counter_value_in'] ) ? $settings['counter_value_in'] : '';
		$counter_delay = !empty( $settings['counter_delay'] ) ? $settings['counter_delay'] : '';
		$counter_time = !empty( $settings['counter_time'] ) ? $settings['counter_time'] : '';

		// Counter Options
    $counter_delay = $counter_delay ? ' data-delay="'. $counter_delay .'"' : ' data-delay="1"';
    $counter_time = $counter_time ? ' data-time="'. $counter_time .'"' : ' data-time="1000"';
		
		// Counter Title
		$counter_title = $counter_title ? '<h4 class="status-title">'.$counter_title.'</h4>' : '';

		// Value
		$counter_value = $counter_value ? '<h2 class="status-number"><span class="fame-counter" '.$counter_delay.$counter_time.'>'.$counter_value.'</span>'.$counter_value_in.'</h2>' : '';

		// Counters
		$output = '<div class="status-item fame-item">'.$counter_value.$counter_title.'</div>';

		// Output
		echo $output;
		
	}

	/**
	 * Render Counter widget output in the editor.
	 * Written as a Backbone JavaScript template and used to generate the live preview.
	*/
	 
	//protected function _content_template(){}
	
}
Plugin::instance()->widgets_manager->register_widget_type( new Fame_Counter() );
