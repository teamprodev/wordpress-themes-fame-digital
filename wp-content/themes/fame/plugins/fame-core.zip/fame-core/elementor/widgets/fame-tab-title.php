<?php
/*
 * Elementor Fame Tab Title Widget
 * Author & Copyright: VictorTheme
*/

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Fame_TabTitle extends Widget_Base{

	/**
	 * Retrieve the widget name.
	*/
	public function get_name(){
		return 'vt-fame_tab_title';
	}

	/**
	 * Retrieve the widget title.
	*/
	public function get_title(){
		return esc_html__( 'Tab Title', 'fame-core' );
	}

	/**
	 * Retrieve the widget icon.
	*/
	public function get_icon() {
		return 'fa fa-bars';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	*/
	public function get_categories() {
		return ['victortheme-category'];
	}

	/**
	 * Retrieve the list of scripts the Fame Tab Title widget depended on.
	 * Used to set scripts dependencies required to run the widget.
	*/
	/*
	public function get_script_depends() {
		return ['vt-fame_tab_title'];
	}
	*/
	
	/**
	 * Register Fame Tab Title widget controls.
	 * Adds different input fields to allow the user to change and customize the widget settings.
	*/
	protected function _register_controls(){

		$this->start_controls_section(
			'section_active',
			[
				'label' => __( 'Tab Options', 'fame-core' ),
			]
		);
		$this->add_control(
			'active',
			[
				'label' => __( 'Active Tab Number', 'fame-core' ),
				'type' => Controls_Manager::TEXT,
				'default' => 1,
			]
		);
		$this->end_controls_section();// end: Section

		$this->start_controls_section(
			'section_tab_title',
			[
				'label' => __( 'Tab Title Group', 'fame-core' ),
			]
		);		

		$repeater = new Repeater();		
		$repeater->add_control(
			'tab_title',
			[
				'label' => esc_html__( 'Tab Title', 'fame-core' ),
				'type' => Controls_Manager::TEXT,
				'default' => esc_html__( 'Cloud Storage', 'fame-core' ),
				'placeholder' => esc_html__( 'Type tab title here', 'fame-core' ),
				'label_block' => true,
			]
		);	
		$repeater->add_control(
			'title_image',
			[
				'label' => esc_html__( 'Title Icon', 'fame-core' ),
				'type' => Controls_Manager::MEDIA,
				'frontend_available' => true,
				'default' => [
					'url' => Utils::get_placeholder_image_src(),
				],
				'description' => esc_html__( 'Set your icon image.', 'fame-core'),
			]
		);
		$repeater->add_control(
			'tab_id',
			[
				'label' => esc_html__( 'Tab ID', 'fame-core' ),
				'type' => Controls_Manager::TEXT,
				'placeholder' => esc_html__( 'Type tab id here', 'fame-core' ),
				'label_block' => true,
			]
		);		
		$this->add_control(
			'title_groups',
			[
				'label' => esc_html__( 'Title Items', 'fame-core' ),
				'type' => Controls_Manager::REPEATER,
				'default' => [
					[
						'tab_title' => esc_html__( 'Cloud Storage', 'fame-core' ),
					],
					
				],
				'fields' => $repeater->get_controls(),
				'title_field' => '{{{ tab_title }}}',
			]
		);
		
		$this->end_controls_section();// end: Section	

		// Tab Title Style
		$this->start_controls_section(
			'section_tab_style',
			[
				'label' => esc_html__( 'Tab Title', 'fame-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'sastabt_title_typography',
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .nav-tabs .nav-link .tab-heading',
			]
		);
		$this->start_controls_tabs( 'title_style' );
			$this->start_controls_tab(
					'title_normal',
					[
						'label' => esc_html__( 'Normal', 'fame-core' ),
					]
				);
			$this->add_control(
				'title_color',
				[
					'label' => esc_html__( 'Color', 'fame-core' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .nav-tabs .nav-link' => 'color: {{VALUE}};',
					],
				]
			);
			$this->add_control(
				'title_bg_color',
				[
					'label' => esc_html__( 'Background Color', 'fame-core' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .nav-tabs .nav-link' => 'background-color: {{VALUE}};',
					],
				]
			);
			$this->add_control(
				'title_border_color',
				[
					'label' => esc_html__( 'Border Color', 'fame-core' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .nav-tabs .nav-link' => 'border-color: {{VALUE}};',
					],
				]
			);
			$this->end_controls_tab();  // end:Normal tab
			$this->start_controls_tab(
					'title_hover',
					[
						'label' => esc_html__( 'Hover', 'fame-core' ),
					]
				);
			$this->add_control(
				'title_hover_color',
				[
					'label' => esc_html__( 'Color', 'fame-core' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .nav-tabs .nav-link:hover, {{WRAPPER}} .nav-tabs .nav-link.active' => 'color: {{VALUE}};',
					],
				]
			);
			$this->add_control(
				'title_bg_hover_color',
				[
					'label' => esc_html__( 'Background Hover Color', 'fame-core' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .nav-tabs .nav-link:hover, {{WRAPPER}} .nav-tabs .nav-link.active' => 'background-color: {{VALUE}};',
					],
				]
			);
			$this->add_control(
				'title_border_hover_color',
				[
					'label' => esc_html__( 'Border Hover Color', 'fame-core' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .nav-tabs .nav-link:hover, {{WRAPPER}} .nav-tabs .nav-link.active' => 'background-color: {{VALUE}};',
					],
				]
			);
			$this->end_controls_tab();  // end:Hover tab
		$this->end_controls_tabs(); // end tabs	
		
		$this->end_controls_section();// end: Section

	}

	/**
	 * Render Tab Title widget output on the frontend.
	 * Written in PHP and used to generate the final HTML.
	*/
	protected function render() {
		// Tab Title query
		$settings = $this->get_settings_for_display();

		$active = !empty( $settings['active'] ) ? $settings['active'] : '';
		$title_groups = !empty( $settings['title_groups'] ) ? $settings['title_groups'] : '';

		$output = '';
		if( !empty( $title_groups ) && is_array( $title_groups ) ) {
			$output .= '<nav class="nav nav-tabs">';
		              	$key = 1;
	                	foreach ( $title_groups as $each_logo ) {
										$tab_id = !empty( $each_logo['tab_id'] ) ? $each_logo['tab_id'] : '';
										$title_image = !empty( $each_logo['title_image']['id'] ) ? $each_logo['title_image']['id'] : '';
										$image_url = wp_get_attachment_url( $title_image );
										$icon = $image_url ? ' style="background-image: url('.$image_url.');"' : '';

										$active_cls = ( $key == $active ) ? ' active' : '';
										$id = $tab_id ? sanitize_title($tab_id) : sanitize_title($each_logo['tab_title']);
											$output .= '<a class="nav-item nav-link'.$active_cls.'" data-toggle="tab" href="#nav-'.$key.$id.'">
																		<span class="fame-icon"'.$icon.'></span>
																		<span class="tab-heading">'.$each_logo['tab_title'].'</span>
																	</a>';
										$key++;
										}
      $output .= '</nav>';
		}
		echo $output;
		
	}

	/**
	 * Render Tab Title widget output in the editor.
	 * Written as a Backbone JavaScript template and used to generate the live preview.
	*/
	
	//protected function _content_template(){}
	
}
Plugin::instance()->widgets_manager->register_widget_type( new Fame_TabTitle() );