<?php
/*
 * Elementor Fame Features Widget
 * Author & Copyright: VictorTheme
*/

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Fame_Features extends Widget_Base{

	/**
	 * Retrieve the widget name.
	*/
	public function get_name(){
		return 'vt-fame_features';
	}

	/**
	 * Retrieve the widget title.
	*/
	public function get_title(){
		return esc_html__( 'Features', 'fame-core' );
	}

	/**
	 * Retrieve the widget icon.
	*/
	public function get_icon() {
		return 'fa fa-plus-circle';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	*/
	public function get_categories() {
		return ['victortheme-category'];
	}

	/**
	 * Retrieve the list of scripts the Fame Features widget depended on.
	 * Used to set scripts dependencies required to run the widget.
	*/
	/*
	public function get_script_depends() {
		return ['vt-fame_features'];
	}
	*/
	
	/**
	 * Register Fame Features widget controls.
	 * Adds different input fields to allow the user to change and customize the widget settings.
	*/
	protected function _register_controls(){
		
		$this->start_controls_section(
			'section_features',
			[
				'label' => __( 'Features Options', 'fame-core' ),
			]
		);
		$this->add_control(
			'upload_type',
			[
				'label' => __( 'Icon Type', 'fame-core' ),
				'type' => Controls_Manager::SELECT,
				'options' => [
					'image' => esc_html__( 'Image', 'fame-core' ),
					'icon' => esc_html__( 'Icon', 'fame-core' ),
				],
				'default' => 'image',
			]
		);
		$this->add_control(
			'features_image',
			[
				'label' => esc_html__( 'Upload Icon', 'fame-core' ),
				'type' => Controls_Manager::MEDIA,
				'condition' => [
					'upload_type' => 'image',
				],
				'frontend_available' => true,
				'default' => [
					'url' => Utils::get_placeholder_image_src(),
				],
				'description' => esc_html__( 'Set your icon image.', 'fame-core'),
			]
		);
		$this->add_control(
			'features_icon',
			[
				'label' => esc_html__( 'Sub Title Icon', 'fame-core' ),
				'type' => Controls_Manager::ICON,
				'options' => Controls_Helper_Output::get_include_icons(),
				'frontend_available' => true,
				'default' => 'fa fa-cog',
				'condition' => [
					'upload_type' => 'icon',
				],
			]
		);
		$this->add_control(
			'features_title',
			[
				'label' => esc_html__( 'Title Text', 'fame-core' ),
				'type' => Controls_Manager::TEXT,
				'default' => esc_html__( 'Powerfull & Secure', 'fame-core' ),
				'placeholder' => esc_html__( 'Type title text here', 'fame-core' ),
				'label_block' => true,
			]
		);
		$this->add_control(
			'features_title_link',
			[
				'label' => esc_html__( 'Title Link', 'fame-core' ),
				'type' => Controls_Manager::URL,
				'placeholder' => 'https://your-link.com',
				'default' => [
					'url' => '',
				],
				'label_block' => true,
			]
		);
		$this->add_control(
			'features_content',
			[
				'label' => esc_html__( 'Content', 'fame-core' ),
				'default' => esc_html__( 'The road and back again your heart is true youre a pal and anfis confidant thank you for being a friend oly travel down.', 'fame-core' ),
				'placeholder' => esc_html__( 'Type your content here', 'fame-core' ),
				'type' => Controls_Manager::TEXTAREA,
				'label_block' => true,
			]
		);
		$this->add_control(
			'features_btn_link',
			[
				'label' => esc_html__( 'Button Link', 'fame-core' ),
				'type' => Controls_Manager::URL,
				'placeholder' => 'https://your-link.com',
				'default' => [
					'url' => '',
				],
				'label_block' => true,
			]
		);

		$this->add_responsive_control(
			'section_alignment',
			[
				'label' => esc_html__( 'Alignment', 'fame-core' ),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'fame-core' ),
						'icon' => 'fa fa-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'fame-core' ),
						'icon' => 'fa fa-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'fame-core' ),
						'icon' => 'fa fa-align-right',
					],
				],
				'default' => 'center',
				'selectors' => [
					'{{WRAPPER}} .feature-item' => 'text-align: {{VALUE}};',
				],
			]
		);
		$this->end_controls_section();// end: Section

		// Style
		// Icon
		$this->start_controls_section(
			'section_icon_style',
			[
				'label' => esc_html__( 'Sub Title', 'fame-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'upload_type' => array('icon'),
				],
			]
		);
			$this->add_control(
				'icon_color',
				[
					'label' => esc_html__( 'Icon Color', 'fame-core' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .feature-item .fame-icon i' => 'color: {{VALUE}};',
					],
				]
			);
			$this->add_control(
				'icon_size',
				[
					'label' => esc_html__( 'Icon Size', 'fame-core' ),
					'type' => Controls_Manager::SLIDER,
					'range' => [
						'px' => [
							'min' => 0,
							'max' => 500,
							'step' => 1,
						],
					],
					'size_units' => [ 'px' ],
					'selectors' => [
						'{{WRAPPER}} .feature-item .fame-icon i' => 'font-size: {{SIZE}}{{UNIT}};',
					],
				]
			);
		$this->end_controls_section();// end: Section

		// Title
		$this->start_controls_section(
			'section_title_style',
			[
				'label' => esc_html__( 'Title', 'fame-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'label' => esc_html__( 'Typography', 'fame-core' ),
				'name' => 'sasstp_title_typography',
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .feature-item h3',
			]
		);
		$this->start_controls_tabs( 'title_style' );
			$this->start_controls_tab(
				'title_normal',
				[
					'label' => esc_html__( 'Normal', 'fame-core' ),
				]
			);
			$this->add_control(
				'title_color',
				[
					'label' => esc_html__( 'Color', 'fame-core' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .feature-item h3, {{WRAPPER}} .feature-item h3 a' => 'color: {{VALUE}};',
					],
				]
			);
			$this->end_controls_tab();  // end:Normal tab
			$this->start_controls_tab(
				'title_hover',
				[
					'label' => esc_html__( 'Hover', 'fame-core' ),
				]
			);
			$this->add_control(
				'title_hover_color',
				[
					'label' => esc_html__( 'Color', 'fame-core' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .feature-item h3 a:hover' => 'color: {{VALUE}};',
					],
				]
			);
			$this->end_controls_tab();  // end:Hover tab
		$this->end_controls_tabs(); // end tabs
		$this->end_controls_section();// end: Section

		// Content		
		$this->start_controls_section(
			'section_content_style',
			[
				'label' => esc_html__( 'Content', 'fame-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'label' => esc_html__( 'Typography', 'fame-core' ),
					'name' => 'content_typography',
					'scheme' => Scheme_Typography::TYPOGRAPHY_1,
					'selector' => '{{WRAPPER}} .feature-item p',
				]
			);
			$this->add_control(
				'content_color',
				[
					'label' => esc_html__( 'Color', 'fame-core' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .feature-item p' => 'color: {{VALUE}};',
					],
				]
			);
		$this->end_controls_section();// end: Section

		// Button
		$this->start_controls_section(
			'section_btn_style',
			[
				'label' => esc_html__( 'Button', 'fame-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->start_controls_tabs( 'btn_style' );
			$this->start_controls_tab(
				'btn_normal',
				[
					'label' => esc_html__( 'Normal', 'fame-core' ),
				]
			);
			$this->add_control(
				'btn_bg_color',
				[
					'label' => esc_html__( 'Background Color', 'fame-core' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .feature-link' => 'background-color: {{VALUE}};',
					],
				]
			);
			$this->end_controls_tab();  // end:Normal tab
			$this->start_controls_tab(
				'btn_hover',
				[
					'label' => esc_html__( 'Hover', 'fame-core' ),
				]
			);
			$this->add_control(
				'btn_bg_hover_color',
				[
					'label' => esc_html__( 'Background Color', 'fame-core' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .feature-item.fame-hover .feature-link' => 'background-color: {{VALUE}};',
					],
				]
			);
			$this->end_controls_tab();  // end:Hover tab
		$this->end_controls_tabs(); // end tabs
		$this->end_controls_section();// end: Section
		
	}

	/**
	 * Render App Works widget output on the frontend.
	 * Written in PHP and used to generate the final HTML.
	*/
	protected function render() {
		$settings = $this->get_settings_for_display();
		$upload_type = !empty( $settings['upload_type'] ) ? $settings['upload_type'] : '';
		$features_image = !empty( $settings['features_image']['id'] ) ? $settings['features_image']['id'] : '';	
		$features_icon = !empty( $settings['features_icon'] ) ? $settings['features_icon'] : '';	
		$features_title = !empty( $settings['features_title'] ) ? $settings['features_title'] : '';	
		$features_title_link = !empty( $settings['features_title_link']['url'] ) ? $settings['features_title_link']['url'] : '';
		$features_title_link_external = !empty( $settings['features_title_link']['is_external'] ) ? 'target="_blank"' : '';
		$features_title_link_nofollow = !empty( $settings['features_title_link']['nofollow'] ) ? 'rel="nofollow"' : '';
		$features_title_link_attr = !empty( $features_title_link ) ?  $features_title_link_external.' '.$features_title_link_nofollow : '';
		$features_content = !empty( $settings['features_content'] ) ? $settings['features_content'] : '';	

		$features_btn_link = !empty( $settings['features_btn_link']['url'] ) ? $settings['features_btn_link']['url'] : '';
		$features_btn_link_external = !empty( $settings['features_btn_link']['is_external'] ) ? 'target="_blank"' : '';
		$features_btn_link_nofollow = !empty( $settings['features_btn_link']['nofollow'] ) ? 'rel="nofollow"' : '';
		$features_btn_link_attr = !empty( $features_btn_link ) ?  $features_btn_link_external.' '.$features_btn_link_nofollow : '';

		// Image
		$image_url = wp_get_attachment_url( $features_image );
		$fame_alt = get_post_meta($features_image, '_wp_attachment_image_alt', true);

		$features_image = $image_url ? '<div class="fame-icon"><img src="'.$image_url.'" width="162" alt="'.$fame_alt.'"></div>' : '';
		$features_icon = $features_icon ? '<div class="fame-icon"><i class="'.$features_icon.'"></i></div>' : '';

		if($upload_type === 'icon'){
		  $icon_main = $features_icon;
		} else {
		  $icon_main = $features_image;
		}
		$title_link = $features_title_link ? '<a href="'.$features_title_link.'" '.$features_title_link_attr.'>'.$features_title.'</a>' : $features_title;
		$title = $features_title ? '<h3 class="features-title">'.$title_link.'</h3>' : '';
		$content = $features_content ? '<p>'.$features_content.'</p>' : '';
		$features_btn = $features_btn_link ? '<div class="feature-link-wrap"><a href="'.$features_btn_link.'" class="feature-link" '.$features_btn_link_attr.'></a></div>' : '';

		$output = '<div class="feature-item fame-item">'.$icon_main.$title.$content.$features_btn.'</div>';
		echo $output;
		
	}

	/**
	 * Render Features widget output in the editor.
	 * Written as a Backbone JavaScript template and used to generate the live preview.
	*/
	
	//protected function _content_template(){}
	
}
Plugin::instance()->widgets_manager->register_widget_type( new Fame_Features() );