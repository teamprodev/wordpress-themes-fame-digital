<?php
/*
 * Elementor Fame Button Widget
 * Author & Copyright: VictorTheme
*/

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Fame_Button extends Widget_Base{

	/**
	 * Retrieve the widget name.
	*/
	public function get_name(){
		return 'vt-fame_button';
	}

	/**
	 * Retrieve the widget title.
	*/
	public function get_title(){
		return esc_html__( 'Button', 'fame-core' );
	}

	/**
	 * Retrieve the widget icon.
	*/
	public function get_icon() {
		return 'fa fa-mouse-pointer';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	*/
	public function get_categories() {
		return ['victortheme-category'];
	}

	/**
	 * Retrieve the list of scripts the Fame Button widget depended on.
	 * Used to set scripts dependencies required to run the widget.
	*/
	/*
	public function get_script_depends() {
		return ['vt-fame_button'];
	}
	*/
	
	/**
	 * Register Fame Button widget controls.
	 * Adds different input fields to allow the user to change and customize the widget settings.
	*/
	protected function _register_controls(){
		
		$this->start_controls_section(
			'section_Button',
			[
				'label' => __( 'Button Options', 'fame-core' ),
			]
		);			
		$this->add_control(
			'btn_style',
			[
				'label' => esc_html__( 'Button/Link Style', 'fame-core' ),
				'type' => Controls_Manager::SELECT,
				'options' => [
					'style-one' => esc_html__( 'Style One (Button)', 'fame-core' ),
					'style-two' => esc_html__( 'Style Two (Video)', 'fame-core' ),
				],
				'default' => 'style-one',
				'description' => esc_html__( 'Select your button style.', 'fame-core' ),
			]
		);
		$this->add_control(
			'btn_text',
			[
				'label' => esc_html__( 'Button Text', 'fame-core' ),
				'type' => Controls_Manager::TEXT,
				'default' => esc_html__( 'Button Text', 'fame-core' ),
				'placeholder' => esc_html__( 'Type btn text here', 'fame-core' ),
				'label_block' => true,
			]
		);
		$this->add_control(
			'video_link',
			[
				'label' => esc_html__( 'Video Link', 'fame-core' ),
				'type' => Controls_Manager::TEXTAREA,
				'label_block' => true,
				'default' => esc_html__( 'This is video link', 'fame-core' ),
				'placeholder' => esc_html__( 'Enter your link here', 'fame-core' ),	
				'condition' => [
					'btn_style' => array('style-two'),
				],			
			]
		);
		$this->add_control(
			'btn_link',
			[
				'label' => esc_html__( 'Button Link', 'fame-core' ),
				'type' => Controls_Manager::URL,
				'placeholder' => 'https://your-link.com',
				'default' => [
					'url' => '',
				],
				'label_block' => true,
				'condition' => [
					'btn_style' => array('style-one'),
				],
			]
		);
		$this->add_control(
			'btn_icon',
			[
				'label' => esc_html__( 'Icon', 'fame-core' ),
				'type' => Controls_Manager::ICON,
				'options' => Controls_Helper_Output::get_include_icons(),
				'frontend_available' => true,
				'default' => 'fa fa-play',
				'condition' => [
					'btn_style' => array('style-two'),
				],
			]
		);
		$this->add_responsive_control(
			'section_alignment',
			[
				'label' => esc_html__( 'Button Alignment', 'fame-core' ),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'fame-core' ),
						'icon' => 'fa fa-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'fame-core' ),
						'icon' => 'fa fa-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'fame-core' ),
						'icon' => 'fa fa-align-right',
					],
				],
				'default' => 'left',
				'selectors' => [
					'{{WRAPPER}} .fame-btn-wraper' => 'text-align: {{VALUE}};',
				],
			]
		);
		$this->end_controls_section();// end: Section
		
		// Video		
		$this->start_controls_section(
			'section_video_style',
			[
				'label' => esc_html__( 'Button Style', 'fame-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'btn_style' => array('style-two'),
				],
			]
		);		
		$this->start_controls_tabs( 'icon_style' );
			$this->start_controls_tab(
				'icon_normal',
				[
					'label' => esc_html__( 'Normal', 'fame-core' ),
				]
			);
			$this->add_control(
				'vbtn_text_color',
				[
					'label' => esc_html__( 'Text Color', 'fame-core' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .fame-btn-wraper .video-btn-title' => 'color: {{VALUE}};',
						'{{WRAPPER}} .fame-btn-wraper .video-btn-title:after' => 'background-color: {{VALUE}};',
					],
				]
			);
			$this->add_control(
				'vbtn_icon_color',
				[
					'label' => esc_html__( 'Icon Color', 'fame-core' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .fame-btn-wraper .fame-video-btn' => 'color: {{VALUE}};',
					],
				]
			);
			$this->add_control(
				'vbtn_icon_bg_color',
				[
					'label' => esc_html__( 'Button Background Color', 'fame-core' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .fame-btn-wraper .fame-video-btn' => 'background-color: {{VALUE}};',
					],
				]
			);
			$this->end_controls_tab();  // end:Normal tab
			
			$this->start_controls_tab(
				'icon_hover',
				[
					'label' => esc_html__( 'Hover', 'fame-core' ),
				]
			);
			$this->add_control(
				'vbtn_text_hover_color',
				[
					'label' => esc_html__( 'Icon Color', 'fame-core' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .fame-btn-wraper .fame-video-btn-wrap:hover .video-btn-title' => 'color: {{VALUE}};',
					],
				]
			);
			$this->add_control(
				'vbtn_icon_hover_color',
				[
					'label' => esc_html__( 'Icon Color', 'fame-core' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .fame-btn-wraper .fame-video-btn-wrap:hover .fame-video-btn' => 'color: {{VALUE}};',
					],
				]
			);
			$this->add_control(
				'vbtn_icon_bg_hover_color',
				[
					'label' => esc_html__( 'Button Background Color', 'fame-core' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .fame-btn-wraper .fame-video-btn-wrap:hover .fame-video-btn' => 'background-color: {{VALUE}};',
					],
				]
			);
			$this->end_controls_tab();  // end:Hover tab
		$this->end_controls_tabs(); // end tabs
		$this->end_controls_section();// end: Section

		// Button
		$this->start_controls_section(
			'section_button_style',
			[
				'label' => esc_html__( 'Button Style', 'fame-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'btn_style' => array('style-one'),
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'button_typography',
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .fame-btn-wraper .fame-btn',
			]
		);
		$this->add_responsive_control(
			'button_min_width',
			[
				'label' => esc_html__( 'Width', 'fame-core' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 10,
						'max' => 500,
						'step' => 1,
					],
				],
				'size_units' => [ 'px' ],
				'selectors' => [
					'{{WRAPPER}} .fame-btn-wraper .fame-btn' => 'min-width: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_control(
			'button_padding',
			[
				'label' => __( 'Padding', 'fame-core' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .fame-btn-wraper .fame-btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_control(
			'button_border_radius',
			[
				'label' => __( 'Border Radius', 'fame-core' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .fame-btn-wraper .fame-btn' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->start_controls_tabs( 'button_style' );
			$this->start_controls_tab(
				'button_normal',
				[
					'label' => esc_html__( 'Normal', 'fame-core' ),
				]
			);
			$this->add_control(
				'button_color',
				[
					'label' => esc_html__( 'Color', 'fame-core' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .fame-btn-wraper .fame-btn' => 'color: {{VALUE}};',
					],
				]
			);
			$this->add_control(
				'button_bg_color',
				[
					'label' => esc_html__( 'Background Color', 'fame-core' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .fame-btn-wraper .fame-btn' => 'background-color: {{VALUE}};',
					],
				]
			);
			$this->add_group_control(
				Group_Control_Border::get_type(),
				[
					'name' => 'button_border',
					'label' => esc_html__( 'Border', 'fame-core' ),
					'selector' => '{{WRAPPER}} .fame-btn-wraper .fame-btn',
				]
			);
			$this->add_group_control(
				Group_Control_Box_Shadow::get_type(),
				[
					'name' => 'btn_box_shadow',
					'label' => esc_html__( 'Button Box Shadow', 'fame-core' ),
					'selector' => '{{WRAPPER}} .fame-btn-wraper .fame-btn',
				]
			);
			$this->end_controls_tab();  // end:Normal tab
			
			$this->start_controls_tab(
				'button_hover',
				[
					'label' => esc_html__( 'Hover', 'fame-core' ),
				]
			);
			$this->add_control(
				'button_hover_color',
				[
					'label' => esc_html__( 'Color', 'fame-core' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .fame-btn-wraper .fame-btn:hover' => 'color: {{VALUE}};',
					],
				]
			);
			$this->add_control(
				'button_bg_hover_color',
				[
					'label' => esc_html__( 'Background Color', 'fame-core' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .fame-btn-wraper .fame-btn:hover' => 'background-color: {{VALUE}};',
					],
				]
			);
			$this->add_group_control(
				Group_Control_Border::get_type(),
				[
					'name' => 'button_hover_border',
					'label' => esc_html__( 'Border', 'fame-core' ),
					'selector' => '{{WRAPPER}} .fame-btn-wraper .fame-btn:hover',
				]
			);
			$this->add_group_control(
				Group_Control_Box_Shadow::get_type(),
				[
					'name' => 'btn_hover_box_shadow',
					'label' => esc_html__( 'Button Box Shadow', 'fame-core' ),
					'selector' => '{{WRAPPER}} .fame-btn-wraper .fame-btn:hover',
				]
			);
			$this->end_controls_tab();  // end:Hover tab
		$this->end_controls_tabs(); // end tabs
		
		$this->end_controls_section();// end: Section
		
	}

	/**
	 * Render Button widget output on the frontend.
	 * Written in PHP and used to generate the final HTML.
	*/
	protected function render() {
		$settings = $this->get_settings_for_display();
		// Button
		$btn_style = !empty( $settings['btn_style'] ) ? $settings['btn_style'] : '';	
		$btn_text = !empty( $settings['btn_text'] ) ? $settings['btn_text'] : '';	
		$video_link = !empty( $settings['video_link'] ) ? $settings['video_link'] : '';	
		$btn_link = !empty( $settings['btn_link']['url'] ) ? $settings['btn_link']['url'] : '';
		$btn_link_external = !empty( $settings['btn_link']['is_external'] ) ? 'target="_blank"' : '';
		$btn_link_nofollow = !empty( $settings['btn_link']['nofollow'] ) ? 'rel="nofollow"' : '';
		$btn_link_attr = !empty( $btn_link ) ?  $btn_link_external.' '.$btn_link_nofollow : '';

		$btn_icon = !empty( $settings['btn_icon'] ) ? $settings['btn_icon'] : '';	

		$icon = $btn_icon ? '<span class="fame-video-btn"><i class="'.$btn_icon.'" aria-hidden="true"></i></span>' : '';
		$video_btn = $btn_text ? '<span class="video-btn-title">'.$btn_text.'</span>' : '';
		
		if($btn_style === 'style-two') {
		  $button = $video_link ? '<a href="'.$video_link.'" class="fame-video-btn-wrap fame-popup-video">'.$video_btn.$icon.'</a>' : '';
		} else {
		  $button = $btn_link ? '<a href="'.$btn_link.'" '.$btn_link_attr.' class="fame-btn fame-blue-btn">'.$btn_text.'</a>' : '';
		}

		$output = '<div class="fame-btn-wraper">'.$button.'</div>';
		
		echo $output;
		
	}

	/**
	 * Render Button widget output in the editor.
	 * Written as a Backbone JavaScript template and used to generate the live preview.
	*/
	 
	//protected function _content_template(){}
	
}
Plugin::instance()->widgets_manager->register_widget_type( new Fame_Button() );