<?php
/*
 * Elementor Fame Case Studies Widget
 * Author & Copyright: VictorTheme
*/

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

$noneed_case_studies_post = (fame_framework_active()) ? cs_get_option('noneed_case_studies_post') : '';

if (!$noneed_case_studies_post) {
class Fame_CaseStudies extends Widget_Base{

	/**
	 * Retrieve the widget name.
	*/
	public function get_name(){
		return 'vt-fame_case_studies';
	}

	/**
	 * Retrieve the widget title.
	*/
	public function get_title(){
		return esc_html__( 'Case Studies', 'fame-core' );
	}

	/**
	 * Retrieve the widget icon.
	*/
	public function get_icon() {
		return 'fa fa-briefcase';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	*/
	public function get_categories() {
		return ['victortheme-category'];
	}

	/**
	 * Retrieve the list of scripts the Fame Case Studies widget depended on.
	 * Used to set scripts dependencies required to run the widget.
	*/
	public function get_script_depends() {
		return ['vt-fame_case_studies'];
	}
	
	/**
	 * Register Fame Case Studies widget controls.
	 * Adds different input fields to allow the user to change and customize the widget settings.
	*/
	protected function _register_controls(){

		$this->start_controls_section(
			'section_case_studies_listing',
			[
				'label' => esc_html__( 'Listing', 'fame-core' ),
			]
		);
		$this->add_control(
			'case_studies_col',
			[
				'label' => esc_html__( 'Case Studies Column', 'fame-core' ),
				'type' => Controls_Manager::SELECT,
				'options' => [
					'two'          => esc_html__('Two', 'fame'),
          'three'        => esc_html__('Three', 'fame'),
				],
				'default' => 'three',
				'description' => esc_html__( 'Select Column.', 'fame-core' ),
			]
		);
		$this->add_control(
			'case_studies_limit',
			[
				'label' => esc_html__( 'Limit', 'fame-core' ),
				'type' => Controls_Manager::NUMBER,
				'min' => -1,
				'step' => 1,
				'description' => esc_html__( 'Enter the number of items to show.', 'fame-core' ),
			]
		);
		$this->add_control(
			'case_studies_order',
			[
				'label' => __( 'Order', 'fame-core' ),
				'type' => Controls_Manager::SELECT,
				'options' => [
					'ASC' => esc_html__( 'Asending', 'fame-core' ),
					'DESC' => esc_html__( 'Desending', 'fame-core' ),
				],
				'default' => '',
				'description' => esc_html__( 'Select your order.', 'fame-core' ),
			]
		);
		$this->add_control(
			'case_studies_orderby',
			[
				'label' => __( 'Order By', 'fame-core' ),
				'type' => Controls_Manager::SELECT2,
				'default' => '',
				'options' => [
					'none' => __('None', 'fame-core'),
					'ID' => __('ID', 'fame-core'),
					'author' => __('Author', 'fame-core'),
					'title' => __('Name', 'fame-core'),
					'date' => __('Date', 'fame-core'),
					'rand' => __('Rand', 'fame-core'),
					'menu_order' => __('Menu Order', 'fame-core'),
				],
			]
		);
		$this->add_control(
			'case_studies_show_category',
			[
				'label' => __( 'Show only certain categories?', 'fame-core' ),
				'type' => Controls_Manager::SELECT2,
				'default' => [],
				'options' => Controls_Helper_Output::get_terms_names( 'casestudies_category'),
				'multiple' => true,
			]
		);
		$this->add_control(
			'read_more_txt',
			[
				'label' => esc_html__( 'More Text', 'fame-core' ),
				'type' => Controls_Manager::TEXT,
				'label_block' => true,
			]
		);
		$this->end_controls_section();// end: Section
		
		$this->start_controls_section(
			'section_case_studies_ena_dis',
			[
				'label' => esc_html__( 'Enable & Disable', 'fame-core' ),
			]
		);
		$this->add_control(
			'case_studies_aqr',
			[
				'label' => esc_html__( 'Disable Image Resize?', 'fame-core' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'fame-core' ),
				'label_off' => esc_html__( 'No', 'fame-core' ),
				'return_value' => 'true',
				'default' => 'false',
			]
		);
		$this->add_control(
			'case_studies_filter',
			[
				'label' => esc_html__( 'Filter', 'fame-core' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'fame-core' ),
				'label_off' => esc_html__( 'No', 'fame-core' ),
				'return_value' => 'true',
				'default' => 'true',
			]
		);
		$this->add_control(
			'case_studies_filter_type',
			[
				'label' => esc_html__( 'Filter Type', 'fame-core' ),
				'type' => Controls_Manager::SELECT,
				'options' => [
					'normal'  => esc_html__('Normal', 'fame'),
          'ajax'    => esc_html__('Ajax', 'fame'),
				],
				'default' => 'normal',
				'description' => esc_html__( 'Select Column.', 'fame-core' ),
				'condition' => [
					'case_studies_filter' => 'true',
				],
			]
		);
		$this->add_control(
			'case_studies_pagination',
			[
				'label' => esc_html__( 'Pagination', 'fame-core' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'fame-core' ),
				'label_off' => esc_html__( 'No', 'fame-core' ),
				'return_value' => 'true',
				'default' => 'true',
			]
		);
		$this->end_controls_section();// end: Section
		
		// Filter
		$this->start_controls_section(
			'section_filter_style',
			[
				'label' => esc_html__( 'Filter', 'fame-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'case_studies_filter' => 'true',
				],
				'frontend_available' => true,
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'filter_typography',
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .masonry-filters ul li a',
			]
		);
		$this->add_responsive_control(
			'filter_padding',
			[
				'label' => __( 'Padding', 'fame-core' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .masonry-filters ul li a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->start_controls_tabs( 'filter_style' );
			$this->start_controls_tab(
				'filter_normal',
				[
					'label' => esc_html__( 'Normal', 'fame-core' ),
				]
			);
			$this->add_control(
				'filter_color',
				[
					'label' => esc_html__( 'Color', 'fame-core' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .masonry-filters ul li a' => 'color: {{VALUE}};',
					],
				]
			);
			$this->add_control(
				'filter_bg_color',
				[
					'label' => esc_html__( 'Background Color', 'fame-core' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .masonry-filters ul li a' => 'background-color: {{VALUE}};',
					],
				]
			);
			$this->add_control(
				'filter_border_color',
				[
					'label' => esc_html__( 'Border Color', 'fame-core' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .masonry-filters ul li a' => 'border-color: {{VALUE}};',
					],
				]
			);
			$this->end_controls_tab();  // end:Normal tab
			$this->start_controls_tab(
				'filter_active',
				[
					'label' => esc_html__( 'Active', 'fame-core' ),
				]
			);
			$this->add_control(
				'filter_active_color',
				[
					'label' => esc_html__( 'Color', 'fame-core' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .masonry-filters ul li a.active, {{WRAPPER}} .masonry-filters ul li a:hover' => 'color: {{VALUE}}',
					],
				]
			);
			$this->add_control(
				'filter_active_bg_color',
				[
					'label' => esc_html__( 'Background Color', 'fame-core' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .masonry-filters ul li a.active, {{WRAPPER}} .masonry-filters ul li a:hover' => 'background-color: {{VALUE}};',
					],
				]
			);
			$this->add_control(
				'filter_active_border_color',
				[
					'label' => esc_html__( 'Border Color', 'fame-core' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .masonry-filters ul li a.active, {{WRAPPER}} .masonry-filters ul li a:hover' => 'border-color: {{VALUE}};',
					],
				]
			);
			$this->end_controls_tab();  // end:Active tab
		$this->end_controls_tabs(); // end tabs		
		$this->end_controls_section();// end: Section
		
		// Title
		$this->start_controls_section(
			'section_title_style',
			[
				'label' => esc_html__( 'Title', 'fame-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'sasapp_title_typography',
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .case-info h3',
			]
		);
		$this->start_controls_tabs( 'title_style' );
			$this->start_controls_tab(
				'title_normal',
				[
					'label' => esc_html__( 'Normal', 'fame-core' ),
				]
			);
			$this->add_control(
				'title_color',
				[
					'label' => esc_html__( 'Color', 'fame-core' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .case-info h3 a' => 'color: {{VALUE}};',
					],
				]
			);
			$this->end_controls_tab();  // end:Normal tab
			
			$this->start_controls_tab(
				'title_hover',
				[
					'label' => esc_html__( 'Hover', 'fame-core' ),
				]
			);
			$this->add_control(
				'title_hover_color',
				[
					'label' => esc_html__( 'Color', 'fame-core' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .case-info h3 a:hover' => 'color: {{VALUE}};',
					],
				]
			);
			$this->end_controls_tab();  // end:Hover tab
		$this->end_controls_tabs(); // end tabs		
		$this->end_controls_section();// end: Section

		// More
		$this->start_controls_section(
			'section_rmore_style',
			[
				'label' => esc_html__( 'Read More', 'fame-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'sasapp_rmore_typography',
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .fame-link a',
			]
		);
		$this->start_controls_tabs( 'rmore_style' );
			$this->start_controls_tab(
				'rmore_normal',
				[
					'label' => esc_html__( 'Normal', 'fame-core' ),
				]
			);
			$this->add_control(
				'rmore_color',
				[
					'label' => esc_html__( 'Color', 'fame-core' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .fame-link a' => 'color: {{VALUE}};',
					],
				]
			);
			$this->end_controls_tab();  // end:Normal tab
			
			$this->start_controls_tab(
				'rmore_hover',
				[
					'label' => esc_html__( 'Hover', 'fame-core' ),
				]
			);
			$this->add_control(
				'rmore_hover_color',
				[
					'label' => esc_html__( 'Color', 'fame-core' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .fame-link a:hover' => 'color: {{VALUE}};',
					],
				]
			);
			$this->end_controls_tab();  // end:Hover tab
		$this->end_controls_tabs(); // end tabs		
		$this->end_controls_section();// end: Section
		
		// Pagination
		$this->start_controls_section(
			'section_pagi_style',
			[
				'label' => esc_html__( 'Pagination', 'fame-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'case_studies_pagination' => 'true',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'pagi_typography',
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .fame-pagination ul li a, {{WRAPPER}} .fame-pagination ul li span',
			]
		);
		$this->start_controls_tabs( 'pagi_style' );
			$this->start_controls_tab(
				'pagi_normal',
				[
					'label' => esc_html__( 'Normal', 'fame-core' ),
				]
			);
			$this->add_control(
				'pagi_color',
				[
					'label' => esc_html__( 'Color', 'fame-core' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .fame-pagination ul li a' => 'color: {{VALUE}};',
					],
				]
			);
			$this->add_control(
				'pagi_bg_color',
				[
					'label' => esc_html__( 'Background Color', 'fame-core' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .fame-pagination ul li a' => 'background-color: {{VALUE}};',
					],
				]
			);
			$this->add_group_control(
				Group_Control_Border::get_type(),
				[
					'name' => 'pagi_border',
					'label' => esc_html__( 'Border', 'fame-core' ),
					'selector' => '{{WRAPPER}} .fame-pagination ul li a',
				]
			);
			$this->end_controls_tab();  // end:Normal tab
			
			$this->start_controls_tab(
				'pagi_hover',
				[
					'label' => esc_html__( 'Hover', 'fame-core' ),
				]
			);
			$this->add_control(
				'pagi_hover_color',
				[
					'label' => esc_html__( 'Color', 'fame-core' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .fame-pagination ul li a:hover' => 'color: {{VALUE}};',
					],
				]
			);
			$this->add_control(
				'pagi_bg_hover_color',
				[
					'label' => esc_html__( 'Background Color', 'fame-core' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .fame-pagination ul li a:hover' => 'background-color: {{VALUE}};',
					],
				]
			);
			$this->add_group_control(
				Group_Control_Border::get_type(),
				[
					'name' => 'pagi_hover_border',
					'label' => esc_html__( 'Border', 'fame-core' ),
					'selector' => '{{WRAPPER}} .fame-pagination ul li a:hover',
				]
			);
			$this->end_controls_tab();  // end:Hover tab
			$this->start_controls_tab(
				'pagi_active',
				[
					'label' => esc_html__( 'Active', 'fame-core' ),
				]
			);
			$this->add_control(
				'pagi_active_color',
				[
					'label' => esc_html__( 'Color', 'fame-core' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .fame-pagination ul li span.current' => 'color: {{VALUE}};',
					],
				]
			);
			$this->add_control(
				'pagi_bg_active_color',
				[
					'label' => esc_html__( 'Background Color', 'fame-core' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .fame-pagination ul li span.current' => 'background-color: {{VALUE}};',
					],
				]
			);
			$this->add_group_control(
				Group_Control_Border::get_type(),
				[
					'name' => 'pagi_active_border',
					'label' => esc_html__( 'Border', 'fame-core' ),
					'selector' => '{{WRAPPER}} .fame-pagination ul li span.current',
				]
			);
			$this->end_controls_tab();  // end:Active tab
		$this->end_controls_tabs(); // end tabs
		
		$this->end_controls_section();// end: Section
	}

	/**
	 * Render Case Studies widget output on the frontend.
	 * Written in PHP and used to generate the final HTML.
	*/
	protected function render() {
		$settings = $this->get_settings_for_display();
		$case_studies_col = !empty( $settings['case_studies_col'] ) ? $settings['case_studies_col'] : '';
		$case_studies_limit = !empty( $settings['case_studies_limit'] ) ? $settings['case_studies_limit'] : '';
		$case_studies_order = !empty( $settings['case_studies_order'] ) ? $settings['case_studies_order'] : '';
		$case_studies_orderby = !empty( $settings['case_studies_orderby'] ) ? $settings['case_studies_orderby'] : '';
		$case_studies_show_category = !empty( $settings['case_studies_show_category'] ) ? $settings['case_studies_show_category'] : [];
		$read_more_txt = !empty( $settings['read_more_txt'] ) ? $settings['read_more_txt'] : '';
		$filter_title = !empty( $settings['filter_title'] ) ? $settings['filter_title'] : [];
		$case_studies_aqr  = ( isset( $settings['case_studies_aqr'] ) && ( 'true' == $settings['case_studies_aqr'] ) ) ? true : false;
		$case_studies_filter  = ( isset( $settings['case_studies_filter'] ) && ( 'true' == $settings['case_studies_filter'] ) ) ? true : false;
		$case_studies_filter_type = !empty( $settings['case_studies_filter_type'] ) ? $settings['case_studies_filter_type'] : '';
		$case_studies_pagination  = ( isset( $settings['case_studies_pagination'] ) && ( 'true' == $settings['case_studies_pagination'] ) ) ? true : false;

		$case_studies_limit = $case_studies_limit ? $case_studies_limit : '-1';
		$all_case_studies_txt = cs_get_option('case_all_text');
		$all_text_actual = $all_case_studies_txt ? $all_case_studies_txt : esc_html__( 'All', 'fame-core' );

		// Read More Text
		if (fame_framework_active()) {
		  $read_more_to = cs_get_option('case_studies_read_more');
		  if ($read_more_txt) {
			$read_more_txt = $read_more_txt;
		  } elseif($read_more_to) {
			$read_more_txt = $read_more_to;
		  } else {
			$read_more_txt = esc_html__( 'VIEW DETAILS', 'fame-core' );
		  }
		} else {
		  $read_more_txt = $read_more_txt ? $read_more_txt : esc_html__( 'VIEW DETAILS', 'fame-core' );
		}

		if ($case_studies_col === 'two') {
	    $col_attr = ' data-item=2';
	  } else {
	    $col_attr = '';
	  }

	  if ($case_studies_filter_type === 'ajax') {
	    $filter_cls = ' ajax-filter';
	  } else {
	    $filter_cls = ' normal-filter';
	  }

		// Turn output buffer on
		ob_start();

		// Pagination
		global $paged;
		if( get_query_var( 'paged' ) )
		  $my_page = get_query_var( 'paged' );
		else {
		  if( get_query_var( 'page' ) )
			$my_page = get_query_var( 'page' );
		  else
			$my_page = 1;
		  set_query_var( 'paged', $my_page );
		  $paged = $my_page;
		}

		$args = array(
		  // other query params here,
			'paged' => $my_page,
			'post_type' => 'casestudies',
			'posts_per_page' => (int)$case_studies_limit,
  		'casestudies_category' => $case_studies_show_category,
			'orderby' => $case_studies_orderby,
			'order' => $case_studies_order
		);
		
		$fame_case = new \WP_Query( $args ); ?>
		<div class="fame-case-section">
			<?php if ($case_studies_filter) { ?>
			<div class="masonry-filters<?php echo esc_attr($filter_cls); ?>">
        <ul>
          <li><a href="javascript:void(0);" data-limit="<?php echo esc_attr($case_studies_limit); ?>" data-filter="*" class="active"><?php echo esc_html($all_text_actual); ?></a></li>
          <?php
            if ($case_studies_show_category) {
              $terms = $case_studies_show_category;
              $count = count($terms);
              if ($count > 0) {
                foreach ($terms as $term) {
                  echo '<li class="cat-'. preg_replace('/\s+/', "", strtolower($term)) .'"><a href="javascript:void(0);" data-limit="'.$case_studies_limit.'" data-cat="'. esc_attr($term->slug) .'" data-filter=".cat-'. esc_attr($term->slug) .'" data-filter=".cat-'. preg_replace('/\s+/', "", strtolower($term)) .'" title="' . str_replace('-', " ", strtolower($term)) . '">' . str_replace('-', " ", strtolower($term)) . '</a></li>';
                 }
              }
            } else {
              $terms = get_terms('casestudies_category');
					    $count = count($terms);
					    $i=0;
					    $term_list = '';
					    if ($count > 0) {
					      foreach ($terms as $term) {
					        $i++;
					        $term_list .= '<li><a href="javascript:void(0);" data-limit="'.$case_studies_limit.'" class="filter cat-'. esc_attr($term->slug) .'" data-filter=".cat-'. esc_attr($term->slug) .'" data-cat="'. esc_attr($term->slug) .'" title="' . esc_attr($term->name) . '">' . esc_html($term->name) . '</a></li>';
					        if ($count != $i) {
					          $term_list .= '';
					        } else {
					          $term_list .= '';
					        }
					      }
					      echo $term_list;
					    }
            }
          ?>
        </ul>
      </div>
			<?php } ?>
			<!-- Case Studies Start -->
      <div class="fame-masonry" data-space="15"<?php echo esc_attr($col_attr); ?>>
	    	<?php
	      if ($fame_case->have_posts()) : while ($fame_case->have_posts()) : $fame_case->the_post();
	      global $post;
				$fame_terms = wp_get_post_terms($post->ID,'casestudies_category');
				foreach ($fame_terms as $term) {
				  $fame_cat_class = 'cat-' . $term->slug;
				}
				$fame_count = count($fame_terms);
				$i=0;
				$fame_cat_class = '';
				if ($fame_count > 0) {
				  foreach ($fame_terms as $term) {
				    $i++;
				    $fame_cat_class .= 'cat-'. $term->slug .' ';
				    if ($fame_count != $i) {
				      $fame_cat_class .= '';
				    } else {
				      $fame_cat_class .= '';
				    }
				  }
				}

				// Featured Image
				$fame_large_image =  wp_get_attachment_image_src( get_post_thumbnail_id(get_the_ID()), 'fullsize', false, '' );
				$fame_large_image = $fame_large_image[0];
				if ($case_studies_aqr) {
					$fame_featured_img = $fame_large_image;
				} else {
					if(class_exists('Aq_Resize')) {
				    $fame_case_studies_img = aq_resize( $fame_large_image, '800', '660', true );
				  } else {$fame_case_studies_img = $fame_large_image;}
				  $fame_featured_img = ( $fame_case_studies_img ) ? $fame_case_studies_img : FAME_PLUGIN_ASTS . '/images/holders/800x660.png';
				}
				?>
				<div class="masonry-item <?php echo esc_attr($fame_cat_class); ?>" data-category="<?php echo esc_attr($fame_cat_class); ?>">
				  <div class="case-item">
				    <?php if($fame_large_image) { ?>
				    <div class="fame-image">
				      <a href="<?php echo esc_url( get_permalink() ); ?>"><img src="<?php echo esc_url($fame_featured_img); ?>" alt="<?php echo esc_attr(get_the_title()); ?>"></a>
				    </div>
				    <?php } ?>
				    <div class="case-info">
				      <h3 class="case-title"><a href="<?php echo esc_url( get_permalink() ); ?>"><?php echo esc_html(the_title()); ?></a></h3>
				      <div class="fame-link">
				        <a href="<?php echo esc_url( get_permalink() ); ?>"><?php echo esc_html($read_more_txt); ?> <img src="<?php echo esc_url( FAME_PLUGIN_ASTS . '/images/icons/icon53@2x.png' ); ?>" width="18" alt="<?php echo esc_attr($read_more_txt); ?>"></a>
				      </div>
				    </div>
				  </div>
				</div>
        <?php endwhile;
	      endif; 
	      wp_reset_postdata(); ?>
      </div>
			<?php if ($case_studies_pagination) { fame_paging_nav($fame_case->max_num_pages,"",$paged); } ?>
		</div>
		<!-- Case Studies End -->

		<?php
		// Return outbut buffer
		echo ob_get_clean();
		
	}

	/**
	 * Render Case Studies widget output in the editor.
	 * Written as a Backbone JavaScript template and used to generate the live preview.
	*/
	
	//protected function _content_template(){}
	
}
Plugin::instance()->widgets_manager->register_widget_type( new Fame_CaseStudies() );
}