<?php
/*
 * Elementor Fame Pricing Widget
 * Author & Copyright: VictorTheme
*/

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Fame_Pricing extends Widget_Base{

	/**
	 * Retrieve the widget name.
	*/
	public function get_name(){
		return 'vt-fame_pricing';
	}

	/**
	 * Retrieve the widget title.
	*/
	public function get_title(){
		return esc_html__( 'Pricing Table', 'fame-core' );
	}

	/**
	 * Retrieve the widget icon.
	*/
	public function get_icon() {
		return 'fa fa-money';
	}

	/**
	 * Retrieve the pricing of categories the widget belongs to.
	*/
	public function get_categories() {
		return ['victortheme-category'];
	}

	/**
	 * Retrieve the pricing of scripts the Fame Pricing widget depended on.
	 * Used to set scripts dependencies required to run the widget.
	*/
	/*
	public function get_script_depends() {
		return ['vt-fame_pricing'];
	}
	*/
	
	/**
	 * Register Fame Pricing widget controls.
	 * Adds different input fields to allow the user to change and customize the widget settings.
	*/
	protected function _register_controls(){
		
		$this->start_controls_section(
			'section_pricing',
			[
				'label' => esc_html__( 'Pricing Options', 'fame-core' ),
			]
		);

		$this->add_control(
			'pricing_style',
			[
				'label' => __( 'Pricing Style', 'fame-core' ),
				'type' => Controls_Manager::SELECT,
				'options' => [
					'one' => esc_html__( 'Style One', 'fame-core' ),
					'two' => esc_html__( 'Style Two', 'fame-core' ),
				],
				'default' => 'one',
			]
		);
		$this->add_control(
			'pricing_image',
			[
				'label' => esc_html__( 'Upload Icon', 'fame-core' ),
				'type' => Controls_Manager::MEDIA,
				'condition' => [
					'pricing_style' => 'one',
				],
				'frontend_available' => true,
				'default' => [
					'url' => Utils::get_placeholder_image_src(),
				],
				'description' => esc_html__( 'Set your icon image.', 'fame-core'),
			]
		);
		$this->add_control(
			'pricing_title',
			[
				'label' => esc_html__( 'Title Text', 'fame-core' ),
				'type' => Controls_Manager::TEXT,
				'default' => esc_html__( 'Starter Plan', 'fame-core' ),
				'placeholder' => esc_html__( 'Type title text here', 'fame-core' ),
				'label_block' => true,
			]
		);
		$this->add_control(
			'pricing_price',
			[
				'label' => esc_html__( 'Price', 'fame-core' ),
				'type' => Controls_Manager::TEXT,
				'default' => esc_html__( 'Free', 'fame-core' ),
				'placeholder' => esc_html__( 'Type price text here', 'fame-core' ),
				'label_block' => true,
			]
		);
		
		$repeater = new Repeater();
		$repeater->add_control(
			'pricing_text',
			[
				'label' => esc_html__( 'Text', 'fame-core' ),
				'type' => Controls_Manager::TEXTAREA,
				'label_block' => true,
			]
		);
		$repeater->add_control(
			'disable_text',
			[
				'label' => esc_html__( 'Disabled?', 'fame-core' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Show', 'fame-core' ),
				'label_off' => esc_html__( 'Hide', 'fame-core' ),
				'return_value' => 'true',
				'default' => 'false',
			]
		);
		$this->add_control(
			'pricingItems_groups',
			[
				'label' => esc_html__( 'Pricings', 'fame-core' ),
				'type' => Controls_Manager::REPEATER,
				'default' => [
					[
						'pricing_text' => esc_html__( 'Item #1', 'fame-core' ),
					],
					
				],
				'fields' => $repeater->get_controls(),
				'title_field' => '{{{ pricing_text }}}',
			]
		);
		$this->add_control(
			'pricing_btn',
			[
				'label' => esc_html__( 'Button Text', 'fame-core' ),
				'type' => Controls_Manager::TEXT,
				'default' => esc_html__( 'Button Text', 'fame-core' ),
				'placeholder' => esc_html__( 'Type btn text here', 'fame-core' ),
				'label_block' => true,
			]
		);
		$this->add_control(
			'pricing_btn_link',
			[
				'label' => esc_html__( 'Button Link', 'fame-core' ),
				'type' => Controls_Manager::URL,
				'placeholder' => 'https://your-link.com',
				'default' => [
					'url' => '',
				],
				'label_block' => true,
			]
		);
		$this->end_controls_section();// end: Section

		// Section
		$this->start_controls_section(
			'section_style',
			[
				'label' => esc_html__( 'Section', 'fame-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control(
			Group_Control_Border::get_type(),
			[
				'name' => 'section_border',
				'label' => esc_html__( 'Border', 'fame-core' ),
				'selector' => '{{WRAPPER}} .price-item, {{WRAPPER}} .plan-item, {{WRAPPER}} .plan-item .fame-icon',
			]
		);
		$this->add_control(
			'section_bg_color',
			[
				'label' => esc_html__( 'Background Color', 'fame-core' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .price-item, {{WRAPPER}} .plan-item' => 'background-color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'section_border_radius',
			[
				'label' => __( 'Border Radius', 'fame-core' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .price-item, {{WRAPPER}} .plan-item' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->end_controls_section();// end: Section
		
		$this->start_controls_section(
			'section_title_style',
			[
				'label' => esc_html__( 'Title', 'fame-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'saspri_title_typography',
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .plan-item h3, {{WRAPPER}} .price-item h4',
			]
		);
		$this->add_control(
			'pricing_title_color',
			[
				'label' => esc_html__( 'Color', 'fame-core' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} h3.compare-title, {{WRAPPER}} .price-item h3' => 'color: {{VALUE}};',
				],
			]
		);
		$this->end_controls_section();// end: Section

		$this->start_controls_section(
			'section_price_style',
			[
				'label' => esc_html__( 'Price', 'fame-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'pricing_price_typography',
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .price-item h2, {{WRAPPER}} .plan-item h2',
			]
		);
		$this->add_control(
			'pricing_price_color',
			[
				'label' => esc_html__( 'Color', 'fame-core' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .price-item h2, {{WRAPPER}} .plan-item h2' => 'color: {{VALUE}};',
				],
			]
		);
		$this->end_controls_section();// end: Section

		$this->start_controls_section(
			'section_list_style',
			[
				'label' => esc_html__( 'List', 'fame-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'pricing_list_typography',
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .plan-item ul li, {{WRAPPER}} .price-item ul li',
			]
		);
		$this->add_control(
			'pricing_list_color',
			[
				'label' => esc_html__( 'Color', 'fame-core' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .plan-item ul li, {{WRAPPER}} .price-item ul li' => 'color: {{VALUE}};',
				],
			]
		);
		$this->end_controls_section();// end: Section

		// Button
		$this->start_controls_section(
			'section_button_style',
			[
				'label' => esc_html__( 'Button Style', 'fame-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'button_typography',
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .fame-btn-wrap .fame-btn',
			]
		);
		$this->add_responsive_control(
			'button_min_width',
			[
				'label' => esc_html__( 'Width', 'fame-core' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 10,
						'max' => 500,
						'step' => 1,
					],
				],
				'size_units' => [ 'px' ],
				'selectors' => [
					'{{WRAPPER}} .fame-btn-wrap .fame-btn' => 'min-width: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_control(
			'button_padding',
			[
				'label' => __( 'Padding', 'fame-core' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .fame-btn-wrap .fame-btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->add_control(
			'button_border_radius',
			[
				'label' => __( 'Border Radius', 'fame-core' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .fame-btn-wrap .fame-btn' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->start_controls_tabs( 'button_style' );
			$this->start_controls_tab(
				'button_normal',
				[
					'label' => esc_html__( 'Normal', 'fame-core' ),
				]
			);
			$this->add_control(
				'button_color',
				[
					'label' => esc_html__( 'Color', 'fame-core' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .fame-btn-wrap .fame-btn' => 'color: {{VALUE}};',
					],
				]
			);
			$this->add_control(
				'button_bg_color',
				[
					'label' => esc_html__( 'Background Color', 'fame-core' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .fame-btn-wrap .fame-btn' => 'background-color: {{VALUE}};',
					],
				]
			);
			$this->add_group_control(
				Group_Control_Border::get_type(),
				[
					'name' => 'button_border',
					'label' => esc_html__( 'Border', 'fame-core' ),
					'selector' => '{{WRAPPER}} .fame-btn-wrap .fame-btn',
				]
			);
			$this->add_group_control(
				Group_Control_Box_Shadow::get_type(),
				[
					'name' => 'btn_box_shadow',
					'label' => esc_html__( 'Button Box Shadow', 'fame-core' ),
					'selector' => '{{WRAPPER}} .fame-btn-wrap .fame-btn',
				]
			);
			$this->end_controls_tab();  // end:Normal tab
			
			$this->start_controls_tab(
				'button_hover',
				[
					'label' => esc_html__( 'Hover', 'fame-core' ),
				]
			);
			$this->add_control(
				'button_hover_color',
				[
					'label' => esc_html__( 'Color', 'fame-core' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .fame-btn-wrap .fame-btn:hover' => 'color: {{VALUE}};',
					],
				]
			);
			$this->add_control(
				'button_bg_hover_color',
				[
					'label' => esc_html__( 'Background Color', 'fame-core' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .fame-btn-wrap .fame-btn:hover' => 'background-color: {{VALUE}};',
					],
				]
			);
			$this->add_group_control(
				Group_Control_Border::get_type(),
				[
					'name' => 'button_hover_border',
					'label' => esc_html__( 'Border', 'fame-core' ),
					'selector' => '{{WRAPPER}} .fame-btn-wrap .fame-btn:hover',
				]
			);
			$this->add_group_control(
				Group_Control_Box_Shadow::get_type(),
				[
					'name' => 'btn_hover_box_shadow',
					'label' => esc_html__( 'Button Box Shadow', 'fame-core' ),
					'selector' => '{{WRAPPER}} .fame-btn-wrap .fame-btn:hover',
				]
			);
			$this->end_controls_tab();  // end:Hover tab
		$this->end_controls_tabs(); // end tabs
		
		$this->end_controls_section();// end: Section

	}

	/**
	 * Render Pricing widget output on the frontend.
	 * Written in PHP and used to generate the final HTML.
	*/
	protected function render() {
		$settings = $this->get_settings_for_display();
		$pricing_style = !empty( $settings['pricing_style'] ) ? $settings['pricing_style'] : '';
		$pricing_image = !empty( $settings['pricing_image']['id'] ) ? $settings['pricing_image']['id'] : '';
		$pricing_title = !empty( $settings['pricing_title'] ) ? $settings['pricing_title'] : '';
		$pricing_price = !empty( $settings['pricing_price'] ) ? $settings['pricing_price'] : '';
		$pricingItems_groups = !empty( $settings['pricingItems_groups'] ) ? $settings['pricingItems_groups'] : [];

		$pricing_btn = !empty( $settings['pricing_btn'] ) ? $settings['pricing_btn'] : '';	
		$pricing_btn_link = !empty( $settings['pricing_btn_link']['url'] ) ? $settings['pricing_btn_link']['url'] : '';
		$pricing_btn_link_external = !empty( $settings['pricing_btn_link']['is_external'] ) ? 'target="_blank"' : '';
		$pricing_btn_link_nofollow = !empty( $settings['pricing_btn_link']['nofollow'] ) ? 'rel="nofollow"' : '';
		$pricing_btn_link_attr = !empty( $pricing_btn_link ) ?  $pricing_btn_link_external.' '.$pricing_btn_link_nofollow : '';

		$image_url = wp_get_attachment_url( $pricing_image );
		$image = $pricing_image ? '<div class="fame-icon"><img src="'.$image_url.'" width="128" alt="Pricing"></div>' : '';

		if ($pricing_style === 'two') {
			$title = $pricing_title ? '<h4 class="price-subtitle">'.$pricing_title.'</h4>' : '';
			$price = $pricing_price ? '<h2 class="price-title">'.$pricing_price.'</h2>' : '';
	  	$button = $pricing_btn_link ? '<div class="fame-btn-wrap"><a href="'.$pricing_btn_link.'" '.$pricing_btn_link_attr.' class="fame-btn fame-medium-btn fame-red-btn">'.$pricing_btn.'</a></div>' : '';
		} else {
			$title = $pricing_title ? '<h2 class="plan-title">'.$pricing_title.'</h2>' : '';
			$price = $pricing_price ? '<h3 class="plan-subtitle">'.$pricing_price.'</h3>' : '';
	  	$button = $pricing_btn_link ? '<div class="fame-btn-wrap"><a href="'.$pricing_btn_link.'" '.$pricing_btn_link_attr.' class="fame-btn">'.$pricing_btn.'</a></div>' : '';
		}

		if ($pricing_style === 'two') {
			$output = '<div class="price-item fame-item">
		              '.$title.$price.'
		              <ul>';
		                if( is_array( $pricingItems_groups ) && !empty( $pricingItems_groups ) ) {
										  foreach ( $pricingItems_groups as $each_pricing ) {
											$pricing_text = $each_pricing['pricing_text'] ? $each_pricing['pricing_text'] : '';
											$disable_text = $each_pricing['disable_text'] ? $each_pricing['disable_text'] : '';
											if ($disable_text == 'true') {
												$disable_class = ' class="disable"';
											} else {
												$disable_class = '';
											}
											  $output .= '<li'.$disable_class.'>'. do_shortcode($pricing_text) .'</li>';
										  }
										}
      $output .= '</ul>
		              '.$button.'
		            </div>';
	  } else {
		  $output = '<div class="plan-item fame-item">
		              '.$image.$title.$price.'
		              <ul>';
		                if( is_array( $pricingItems_groups ) && !empty( $pricingItems_groups ) ) {
										  foreach ( $pricingItems_groups as $each_pricing ) {
											$pricing_text = $each_pricing['pricing_text'] ? $each_pricing['pricing_text'] : '';
											$disable_text = $each_pricing['disable_text'] ? $each_pricing['disable_text'] : '';
											if ($disable_text == 'true') {
												$disable_class = ' class="disable"';
											} else {
												$disable_class = '';
											}
											  $output .= '<li'.$disable_class.'>'. do_shortcode($pricing_text) .'</li>';
										  }
										}
    	$output .= '</ul>
		              '.$button.'
		            </div>';
		}

		echo $output;
		
	}

	/**
	 * Render Pricing widget output in the editor.
	 * Written as a Backbone JavaScript template and used to generate the live preview.
	*/
	
	//protected function _content_template(){}
	
}
Plugin::instance()->widgets_manager->register_widget_type( new Fame_Pricing() );