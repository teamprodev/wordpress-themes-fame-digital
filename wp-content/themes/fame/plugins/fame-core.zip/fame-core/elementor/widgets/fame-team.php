<?php
/*
 * Elementor Fame Team Widget
 * Author & Copyright: VictorTheme
*/

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

$noneed_team_post = (fame_framework_active()) ? cs_get_option('noneed_team_post') : '';

if (!$noneed_team_post) {
class Fame_Team extends Widget_Base{

	/**
	 * Retrieve the widget name.
	*/
	public function get_name(){
		return 'vt-fame_team';
	}

	/**
	 * Retrieve the widget title.
	*/
	public function get_title(){
		return esc_html__( 'Team', 'fame-core' );
	}

	/**
	 * Retrieve the widget icon.
	*/
	public function get_icon() {
		return 'fa fa-users';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	*/
	public function get_categories() {
		return ['victortheme-category'];
	}

	/**
	 * Retrieve the list of scripts the Fame Team widget depended on.
	 * Used to set scripts dependencies required to run the widget.
	*/
	
	public function get_script_depends() {
		return ['vt-fame_team'];
	}
	
	/**
	 * Register Fame Team widget controls.
	 * Adds different input fields to allow the user to change and customize the widget settings.
	*/
	protected function _register_controls(){
		
		$this->start_controls_section(
			'section_team_settings',
			[
				'label' => esc_html__( 'Team Options', 'fame-core' ),
			]
		);
		$this->add_control(
			'team_list_heading',
			[
				'label' => __( 'Listing', 'fame-core' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
		$this->add_control(
			'team_aqr',
			[
				'label' => esc_html__( 'Disable Image Resize?', 'fame-core' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'fame-core' ),
				'label_off' => esc_html__( 'No', 'fame-core' ),
				'return_value' => 'true',
				'default' => 'false',
			]
		);
		$this->add_control(
			'team_pagination',
			[
				'label' => esc_html__( 'Pagination?', 'fame-core' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'fame-core' ),
				'label_off' => esc_html__( 'No', 'fame-core' ),
				'return_value' => 'true',
				'default' => 'true',
			]
		);
		$this->add_control(
			'team_limit',
			[
				'label' => esc_html__( 'Limit', 'fame-core' ),
				'type' => Controls_Manager::NUMBER,
				'min' => -1,
				'step' => 1,
			]
		);
		$this->add_control(
			'team_order',
			[
				'label' => esc_html__( 'Order', 'fame-core' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'DESC',
				'options' => [
					'DESC' => esc_html__('DESC', 'fame-core'),
					'ASC' => esc_html__('ASC', 'fame-core'),
				],
			]
		);
		$this->add_control(
			'team_orderby',
			[
				'label' => esc_html__( 'Order By', 'fame-core' ),
				'type' => Controls_Manager::SELECT2,
				'default' => '',
				'options' => [
					'none' => esc_html__('None', 'fame-core'),
					'ID' => esc_html__('ID', 'fame-core'),
					'author' => esc_html__('Author', 'fame-core'),
					'title' => esc_html__('Name', 'fame-core'),
					'date' => esc_html__('Date', 'fame-core'),
					'rand' => esc_html__('Rand', 'fame-core'),
					'menu_order' => esc_html__('Menu Order', 'fame-core'),
				],
			]
		);
		$this->add_control(
			'team_show_category',
			[
				'label' => __( 'Certain Categories?', 'fame-core' ),
				'type' => Controls_Manager::SELECT2,
				'default' => [],
				'options' => Controls_Helper_Output::get_terms_names( 'team_category'),
				'multiple' => true,
			]
		);
		$this->end_controls_section();// end: Section

		$this->start_controls_section(
			'section_name_style',
			[
				'label' => esc_html__( 'Name', 'fame-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'name_typography',
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .mate-info h3',
			]
		);
		$this->start_controls_tabs( 'name_style' );
			$this->start_controls_tab(
				'title_normal',
				[
					'label' => esc_html__( 'Normal', 'fame-core' ),
				]
			);
			$this->add_control(
				'name_color',
				[
					'label' => esc_html__( 'Color', 'fame-core' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .mate-info h3, {{WRAPPER}} .mate-info h3 a' => 'color: {{VALUE}};',
					],
				]
			);
			$this->end_controls_tab();  // end:Normal tab
			
			$this->start_controls_tab(
				'title_hover',
				[
					'label' => esc_html__( 'Hover', 'fame-core' ),
				]
			);
			$this->add_control(
				'name_hover_color',
				[
					'label' => esc_html__( 'Color', 'fame-core' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .mate-info h3 a:hover' => 'color: {{VALUE}};',
					],
				]
			);
			$this->end_controls_tab();  // end:Hover tab
		$this->end_controls_tabs(); // end tabs
		
		$this->end_controls_section();// end: Section
		
		$this->start_controls_section(
			'section_profession_style',
			[
				'label' => esc_html__( 'Profession', 'fame-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'profession_typography',
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .mate-info h5',
			]
		);
		$this->add_control(
			'profession_color',
			[
				'label' => esc_html__( 'Color', 'fame-core' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .mate-info h5' => 'color: {{VALUE}};',
				],
			]
		);
		$this->end_controls_section();// end: Section

		$this->start_controls_section(
			'section_content_style',
			[
				'label' => esc_html__( 'Content', 'fame-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'content_typography',
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .mate-info p',
			]
		);
		$this->add_control(
			'content_color',
			[
				'label' => esc_html__( 'Color', 'fame-core' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .mate-info p' => 'color: {{VALUE}};',
				],
			]
		);
		$this->end_controls_section();// end: Section

		$this->start_controls_section(
			'icon_style',
			[
				'label' => esc_html__( 'Social Icon', 'fame-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);		
		$this->add_responsive_control(
			'icon_font_size',
			[
				'label' => esc_html__( 'Icon Font Size', 'fame-core' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 1,
						'max' => 200,
						'step' => 1,
					],
				],
				'size_units' => [ 'px' ],
				'selectors' => [
					'{{WRAPPER}} .mate-info .fame-social a' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->start_controls_tabs( 'social_icon_style' );
			$this->start_controls_tab(
				'icon_normal',
				[
					'label' => esc_html__( 'Normal', 'fame-core' ),
				]
			);
			$this->add_control(
				'icon_color',
				[
					'label' => esc_html__( 'Color', 'fame-core' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .mate-info .fame-social a' => 'color: {{VALUE}};',
					],
				]
			);
			$this->end_controls_tab();  // end:Normal tab
			
			$this->start_controls_tab(
				'icon_hover',
				[
					'label' => esc_html__( 'Hover', 'fame-core' ),
				]
			);
			$this->add_control(
				'icon_hov_color',
				[
					'label' => esc_html__( 'Color', 'fame-core' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .mate-info .fame-social a:hover' => 'color: {{VALUE}};',
					],
				]
			);
			$this->end_controls_tab();  // end:Hover tab
		$this->end_controls_tabs(); // end tabs

		$this->end_controls_section();// end: Section
		
	}

	/**
	 * Render Team widget output on the frontend.
	 * Written in PHP and used to generate the final HTML.
	*/
	protected function render() {
		$settings = $this->get_settings_for_display();
		
		// Team query
		$team_limit = !empty( $settings['team_limit'] ) ? $settings['team_limit'] : '';
		$team_order = !empty( $settings['team_order'] ) ? $settings['team_order'] : '';
		$team_orderby = !empty( $settings['team_orderby'] ) ? $settings['team_orderby'] : '';
		$team_show_category = !empty( $settings['team_show_category'] ) ? $settings['team_show_category'] : [];
		$team_aqr  = ( isset( $settings['team_aqr'] ) && ( 'true' == $settings['team_aqr'] ) ) ? true : false;
		$team_pagination  = ( isset( $settings['team_pagination'] ) && ( 'true' == $settings['team_pagination'] ) ) ? true : false;
		
		// Turn output buffer on
		ob_start();

		// Pagination
		global $paged;
		if( get_query_var( 'paged' ) )
		  $my_page = get_query_var( 'paged' );
		else {
		  if( get_query_var( 'page' ) )
			$my_page = get_query_var( 'page' );
		  else
			$my_page = 1;
		  set_query_var( 'paged', $my_page );
		  $paged = $my_page;
		}
		$team_limit = $team_limit ? $team_limit : '-1';
		$args = array(
		  'paged' => $my_page,
		  'post_type' => 'team',
		  'posts_per_page' => (int) $team_limit,
		  'team_category' => $team_show_category,
		  'orderby' => $team_orderby,
		  'order' => $team_order,
		);
		$fame_team = new \WP_Query( $args );
		if ($fame_team->have_posts()) : ?>
		<div class="fame-team">
      <div class="row">
			<?php
			  while ($fame_team->have_posts()) : $fame_team->the_post();

        // Link
        $team_options = get_post_meta( get_the_ID(), 'team_options', true );
				if($team_options) {
	        $team_pro = $team_options['team_job_position'];
	        $team_socials = $team_options['social_icons'];
				} else {
				  $team_pro = '';
				  $team_socials = '';
				}

				// Featured Image
    		$large_image =  wp_get_attachment_image_src( get_post_thumbnail_id(get_the_ID()), 'fullsize', false, '' );
    		$large_image = $large_image[0];
    		$abt_title = get_the_title();
        if ($team_aqr) {
          $team_featured_img = $large_image;
        } else {
      		if(class_exists('Aq_Resize')) {
      			$team_img = aq_resize( $large_image, '380', '380', true );
      		} else {$team_img = $large_image;}
      		$team_featured_img = ( $team_img ) ? $team_img : FAME_PLUGIN_ASTS . '/images/holders/380x380.png';
        }
				?>
				<div class="col-lg-6 col-md-12">
          <div class="mate-item fame-item">
            <?php if ($large_image) { ?>
            <div class="fame-image"><a href="<?php echo esc_url( get_permalink() ); ?>"><img src="<?php echo esc_url($team_featured_img); ?>" alt="<?php echo esc_attr($abt_title); ?>"></a></div>
            <?php } ?>
            <div class="mate-info">
              <h3 class="mate-name"><a href="<?php echo esc_url( get_permalink() ); ?>"><?php echo esc_html($abt_title); ?></a></h3>
              <h5 class="mate-designation"><?php echo esc_html($team_pro); ?></h5>
              <p><?php the_excerpt(); ?></p>
              <?php if ( ! empty( $team_socials ) ) { ?>
                <div class="fame-social">
                  <?php foreach ( $team_socials as $social ) {
                  if($social['icon_link']) { ?>
                    <a href="<?php echo esc_url($social['icon_link']); ?>"><i class="<?php echo esc_attr($social['icon']); ?>"></i></a>
                  <?php } } ?>
                </div>
              <?php } ?>
            </div>
          </div>
        </div>
				<?php
			  endwhile;
				?>
		  </div>
		  <?php if ($team_pagination) { fame_paging_nav($fame_team->max_num_pages,"",$paged); }
      wp_reset_postdata(); ?>
		</div> <!-- team End -->
		<?php
		endif;

		wp_reset_postdata();
		// Return outbut buffer
		echo ob_get_clean();
		
	}

	/**
	 * Render Team widget output in the editor.
	 * Written as a Backbone JavaScript template and used to generate the live preview.
	*/
	
	//protected function _content_template(){}
	
}
Plugin::instance()->widgets_manager->register_widget_type( new Fame_Team() );
}