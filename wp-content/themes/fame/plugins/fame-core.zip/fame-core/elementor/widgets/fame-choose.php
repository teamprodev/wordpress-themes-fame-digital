<?php
/*
 * Elementor Fame Choose Widget
 * Author & Copyright: VictorTheme
*/

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Fame_Choose extends Widget_Base{

	/**
	 * Retrieve the widget name.
	*/
	public function get_name(){
		return 'vt-fame_choose';
	}

	/**
	 * Retrieve the widget title.
	*/
	public function get_title(){
		return esc_html__( 'Choose', 'fame-core' );
	}

	/**
	 * Retrieve the widget icon.
	*/
	public function get_icon() {
		return 'fa fa-wrench';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	*/
	public function get_categories() {
		return ['victortheme-category'];
	}

	/**
	 * Retrieve the list of scripts the Fame Choose widget depended on.
	 * Used to set scripts dependencies required to run the widget.
	*/
	/*
	public function get_script_depends() {
		return ['vt-fame_choose'];
	}
	*/
	
	/**
	 * Register Fame Choose widget controls.
	 * Adds different input fields to allow the user to change and customize the widget settings.
	*/
	protected function _register_controls(){
		
		$this->start_controls_section(
			'section_choose',
			[
				'label' => __( 'Choose Item', 'fame-core' ),
			]
		);

		$repeater = new Repeater();
		$repeater->add_control(
			'icon_type',
			[
				'label' => __( 'Icon Type', 'fame-core' ),
				'type' => Controls_Manager::SELECT,
				'options' => [
					'image' => esc_html__( 'Image', 'fame-core' ),
					'icon' => esc_html__( 'Icon', 'fame-core' ),
				],
				'default' => 'image',
			]
		);
		$repeater->add_control(
			'choose_icon',
			[
				'label' => esc_html__( 'Icon', 'fame-core' ),
				'type' => Controls_Manager::ICON,
				'options' => Controls_Helper_Output::get_include_icons(),
				'frontend_available' => true,
				'default' => 'icon-arrows-check',
				'condition' => [
					'icon_type' => 'icon',
				],
			]
		);
		$repeater->add_control(
			'choose_image',
			[
				'label' => esc_html__( 'Upload Icon', 'fame-core' ),
				'type' => Controls_Manager::MEDIA,
				'condition' => [
					'icon_type' => 'image',
				],
				'frontend_available' => true,
				'default' => [
					'url' => Utils::get_placeholder_image_src(),
				],
				'description' => esc_html__( 'Set your icon image.', 'fame-core'),
			]
		);
		
		$repeater->add_control(
			'choose_title',
			[
				'label' => esc_html__( 'Title', 'fame-core' ),
				'type' => Controls_Manager::TEXT,
				'default' => esc_html__( 'Title', 'fame-core' ),
				'placeholder' => esc_html__( 'Type title text here', 'fame-core' ),
				'label_block' => true,
			]
		);
		$repeater->add_control(
			'choose_title_link',
			[
				'label' => esc_html__( 'Link', 'fame-core' ),
				'type' => Controls_Manager::URL,
				'placeholder' => 'https://your-link.com',
				'default' => [
					'url' => '',
				],
				'label_block' => true,
			]
		);
		$repeater->add_control(
			'choose_content',
			[
				'label' => esc_html__( 'Content', 'fame-core' ),
				'default' => esc_html__( 'your content text', 'fame-core' ),
				'placeholder' => esc_html__( 'Type your content here', 'fame-core' ),
				'type' => Controls_Manager::TEXTAREA,
				'label_block' => true,
			]
		);
		$this->add_control(
			'choose_groups',
			[
				'label' => esc_html__( 'Choose Items', 'fame-core' ),
				'type' => Controls_Manager::REPEATER,
				'default' => [
					[
						'choose_title' => esc_html__( 'Easy to Use', 'fame-core' ),
						'choose_content' => esc_html__( 'The road and back again your heart is true youre a pal and an confidant being a best friend only travel down.', 'fame-core' ),
					],
					
				],
				'fields' => $repeater->get_controls(),
				'title_field' => '{{{ choose_title }}}',
			]
		);
		
		$this->end_controls_section();// end: Section

		// Title
		$this->start_controls_section(
			'section_title_style',
			[
				'label' => esc_html__( 'Title', 'fame-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'label' => esc_html__( 'Typography', 'fame-core' ),
					'name' => 'sastool_title_typography',
					'scheme' => Scheme_Typography::TYPOGRAPHY_1,
					'selector' => '{{WRAPPER}} .choose-info h3',
				]
			);
			$this->start_controls_tabs( 'choose_title_style' );
				$this->start_controls_tab(
					'title_normal',
					[
						'label' => esc_html__( 'Normal', 'fame-core' ),
					]
				);
				$this->add_control(
					'title_color',
					[
						'label' => esc_html__( 'Color', 'fame-core' ),
						'type' => Controls_Manager::COLOR,
						'selectors' => [
							'{{WRAPPER}} .choose-info h3, {{WRAPPER}} .choose-info h3 a' => 'color: {{VALUE}};',
						],
					]
				);
				$this->end_controls_tab();  // end:Normal tab
				
				$this->start_controls_tab(
					'title_hover',
					[
						'label' => esc_html__( 'Hover', 'fame-core' ),
					]
				);
				$this->add_control(
					'title_hov_color',
					[
						'label' => esc_html__( 'Color', 'fame-core' ),
						'type' => Controls_Manager::COLOR,
						'selectors' => [
							'{{WRAPPER}} .choose-info h3 a:hover' => 'color: {{VALUE}};',
						],
					]
				);
				$this->end_controls_tab();  // end:Hover tab
			$this->end_controls_tabs(); // end tabs
		$this->end_controls_section();// end: Section
		
		$this->start_controls_section(
			'section_content_style',
			[
				'label' => esc_html__( 'Content', 'fame-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'label' => esc_html__( 'Typography', 'fame-core' ),
					'name' => 'content_typography',
					'scheme' => Scheme_Typography::TYPOGRAPHY_1,
					'selector' => '{{WRAPPER}} .choose-info p',
				]
			);
			$this->add_control(
				'content_color',
				[
					'label' => esc_html__( 'Color', 'fame-core' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .choose-info p' => 'color: {{VALUE}};',
					],
				]
			);
		$this->end_controls_section();// end: Section

		$this->start_controls_section(
			'icon_style',
			[
				'label' => esc_html__( 'Icon', 'fame-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'icon_color',
			[
				'label' => esc_html__( 'Color', 'fame-core' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .choose-item .fame-icon i' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_responsive_control(
			'icon_font_size',
			[
				'label' => esc_html__( 'Icon Font Size', 'fame-core' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 1,
						'max' => 200,
						'step' => 1,
					],
				],
				'size_units' => [ 'px' ],
				'selectors' => [
					'{{WRAPPER}} .choose-item .fame-icon i' => 'font-size: {{SIZE}}{{UNIT}};',
				],
			]
		);
		$this->add_responsive_control(
			'icon_right',
			[
				'label' => esc_html__( 'Icon Right Space', 'fame-core' ),
				'type' => Controls_Manager::SLIDER,
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 200,
						'step' => 1,
					],
				],
				'size_units' => [ 'px' ],
				'selectors' => [
					'{{WRAPPER}} .choose-item .fame-icon' => 'padding-right: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section();// end: Section
		
	}

	/**
	 * Render Choose widget output on the frontend.
	 * Written in PHP and used to generate the final HTML.
	*/
	protected function render() {
		// Choose query
		$settings = $this->get_settings_for_display();
		$choose = $this->get_settings_for_display( 'choose_groups' );

		$output = '';

		if( !empty( $choose ) && is_array( $choose ) ){
		$output .= '<div class="choose-wrap">';	

			// Group Param Output
			foreach ( $choose as $each_logo ) {
				$image_url = wp_get_attachment_url( $each_logo['choose_image']['id'], 'thumbnail' );
				$fame_alt = get_post_meta($each_logo['choose_image']['id'], '_wp_attachment_image_alt', true);
				$choose_title_link = !empty( $each_logo['choose_title_link'] ) ? $each_logo['choose_title_link'] : '';
				$link_url = !empty( $choose_title_link['url'] ) ? esc_url($choose_title_link['url']) : '';
				$link_external = !empty( $choose_title_link['is_external'] ) ? 'target="_blank"' : '';
				$link_nofollow = !empty( $choose_title_link['nofollow'] ) ? 'rel="nofollow"' : '';
				$link_attr = !empty( $choose_title_link['url'] ) ?  $link_external.' '.$link_nofollow : '';

				$icon_type = !empty( $each_logo['icon_type'] ) ? $each_logo['icon_type'] : '';
	  		$icon = !empty( $each_logo['choose_icon'] ) ? $each_logo['choose_icon'] : '';

			  $title_link = !empty( $link_url ) ? '<a href="'.$link_url.'" '.$link_attr.'>'.$each_logo['choose_title'].'</a>' : $each_logo['choose_title'];
		  	$title = !empty( $each_logo['choose_title'] ) ? '<h3 class="choose-title">'.$title_link.'</h3>' : '';
			  $content = !empty( $each_logo['choose_content'] ) ? '<p>'.$each_logo['choose_content'].'</p>' : '';

			  $image = $image_url ? '<div class="fame-icon"><img src="'. $image_url .'" width="60" alt="'.$fame_alt.'"></div>' : '';
				$icon = $icon ? '<div class="fame-icon"><i class="'.$icon.'" aria-hidden="true"></i></div>' : '';

			  if($icon_type === 'icon') {
				  $icon_image = $icon;
				} else {
				  $icon_image = $image;
				}

			  $output .= '<div class="choose-item">
									    '.$icon_image.'
									    <div class="choose-info">'.$title.$content.'</div>
									  </div>';
			}

		$output .= '</div>';
		}
		echo $output;
		
	}

	/**
	 * Render Choose widget output in the editor.
	 * Written as a Backbone JavaScript template and used to generate the live preview.
	*/
	
	//protected function _content_template(){}
	
}
Plugin::instance()->widgets_manager->register_widget_type( new Fame_Choose() );