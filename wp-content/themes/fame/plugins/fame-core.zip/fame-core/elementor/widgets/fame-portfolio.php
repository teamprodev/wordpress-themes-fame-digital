<?php
/*
 * Elementor Fame Portfolio Widget
 * Author & Copyright: VictorTheme
*/

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

$noneed_portfolio_post = (fame_framework_active()) ? cs_get_option('noneed_portfolio_post') : '';

if (!$noneed_portfolio_post) {
class Fame_Portfolio extends Widget_Base{

	/**
	 * Retrieve the widget name.
	*/
	public function get_name(){
		return 'vt-fame_portfolio';
	}

	/**
	 * Retrieve the widget title.
	*/
	public function get_title(){
		return esc_html__( 'Portfolio', 'fame-core' );
	}

	/**
	 * Retrieve the widget icon.
	*/
	public function get_icon() {
		return 'fa fa-rocket';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	*/
	public function get_categories() {
		return ['victortheme-category'];
	}

	/**
	 * Retrieve the list of scripts the Fame Portfolio widget depended on.
	 * Used to set scripts dependencies required to run the widget.
	*/
	public function get_script_depends() {
		return ['vt-fame_portfolio'];
	}
	
	/**
	 * Register Fame Portfolio widget controls.
	 * Adds different input fields to allow the user to change and customize the widget settings.
	*/
	protected function _register_controls(){

		$this->start_controls_section(
			'section_portfolio_listing',
			[
				'label' => esc_html__( 'Listing', 'fame-core' ),
			]
		);
		$this->add_control(
			'portfolio_limit',
			[
				'label' => esc_html__( 'Limit', 'fame-core' ),
				'type' => Controls_Manager::NUMBER,
				'min' => -1,
				'step' => 1,
				'description' => esc_html__( 'Enter the number of items to show.', 'fame-core' ),
			]
		);
		$this->add_control(
			'portfolio_order',
			[
				'label' => __( 'Order', 'fame-core' ),
				'type' => Controls_Manager::SELECT,
				'options' => [
					'ASC' => esc_html__( 'Asending', 'fame-core' ),
					'DESC' => esc_html__( 'Desending', 'fame-core' ),
				],
				'default' => '',
				'description' => esc_html__( 'Select your order.', 'fame-core' ),
			]
		);
		$this->add_control(
			'portfolio_orderby',
			[
				'label' => __( 'Order By', 'fame-core' ),
				'type' => Controls_Manager::SELECT2,
				'default' => '',
				'options' => [
					'none' => __('None', 'fame-core'),
					'ID' => __('ID', 'fame-core'),
					'author' => __('Author', 'fame-core'),
					'title' => __('Name', 'fame-core'),
					'date' => __('Date', 'fame-core'),
					'rand' => __('Rand', 'fame-core'),
					'menu_order' => __('Menu Order', 'fame-core'),
				],
			]
		);
		$this->add_control(
			'portfolio_show_category',
			[
				'label' => __( 'Show only certain categories?', 'fame-core' ),
				'type' => Controls_Manager::SELECT2,
				'default' => [],
				'options' => Controls_Helper_Output::get_terms_names( 'portfolio_category'),
				'multiple' => true,
			]
		);
		$this->add_control(
			'read_more_txt',
			[
				'label' => esc_html__( 'More Text', 'fame-core' ),
				'type' => Controls_Manager::TEXT,
				'label_block' => true,
			]
		);
		$this->end_controls_section();// end: Section
		
		$this->start_controls_section(
			'section_portfolio_ena_dis',
			[
				'label' => esc_html__( 'Enable & Disable', 'fame-core' ),
			]
		);
		$this->add_control(
			'portfolio_aqr',
			[
				'label' => esc_html__( 'Disable Image Resize?', 'fame-core' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'fame-core' ),
				'label_off' => esc_html__( 'No', 'fame-core' ),
				'return_value' => 'true',
				'default' => 'false',
			]
		);
		$this->add_control(
			'portfolio_filter',
			[
				'label' => esc_html__( 'Filter', 'fame-core' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'fame-core' ),
				'label_off' => esc_html__( 'No', 'fame-core' ),
				'return_value' => 'true',
				'default' => 'true',
			]
		);
		$this->add_control(
			'portfolio_filter_type',
			[
				'label' => esc_html__( 'Filter Type', 'fame-core' ),
				'type' => Controls_Manager::SELECT,
				'options' => [
					'normal'  => esc_html__('Normal', 'fame'),
          'ajax'    => esc_html__('Ajax', 'fame'),
				],
				'default' => 'normal',
				'description' => esc_html__( 'Select Column.', 'fame-core' ),
				'condition' => [
					'portfolio_filter' => 'true',
				],
			]
		);

		$this->add_control(
			'portfolio_pagination',
			[
				'label' => esc_html__( 'Pagination', 'fame-core' ),
				'type' => Controls_Manager::SWITCHER,
				'label_on' => esc_html__( 'Yes', 'fame-core' ),
				'label_off' => esc_html__( 'No', 'fame-core' ),
				'return_value' => 'true',
				'default' => 'true',
			]
		);
		$this->end_controls_section();// end: Section
		
		// Filter
		$this->start_controls_section(
			'section_filter_style',
			[
				'label' => esc_html__( 'Filter', 'fame-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'portfolio_filter' => 'true',
				],
				'frontend_available' => true,
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'filter_typography',
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .masonry-filters ul li a',
			]
		);
		$this->add_responsive_control(
			'filter_padding',
			[
				'label' => __( 'Padding', 'fame-core' ),
				'type' => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors' => [
					'{{WRAPPER}} .masonry-filters ul li a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);
		$this->start_controls_tabs( 'filter_style' );
			$this->start_controls_tab(
				'filter_normal',
				[
					'label' => esc_html__( 'Normal', 'fame-core' ),
				]
			);
			$this->add_control(
				'filter_color',
				[
					'label' => esc_html__( 'Color', 'fame-core' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .masonry-filters ul li a' => 'color: {{VALUE}};',
					],
				]
			);
			$this->add_control(
				'filter_bg_color',
				[
					'label' => esc_html__( 'Background Color', 'fame-core' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .masonry-filters ul li a' => 'background-color: {{VALUE}};',
					],
				]
			);
			$this->add_control(
				'filter_border_color',
				[
					'label' => esc_html__( 'Border Color', 'fame-core' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .masonry-filters ul li a' => 'border-color: {{VALUE}};',
					],
				]
			);
			$this->end_controls_tab();  // end:Normal tab
			$this->start_controls_tab(
				'filter_active',
				[
					'label' => esc_html__( 'Active', 'fame-core' ),
				]
			);
			$this->add_control(
				'filter_active_color',
				[
					'label' => esc_html__( 'Color', 'fame-core' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .masonry-filters ul li a.active, {{WRAPPER}} .masonry-filters ul li a:hover' => 'color: {{VALUE}}',
					],
				]
			);
			$this->add_control(
				'filter_active_bg_color',
				[
					'label' => esc_html__( 'Background Color', 'fame-core' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .masonry-filters ul li a.active, {{WRAPPER}} .masonry-filters ul li a:hover' => 'background-color: {{VALUE}};',
					],
				]
			);
			$this->add_control(
				'filter_active_border_color',
				[
					'label' => esc_html__( 'Border Color', 'fame-core' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .masonry-filters ul li a.active, {{WRAPPER}} .masonry-filters ul li a:hover' => 'border-color: {{VALUE}};',
					],
				]
			);
			$this->end_controls_tab();  // end:Active tab
		$this->end_controls_tabs(); // end tabs		
		$this->end_controls_section();// end: Section
		
		// Title
		$this->start_controls_section(
			'section_title_style',
			[
				'label' => esc_html__( 'Title', 'fame-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'sasapp_title_typography',
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .portfolio-info h3',
			]
		);
		$this->start_controls_tabs( 'title_style' );
			$this->start_controls_tab(
				'title_normal',
				[
					'label' => esc_html__( 'Normal', 'fame-core' ),
				]
			);
			$this->add_control(
				'title_color',
				[
					'label' => esc_html__( 'Color', 'fame-core' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .portfolio-info h3 a' => 'color: {{VALUE}};',
					],
				]
			);
			$this->end_controls_tab();  // end:Normal tab
			
			$this->start_controls_tab(
				'title_hover',
				[
					'label' => esc_html__( 'Hover', 'fame-core' ),
				]
			);
			$this->add_control(
				'title_hover_color',
				[
					'label' => esc_html__( 'Color', 'fame-core' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .portfolio-info h3 a:hover' => 'color: {{VALUE}};',
					],
				]
			);
			$this->end_controls_tab();  // end:Hover tab
		$this->end_controls_tabs(); // end tabs		
		$this->end_controls_section();// end: Section

		// More
		$this->start_controls_section(
			'section_rmore_style',
			[
				'label' => esc_html__( 'Read More', 'fame-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'sasapp_rmore_typography',
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .fame-link a',
			]
		);
		$this->start_controls_tabs( 'rmore_style' );
			$this->start_controls_tab(
				'rmore_normal',
				[
					'label' => esc_html__( 'Normal', 'fame-core' ),
				]
			);
			$this->add_control(
				'rmore_color',
				[
					'label' => esc_html__( 'Color', 'fame-core' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .fame-link a' => 'color: {{VALUE}};',
					],
				]
			);
			$this->end_controls_tab();  // end:Normal tab
			
			$this->start_controls_tab(
				'rmore_hover',
				[
					'label' => esc_html__( 'Hover', 'fame-core' ),
				]
			);
			$this->add_control(
				'rmore_hover_color',
				[
					'label' => esc_html__( 'Color', 'fame-core' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .fame-link a:hover' => 'color: {{VALUE}};',
					],
				]
			);
			$this->end_controls_tab();  // end:Hover tab
		$this->end_controls_tabs(); // end tabs		
		$this->end_controls_section();// end: Section
		
		// Pagination
		$this->start_controls_section(
			'section_pagi_style',
			[
				'label' => esc_html__( 'Pagination', 'fame-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
				'condition' => [
					'portfolio_pagination' => 'true',
				],
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'pagi_typography',
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .fame-pagination ul li a, {{WRAPPER}} .fame-pagination ul li span',
			]
		);
		$this->start_controls_tabs( 'pagi_style' );
			$this->start_controls_tab(
				'pagi_normal',
				[
					'label' => esc_html__( 'Normal', 'fame-core' ),
				]
			);
			$this->add_control(
				'pagi_color',
				[
					'label' => esc_html__( 'Color', 'fame-core' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .fame-pagination ul li a' => 'color: {{VALUE}};',
					],
				]
			);
			$this->add_control(
				'pagi_bg_color',
				[
					'label' => esc_html__( 'Background Color', 'fame-core' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .fame-pagination ul li a' => 'background-color: {{VALUE}};',
					],
				]
			);
			$this->add_group_control(
				Group_Control_Border::get_type(),
				[
					'name' => 'pagi_border',
					'label' => esc_html__( 'Border', 'fame-core' ),
					'selector' => '{{WRAPPER}} .fame-pagination ul li a',
				]
			);
			$this->end_controls_tab();  // end:Normal tab
			
			$this->start_controls_tab(
				'pagi_hover',
				[
					'label' => esc_html__( 'Hover', 'fame-core' ),
				]
			);
			$this->add_control(
				'pagi_hover_color',
				[
					'label' => esc_html__( 'Color', 'fame-core' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .fame-pagination ul li a:hover' => 'color: {{VALUE}};',
					],
				]
			);
			$this->add_control(
				'pagi_bg_hover_color',
				[
					'label' => esc_html__( 'Background Color', 'fame-core' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .fame-pagination ul li a:hover' => 'background-color: {{VALUE}};',
					],
				]
			);
			$this->add_group_control(
				Group_Control_Border::get_type(),
				[
					'name' => 'pagi_hover_border',
					'label' => esc_html__( 'Border', 'fame-core' ),
					'selector' => '{{WRAPPER}} .fame-pagination ul li a:hover',
				]
			);
			$this->end_controls_tab();  // end:Hover tab
			$this->start_controls_tab(
				'pagi_active',
				[
					'label' => esc_html__( 'Active', 'fame-core' ),
				]
			);
			$this->add_control(
				'pagi_active_color',
				[
					'label' => esc_html__( 'Color', 'fame-core' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .fame-pagination ul li span.current' => 'color: {{VALUE}};',
					],
				]
			);
			$this->add_control(
				'pagi_bg_active_color',
				[
					'label' => esc_html__( 'Background Color', 'fame-core' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .fame-pagination ul li span.current' => 'background-color: {{VALUE}};',
					],
				]
			);
			$this->add_group_control(
				Group_Control_Border::get_type(),
				[
					'name' => 'pagi_active_border',
					'label' => esc_html__( 'Border', 'fame-core' ),
					'selector' => '{{WRAPPER}} .fame-pagination ul li span.current',
				]
			);
			$this->end_controls_tab();  // end:Active tab
		$this->end_controls_tabs(); // end tabs
		
		$this->end_controls_section();// end: Section
	}

	/**
	 * Render Portfolio widget output on the frontend.
	 * Written in PHP and used to generate the final HTML.
	*/
	protected function render() {
		$settings = $this->get_settings_for_display();
		$portfolio_limit = !empty( $settings['portfolio_limit'] ) ? $settings['portfolio_limit'] : '';
		$portfolio_order = !empty( $settings['portfolio_order'] ) ? $settings['portfolio_order'] : '';
		$portfolio_orderby = !empty( $settings['portfolio_orderby'] ) ? $settings['portfolio_orderby'] : '';
		$portfolio_show_category = !empty( $settings['portfolio_show_category'] ) ? $settings['portfolio_show_category'] : [];
		$read_more_txt = !empty( $settings['read_more_txt'] ) ? $settings['read_more_txt'] : '';
		$filter_title = !empty( $settings['filter_title'] ) ? $settings['filter_title'] : [];
		$portfolio_aqr  = ( isset( $settings['portfolio_aqr'] ) && ( 'true' == $settings['portfolio_aqr'] ) ) ? true : false;
		$portfolio_filter  = ( isset( $settings['portfolio_filter'] ) && ( 'true' == $settings['portfolio_filter'] ) ) ? true : false;
		$portfolio_filter_type = !empty( $settings['portfolio_filter_type'] ) ? $settings['portfolio_filter_type'] : '';
		$portfolio_pagination  = ( isset( $settings['portfolio_pagination'] ) && ( 'true' == $settings['portfolio_pagination'] ) ) ? true : false;

		$portfolio_limit = $portfolio_limit ? $portfolio_limit : '-1';
		$all_portfolio_txt = cs_get_option('all_text');
		$all_text_actual = $all_portfolio_txt ? $all_portfolio_txt : esc_html__( 'All', 'fame-core' );

		// Read More Text
		if (fame_framework_active()) {
		  $read_more_to = cs_get_option('portfolio_read_more');
		  if ($read_more_txt) {
			$read_more_txt = $read_more_txt;
		  } elseif($read_more_to) {
			$read_more_txt = $read_more_to;
		  } else {
			$read_more_txt = esc_html__( 'VIEW DETAILS', 'fame-core' );
		  }
		} else {
		  $read_more_txt = $read_more_txt ? $read_more_txt : esc_html__( 'VIEW DETAILS', 'fame-core' );
		}

		if ($portfolio_filter_type === 'ajax') {
	    $filter_cls = ' ajax-filter';
	  } else {
	    $filter_cls = ' normal-filter';
	  }

		// Turn output buffer on
		ob_start();

		// Pagination
		global $paged;
		if( get_query_var( 'paged' ) )
		  $my_page = get_query_var( 'paged' );
		else {
		  if( get_query_var( 'page' ) )
			$my_page = get_query_var( 'page' );
		  else
			$my_page = 1;
		  set_query_var( 'paged', $my_page );
		  $paged = $my_page;
		}

		$args = array(
		  // other query params here,
			'paged' => $my_page,
			'post_type' => 'portfolio',
			'posts_per_page' => (int)$portfolio_limit,
  		'portfolio_category' => $portfolio_show_category,
			'orderby' => $portfolio_orderby,
			'order' => $portfolio_order
		);
		
		$fame_port = new \WP_Query( $args ); ?>
		<div class="fame-portfolio-section">
			<?php if ($portfolio_filter) { ?>
			<div class="masonry-filters<?php echo esc_attr($filter_cls); ?>">
        <ul>
          <li><a href="javascript:void(0);" data-limit="<?php echo esc_attr($portfolio_limit); ?>" data-filter="*" class="active"><?php echo esc_html($all_text_actual); ?></a></li>
          <?php
            if ($portfolio_show_category) {
              $terms = $portfolio_show_category;
              $count = count($terms);
              if ($count > 0) {
                foreach ($terms as $term) {
                  echo '<li class="cat-'. preg_replace('/\s+/', "", strtolower($term)) .'"><a href="javascript:void(0);" data-limit="'.$portfolio_limit.'" data-cat="'. esc_attr($term->slug) .'" data-filter=".cat-'. preg_replace('/\s+/', "", strtolower($term)) .'" title="' . str_replace('-', " ", strtolower($term)) . '">' . str_replace('-', " ", strtolower($term)) . '</a></li>';
                 }
              }
            } else {
              $terms = get_terms('portfolio_category');
					    $count = count($terms);
					    $i=0;
					    $term_list = '';
					    if ($count > 0) {
					      foreach ($terms as $term) {
					        $i++;
					        $term_list .= '<li><a href="javascript:void(0);" data-limit="'.$portfolio_limit.'" data-cat="'. esc_attr($term->slug) .'" class="filter cat-'. esc_attr($term->slug) .'" data-filter=".cat-'. esc_attr($term->slug) .'" title="' . esc_attr($term->name) . '">' . esc_html($term->name) . '</a></li>';
					        if ($count != $i) {
					          $term_list .= '';
					        } else {
					          $term_list .= '';
					        }
					      }
					      echo $term_list;
					    }
            }
          ?>
        </ul>
      </div>
			<?php } ?>
			<!-- Portfolio Start -->
      <div class="fame-masonry">
	    	<?php
	      if ($fame_port->have_posts()) : while ($fame_port->have_posts()) : $fame_port->the_post();
	      global $post;
				$fame_terms = wp_get_post_terms($post->ID,'portfolio_category');
				foreach ($fame_terms as $term) {
				  $fame_cat_class = 'cat-' . $term->slug;
				}
				$fame_count = count($fame_terms);
				$i=0;
				$fame_cat_class = '';
				if ($fame_count > 0) {
				  foreach ($fame_terms as $term) {
				    $i++;
				    $fame_cat_class .= 'cat-'. $term->slug .' ';
				    if ($fame_count != $i) {
				      $fame_cat_class .= '';
				    } else {
				      $fame_cat_class .= '';
				    }
				  }
				}

				// Featured Image
				$fame_large_image =  wp_get_attachment_image_src( get_post_thumbnail_id(get_the_ID()), 'fullsize', false, '' );
				$fame_large_image = $fame_large_image[0];
				if ($portfolio_aqr) {
					$fame_featured_img = $fame_large_image;
				} else {
					if(class_exists('Aq_Resize')) {
				    $fame_portfolio_img = aq_resize( $fame_large_image, '500', '839', true );
				  } else {$fame_portfolio_img = $fame_large_image;}
				  $fame_featured_img = ( $fame_portfolio_img ) ? $fame_portfolio_img : $fame_large_image;
				}
				?>
				<div class="masonry-item <?php echo esc_attr($fame_cat_class); ?>" data-category="<?php echo esc_attr($fame_cat_class); ?>">
				  <div class="portfolio-item">
				    <?php if($fame_large_image) { ?>
				    <div class="fame-image">
				      <a href="<?php echo esc_url( get_permalink() ); ?>"><img src="<?php echo esc_url($fame_featured_img); ?>" alt="<?php echo esc_attr(get_the_title()); ?>"></a>
				    </div>
				    <?php } ?>
				    <div class="portfolio-info">
				      <h3 class="portfolio-title"><a href="<?php echo esc_url( get_permalink() ); ?>"><?php echo esc_html(the_title()); ?></a></h3>
				      <div class="fame-link">
				        <a href="<?php echo esc_url( get_permalink() ); ?>"><?php echo esc_html($read_more_txt); ?> <img src="<?php echo esc_url( FAME_PLUGIN_ASTS . '/images/icons/icon53@2x.png' ); ?>" width="18" alt="<?php echo esc_attr($read_more_txt); ?>"></a>
				      </div>
				    </div>
				  </div>
				</div>
        <?php endwhile;
	      endif; 
	      wp_reset_postdata(); ?>
      </div>
			<?php if ($portfolio_pagination) { fame_paging_nav($fame_port->max_num_pages,"",$paged); } ?>
		</div>
		<!-- Portfolio End -->

		<?php
		// Return outbut buffer
		echo ob_get_clean();
		
	}

	/**
	 * Render Portfolio widget output in the editor.
	 * Written as a Backbone JavaScript template and used to generate the live preview.
	*/
	
	//protected function _content_template(){}
	
}
Plugin::instance()->widgets_manager->register_widget_type( new Fame_Portfolio() );
}