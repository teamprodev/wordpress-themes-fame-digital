<?php
/*
 * Elementor Fame Process Widget
 * Author & Copyright: VictorTheme
*/

namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Fame_Process extends Widget_Base{

	/**
	 * Retrieve the widget name.
	*/
	public function get_name(){
		return 'vt-fame_process';
	}

	/**
	 * Retrieve the widget title.
	*/
	public function get_title(){
		return esc_html__( 'Process', 'fame-core' );
	}

	/**
	 * Retrieve the widget icon.
	*/
	public function get_icon() {
		return 'fa fa-anchor';
	}

	/**
	 * Retrieve the list of categories the widget belongs to.
	*/
	public function get_categories() {
		return ['victortheme-category'];
	}

	/**
	 * Retrieve the list of scripts the Fame Process widget depended on.
	 * Used to set scripts dependencies required to run the widget.
	*/
	/*
	public function get_script_depends() {
		return ['vt-fame_process'];
	}
	*/
	
	/**
	 * Register Fame Process widget controls.
	 * Adds different input fields to allow the user to change and customize the widget settings.
	*/
	protected function _register_controls(){
		
		$this->start_controls_section(
			'section_process',
			[
				'label' => __( 'Process Item', 'fame-core' ),
			]
		);

		$repeater = new Repeater();
		$repeater->add_control(
			'process_number',
			[
				'label' => esc_html__( 'Number', 'fame-core' ),
				'type' => Controls_Manager::TEXT,
				'default' => esc_html__( '01', 'fame-core' ),
				'placeholder' => esc_html__( 'Type number text here', 'fame-core' ),
				'label_block' => true,
			]
		);
		$repeater->add_control(
			'process_title',
			[
				'label' => esc_html__( 'Title', 'fame-core' ),
				'type' => Controls_Manager::TEXT,
				'default' => esc_html__( 'Prototyping', 'fame-core' ),
				'placeholder' => esc_html__( 'Type title text here', 'fame-core' ),
				'label_block' => true,
			]
		);
		$repeater->add_control(
			'process_title_link',
			[
				'label' => esc_html__( 'Link', 'fame-core' ),
				'type' => Controls_Manager::URL,
				'placeholder' => 'https://your-link.com',
				'default' => [
					'url' => '',
				],
				'label_block' => true,
			]
		);
		$repeater->add_control(
			'process_content',
			[
				'label' => esc_html__( 'Content', 'fame-core' ),
				'default' => esc_html__( 'your content text', 'fame-core' ),
				'placeholder' => esc_html__( 'Type your content here', 'fame-core' ),
				'type' => Controls_Manager::TEXTAREA,
				'label_block' => true,
			]
		);
		$this->add_control(
			'process_groups',
			[
				'label' => esc_html__( 'Process Items', 'fame-core' ),
				'type' => Controls_Manager::REPEATER,
				'default' => [
					[
						'process_title' => esc_html__( 'Prototyping', 'fame-core' ),
						'process_content' => esc_html__( 'The road and back again your heart is true youre a pal and an confidant being a best friend only travel down.', 'fame-core' ),
					],
					
				],
				'fields' => $repeater->get_controls(),
				'title_field' => '{{{ process_title }}}',
			]
		);
		
		$this->end_controls_section();// end: Section

		$this->start_controls_section(
			'number_style',
			[
				'label' => esc_html__( 'Number', 'fame-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'label' => esc_html__( 'Typography', 'fame-core' ),
				'name' => 'number_typography',
				'scheme' => Scheme_Typography::TYPOGRAPHY_1,
				'selector' => '{{WRAPPER}} .process-item h2',
			]
		);
		$this->add_control(
			'number_color',
			[
				'label' => esc_html__( 'Color', 'fame-core' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .process-item h2' => 'color: {{VALUE}};',
				],
			]
		);
		$this->add_control(
			'number_bg_color',
			[
				'label' => esc_html__( 'Background Shape Color', 'fame-core' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .process-counter span, {{WRAPPER}} .process-counter span:before, {{WRAPPER}} .process-counter span:after' => 'background: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();// end: Section

		// Title
		$this->start_controls_section(
			'section_title_style',
			[
				'label' => esc_html__( 'Title', 'fame-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'label' => esc_html__( 'Typography', 'fame-core' ),
					'name' => 'sastool_title_typography',
					'scheme' => Scheme_Typography::TYPOGRAPHY_1,
					'selector' => '{{WRAPPER}} .process-item h3',
				]
			);
			$this->start_controls_tabs( 'process_title_style' );
				$this->start_controls_tab(
					'title_normal',
					[
						'label' => esc_html__( 'Normal', 'fame-core' ),
					]
				);
				$this->add_control(
					'title_color',
					[
						'label' => esc_html__( 'Color', 'fame-core' ),
						'type' => Controls_Manager::COLOR,
						'selectors' => [
							'{{WRAPPER}} .process-item h3, {{WRAPPER}} .process-item h3 a' => 'color: {{VALUE}};',
						],
					]
				);
				$this->end_controls_tab();  // end:Normal tab
				
				$this->start_controls_tab(
					'title_hover',
					[
						'label' => esc_html__( 'Hover', 'fame-core' ),
					]
				);
				$this->add_control(
					'title_hov_color',
					[
						'label' => esc_html__( 'Color', 'fame-core' ),
						'type' => Controls_Manager::COLOR,
						'selectors' => [
							'{{WRAPPER}} .process-item h3 a:hover' => 'color: {{VALUE}};',
						],
					]
				);
				$this->end_controls_tab();  // end:Hover tab
			$this->end_controls_tabs(); // end tabs
		$this->end_controls_section();// end: Section
		
		$this->start_controls_section(
			'section_content_style',
			[
				'label' => esc_html__( 'Content', 'fame-core' ),
				'tab' => Controls_Manager::TAB_STYLE,
			]
		);
			$this->add_group_control(
				Group_Control_Typography::get_type(),
				[
					'label' => esc_html__( 'Typography', 'fame-core' ),
					'name' => 'content_typography',
					'scheme' => Scheme_Typography::TYPOGRAPHY_1,
					'selector' => '{{WRAPPER}} .process-item p',
				]
			);
			$this->add_control(
				'content_color',
				[
					'label' => esc_html__( 'Color', 'fame-core' ),
					'type' => Controls_Manager::COLOR,
					'selectors' => [
						'{{WRAPPER}} .process-item p' => 'color: {{VALUE}};',
					],
				]
			);
		$this->end_controls_section();// end: Section
		
	}

	/**
	 * Render Process widget output on the frontend.
	 * Written in PHP and used to generate the final HTML.
	*/
	protected function render() {
		// Process query
		$settings = $this->get_settings_for_display();
		$process = $this->get_settings_for_display( 'process_groups' );

		$output = '';

		if( !empty( $process ) && is_array( $process ) ){
		$output .= '<div class="fame-process"><div class="row justify-content-center">';	

			// Group Param Output
			foreach ( $process as $each_logo ) {
				$process_title_link = !empty( $each_logo['process_title_link'] ) ? $each_logo['process_title_link'] : '';
				$link_url = !empty( $process_title_link['url'] ) ? esc_url($process_title_link['url']) : '';
				$link_external = !empty( $process_title_link['is_external'] ) ? 'target="_blank"' : '';
				$link_nofollow = !empty( $process_title_link['nofollow'] ) ? 'rel="nofollow"' : '';
				$link_attr = !empty( $process_title_link['url'] ) ?  $link_external.' '.$link_nofollow : '';

				$process_number = !empty( $each_logo['process_number'] ) ? $each_logo['process_number'] : '';

		  	$count = !empty( $process_number ) ? '<h2 class="process-counter"><span></span>'.$process_number.'</h2>' : '';
			  $title_link = !empty( $link_url ) ? '<a href="'.$link_url.'" '.$link_attr.'>'.$each_logo['process_title'].'</a>' : $each_logo['process_title'];
		  	$title = !empty( $each_logo['process_title'] ) ? '<h3 class="process-title">'.$title_link.'</h3>' : '';
			  $content = !empty( $each_logo['process_content'] ) ? '<p>'.$each_logo['process_content'].'</p>' : '';

			  $output .= '<div class="col-md-4 col-sm-6"><div class="process-item fame-item">'.$count.$title.$content.'</div></div>';
			}

		$output .= '</div></div>';
		}
		echo $output;
		
	}

	/**
	 * Render Process widget output in the editor.
	 * Written as a Backbone JavaScript template and used to generate the live preview.
	*/
	
	//protected function _content_template(){}
	
}
Plugin::instance()->widgets_manager->register_widget_type( new Fame_Process() );